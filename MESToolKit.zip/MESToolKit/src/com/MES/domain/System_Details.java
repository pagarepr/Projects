package com.MES.domain;

public class System_Details {
	private int sys_ID;
	private int attribute_id;
	private int subAttribute_id;
	private String details;
	private int details_id;
	private int age;
	private int noOfUsers;
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getNoOfUsers() {
		return noOfUsers;
	}
	public void setNoOfUsers(int noOfUsers) {
		this.noOfUsers = noOfUsers;
	}
	public int getDetails_id() {
		return details_id;
	}
	public void setDetails_id(int details_id) {
		this.details_id = details_id;
	}
	public int getSys_ID() {
		return sys_ID;
	}
	public void setSys_ID(int sys_ID) {
		this.sys_ID = sys_ID;
	}
	public int getAttribute_id() {
		return attribute_id;
	}
	public void setAttribute_id(int attribute_id) {
		this.attribute_id = attribute_id;
	}
	public int getSubAttribute_id() {
		return subAttribute_id;
	}
	public void setSubAttribute_id(int subAttribute_id) {
		this.subAttribute_id = subAttribute_id;
	}
	public String getDetails() {
		return details;
	}
	public void setDetails(String details) {
		this.details = details;
	}
	

}
