package com.MES.domain;

public class SubBusinessProcess {
	private int SBP_ID;
	private int PROCESS_ID;
	private String SBP_NAME;
	private int percentageCompleted;
	public int getSBP_ID() {
		return SBP_ID;
	}
	public void setSBP_ID(int sBP_ID) {
		SBP_ID = sBP_ID;
	}
	public int getPROCESS_ID() {
		return PROCESS_ID;
	}
	public void setPROCESS_ID(int pROCESS_ID) {
		PROCESS_ID = pROCESS_ID;
	}
	public String getSBP_NAME() {
		return SBP_NAME;
	}
	public void setSBP_NAME(String sBP_NAME) {
		SBP_NAME = sBP_NAME;
	}
	public int getPercentageCompleted() {
		return percentageCompleted;
	}
	public void setPercentageCompleted(int percentageCompleted) {
		this.percentageCompleted = percentageCompleted;
	}
	
}
