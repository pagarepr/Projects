package com.MES.domain;


import com.MES.services.PasswordSecurity;

public class NewUser 
{
	private String userid;
	private String firstName;
	private String lastName;
	private String Company;
	private String pswd;
	private String cmpswd;
	private String username;
	private String siteName;
	private int roleid;
	private int pwdQues;
	private String pwdQuesAns;
	
	
	public int getRoleid() {
		return roleid;
	}
	public void setRoleid(int roleid) {
		this.roleid = roleid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getCompany() {
		return Company;
	}
	public void setCompany(String company) {
		Company = company;
	}
	public String getEncryptedPwd() {
		return pswd;
	}
	public String getPswd() {
		String pwd=null;
		try{
			pwd=PasswordSecurity.decrypt(pswd);
		}catch(Exception e)
		{}
	return pwd;
	}
	public void setPswd(String pswd) {
		try{
		pswd=PasswordSecurity.encrypt(pswd);
		}catch(Exception e){}
		this.pswd = pswd;
	}
	public String getCmpswd() {
		return cmpswd;
	}
	public void setCmpswd(String cmpswd) {
		this.cmpswd = cmpswd;
	}
	public String getSiteName() {
		return siteName;
	}
	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}
	public int getPwdQues() {
		return pwdQues;
	}
	public void setPwdQues(int pwdQues) {
		this.pwdQues = pwdQues;
	}
	public String getPwdQuesAns() {
		return pwdQuesAns;
	}
	public void setPwdQuesAns(String pwdQuesAns) {
		this.pwdQuesAns = pwdQuesAns;
	}
	
	
	
	
}
