package com.MES.domain;

public class RequirementFormDetails {
	private String req_id;
	private String SBP_name;
	private String SP_name;
	private String std_name;
	private int SBP_id;
	private int SP_id;
	private String process_details;
	private String rating;
	private String commentsGiven;
	private int details_id;
	public int getSBP_id() {
		return SBP_id;
	}
	public void setSBP_id(int sBP_id) {
		SBP_id = sBP_id;
	}
	public int getSP_id() {
		return SP_id;
	}
	public void setSP_id(int sP_id) {
		SP_id = sP_id;
	}
	
	public String getReq_id() {
		return req_id;
	}
	public void setReq_id(String req_id) {
		this.req_id = req_id;
	}
	public String getSBP_name() {
		return SBP_name;
	}
	public void setSBP_name(String sBP_name) {
		SBP_name = sBP_name;
	}
	public String getSP_name() {
		return SP_name;
	}
	public void setSP_name(String sP_name) {
		SP_name = sP_name;
	}
	public String getProcess_details() {
		return process_details;
	}
	public void setProcess_details(String process_details) {
		this.process_details = process_details;
	}
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	public String getCommentsGiven() {
		return commentsGiven;
	}
	public void setCommentsGiven(String commentsGiven) {
		this.commentsGiven = commentsGiven;
	}
	public int getDetails_id() {
		return details_id;
	}
	public void setDetails_id(int details_id) {
		this.details_id = details_id;
	}
	public String getStd_name() {
		return std_name;
	}
	public void setStd_name(String std_name) {
		this.std_name = std_name;
	}
	
	

}
