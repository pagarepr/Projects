package com.MES.domain;


public class AssementmentForm {
	private String reqID;
	private String stdProcess;
	private String subProcess;
	private String existingSystemEntered;
	private int sp_id;
	private String[] existingSystem;
	private int[] id;
	private int[] elements;  
	private String[] subProcessSystems;
	public String[] getSubProcessSystems() {
		return subProcessSystems;
	}
	public void setSubProcessSystems(String[] subProcessSystems) {
		this.subProcessSystems = subProcessSystems;
	}
	public String getExistingSystemEntered() {
		return existingSystemEntered;
	}
	public void setExistingSystemEntered(String existingSystemEntered) {
		this.existingSystemEntered = existingSystemEntered;
	}
	public int getSp_id() {
		return sp_id;
	}
	public void setSp_id(int sp_id) {
		this.sp_id = sp_id;
	}
	
	public int[] getId() {
		return id;
	}
	public void setId(int[] id) {
		this.id = id;
	}
	

	public int[] getElements() {
		return elements;
	}
	public void setElements(int[] elements) {
		this.elements = elements;
	}
	public String getReqID() {
		return reqID;
	}
	public void setReqID(String reqID) {
		this.reqID = reqID;
	}
	public String getStdProcess() {
		return stdProcess;
	}
	public void setStdProcess(String stdProcess) {
		this.stdProcess = stdProcess;
	}
	public String getSubProcess() {
		return subProcess;
	}
	public void setSubProcess(String subProcess) {
		this.subProcess = subProcess;
	}
	public String[] getExistingSystem() {
		return existingSystem;
	}
	public void setExistingSystem(String[] existingSystem) {
		this.existingSystem = existingSystem;
	}

}

