package com.MES.domain;

public class System_Attribute {

	private int attribute_id;
	private int attribute_subtype;
	private String attribute_name;
	private int is_active;
	public int getAttribute_id() {
		return attribute_id;
	}
	public void setAttribute_id(int attribute_id) {
		this.attribute_id = attribute_id;
	}
	public int getAttribute_subtype() {
		return attribute_subtype;
	}
	public void setAttribute_subtype(int attribute_subtype) {
		this.attribute_subtype = attribute_subtype;
	}
	public String getAttribute_name() {
		return attribute_name;
	}
	public void setAttribute_name(String attribute_name) {
		this.attribute_name = attribute_name;
	}
	public int getIs_active() {
		return is_active;
	}
	public void setIs_active(int is_active) {
		this.is_active = is_active;
	}
	
}
