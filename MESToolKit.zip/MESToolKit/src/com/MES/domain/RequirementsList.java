package com.MES.domain;

public class RequirementsList {
	private String req_id;
	private String userid;
	private String company;
	private String site;
	private String idSelected;
	public String getReq_id() {
		return req_id;
	}
	public void setReq_id(String req_id) {
		this.req_id = req_id;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getSite() {
		return site;
	}
	public void setSite(String site) {
		this.site = site;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getIdSelected() {
		return idSelected;
	}
	public void setIdSelected(String idSelected) {
		this.idSelected = idSelected;
	}
}
