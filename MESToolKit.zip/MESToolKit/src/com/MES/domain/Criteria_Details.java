package com.MES.domain;

public class Criteria_Details 
{
	private int criteria_details_id;
	private int criteria_id;
	private int ratings;
	private String ratings_name;
	public int getCriteria_details_id() {
		return criteria_details_id;
	}
	public void setCriteria_details_id(int criteria_details_id) {
		this.criteria_details_id = criteria_details_id;
	}
	public int getCriteria_id() {
		return criteria_id;
	}
	public void setCriteria_id(int criteria_id) {
		this.criteria_id = criteria_id;
	}
	public int getRatings() {
		return ratings;
	}
	public void setRatings(int ratings) {
		this.ratings = ratings;
	}
	public String getRatings_name() {
		return ratings_name;
	}
	public void setRatings_name(String ratings_name) {
		this.ratings_name = ratings_name;
	}
}
