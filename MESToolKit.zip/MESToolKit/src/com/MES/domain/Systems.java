package com.MES.domain;

public class Systems {
	private int sys_ID;
	private String sys_Name;
	private String sys_Description;
	private String company;
	private String inserted_By;
	private String site;
	private int[] systemsID;

	public int getSys_ID() {
		return sys_ID;
	}
	public void setSys_ID(int sys_ID) {
		this.sys_ID = sys_ID;
	}
	public String getSys_Name() {
		return sys_Name;
	}
	public void setSys_Name(String sys_Name) {
		this.sys_Name = sys_Name;
	}
	public String getSys_Description() {
		return sys_Description;
	}
	public void setSys_Description(String sys_Description) {
		this.sys_Description = sys_Description;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getInserted_By() {
		return inserted_By;
	}
	public void setInserted_By(String inserted_By) {
		this.inserted_By = inserted_By;
	}
	
	public String getSite() {
		return site;
	}
	public void setSite(String site) {
		this.site = site;
	}
	public int[] getSystemsID() {
		return systemsID;
	}
	public void setSystemsID(int[] systemsID) {
		this.systemsID = systemsID;
	}
	
 

}
