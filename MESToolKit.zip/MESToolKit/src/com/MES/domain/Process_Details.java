package com.MES.domain;

public class Process_Details {
	private int details_Id;
	private int SP_Id;
	private String DETAILS;
	private int is_active;
	private int customer_active;
	private String customer_name;
	private String site;
	public int getCustomer_active() {
		return customer_active;
	}
	public void setCustomer_active(int customer_active) {
		this.customer_active = customer_active;
	}
	public String getCustomer_name() {
		return customer_name;
	}
	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}
	public String getSite() {
		return site;
	}
	public void setSite(String site) {
		this.site = site;
	}
	public int getIs_active() {
		return is_active;
	}
	public void setIs_active(int is_active) {
		this.is_active = is_active;
	}
	private int check;
	public int getCheck() {
		return check;
	}
	public void setCheck(int check) {
		this.check = check;
	}
	public int getDetails_Id() {
		return details_Id;
	}
	public void setDetails_Id(int details_Id) {
		this.details_Id = details_Id;
	}
	public int getSP_Id() {
		return SP_Id;
	}
	public void setSP_Id(int sP_Id) {
		SP_Id = sP_Id;
	}
	public String getDETAILS() {
		return DETAILS;
	}
	public void setDETAILS(String details) {
		DETAILS = details;
	}
	
	
	

}
