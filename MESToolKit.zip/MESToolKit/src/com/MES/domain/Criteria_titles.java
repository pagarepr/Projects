package com.MES.domain;

public class Criteria_titles 
{
	private int criteria_id;
	private String criteria_Title;
	
	public String getCriteria_Title() {
		return criteria_Title;
	}
	public void setCriteria_Title(String criteria_Title) {
		this.criteria_Title = criteria_Title;
	}
	public int getCriteria_id() {
		return criteria_id;
	}
	public void setCriteria_id(int criteria_id) {
		this.criteria_id = criteria_id;
	}

	
}
