package com.MES.domain;

public class SubProcess {
	private int SP_id;
	private int SBP_id;
	private String SP_Name;
	private int percentageCompleted;
	public int getSP_id() {
		return SP_id;
	}
	public void setSP_id(int sP_id) {
		SP_id = sP_id;
	}
	public int getSBP_id() {
		return SBP_id;
	}
	public void setSBP_id(int sBP_id) {
		SBP_id = sBP_id;
	}
	public String getSP_Name() {
		return SP_Name;
	}
	public void setSP_Name(String sP_Name) {
		SP_Name = sP_Name;
	}
	public int getPercentageCompleted() {
		return percentageCompleted;
	}
	public void setPercentageCompleted(int percentageCompleted) {
		this.percentageCompleted = percentageCompleted;
	}
	
}
