 package com.MES.domain;   
  
public class HomeDetails {   
  
 private int moduleid;   
 private String moduleName;   
 private String link;   
 private String	description;   
  
  
 

public int getModuleid() {
	return moduleid;
}

public void setModuleid(int moduleid) {
	this.moduleid = moduleid;
}

public String getModuleName() {
	return moduleName;
}

public void setModuleName(String moduleName) {
	this.moduleName = moduleName;
}

public String getLink() {
	return link;
}

public void setLink(String link) {
	this.link = link;
}

public String getDescription() {
	return description;
}

public void setDescription(String description) {
	this.description = description;
}   
  
  
  
  
}  
