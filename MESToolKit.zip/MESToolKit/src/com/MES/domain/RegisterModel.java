package com.MES.domain;


public class RegisterModel 
{
	private NewUser register;

	public NewUser getRegisterModel() {
		return register;
	}


	public void setRegisterModel(NewUser reg) 
	{
		this.register=reg;
		
	}

}
