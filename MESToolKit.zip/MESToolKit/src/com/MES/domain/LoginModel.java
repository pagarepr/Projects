package com.MES.domain;


public class LoginModel 
{
	private Login login;

	public Login getLoginModel() {
		return login;
	}


	public void setLoginModel(Login login2) 
	{
		this.login=login2;
		
	}

}
