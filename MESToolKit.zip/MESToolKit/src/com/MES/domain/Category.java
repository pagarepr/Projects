package com.MES.domain;

public class Category {
	private int cat_id;
	private String cat_id1; 
	private String cat_name;
	private int criteria_id;
	private int is_active;
	public int getCat_id() {
		return cat_id;
	}
	public void setCat_id(int cat_id) {
		this.cat_id = cat_id;
	}
	public String getCat_name() {
		return cat_name;
	}
	public void setCat_name(String cat_name) {
		this.cat_name = cat_name;
	}
	public int getCriteria_id() {
		return criteria_id;
	}
	public void setCriteria_id(int criteria_id) {
		this.criteria_id = criteria_id;
	}
	public int getIs_active() {
		return is_active;
	}
	public void setIs_active(int is_active) {
		this.is_active = is_active;
	}
	public String getCat_id1() {
		return cat_id1;
	}
	public void setCat_id1(String cat_id1) {
		this.cat_id1 = cat_id1;
	}
}
