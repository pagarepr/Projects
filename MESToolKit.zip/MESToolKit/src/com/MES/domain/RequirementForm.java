package com.MES.domain;

public class RequirementForm {
	
	private String[] SBP_Name;
	private String[] SBP_id;
	private String[] SP_id;
	private String[] SP_Name;
	private String[] std_Name;
	private String[] Process_Details;
	private String rating;
	private String[] comments;
	private int[] details_id;
	public int[] getDetails_id() {
		return details_id;
	}
	public void setDetails_id(int[] details_id) {
		this.details_id = details_id;
	}	
	public String[] getSBP_Name() {
		return SBP_Name;
	}
	public void setSBP_Name(String[] sBP_Name) {
		SBP_Name = sBP_Name;
	}
	public String[] getSP_Name() {
		return SP_Name;
	}
	public void setSP_Name(String[] sP_Name) {
		SP_Name = sP_Name;
	}
	public String[] getProcess_Details() {
		return Process_Details;
	}
	public void setProcess_Details(String[] process_Details) {
		Process_Details = process_Details;
	}
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	public String[] getComments() {
		return comments;
	}
	public void setComments(String[] comments) {
		this.comments = comments;
	}
	public String[] getStd_Name() {
		return std_Name;
	}
	public void setStd_Name(String[] std_Name) {
		this.std_Name = std_Name;
	}
	public String[] getSP_id() {
		return SP_id;
	}
	public void setSP_id(String[] sP_id) {
		SP_id = sP_id;
	}
	public String[] getSBP_id() {
		return SBP_id;
	}
	public void setSBP_id(String[] sBP_id) {
		SBP_id = sBP_id;
	}
	
	
}
