package com.MES.domain;

public class System_SubAttributes {
	private int subAttribute_id;
	private int attribute_subtype;
	private String subAttribute_name;
	private int mainAttribute_id;
	private int is_active;
	private int is_active1;
	public int getSubAttribute_id() {
		return subAttribute_id;
	}
	public void setSubAttribute_id(int subAttribute_id) {
		this.subAttribute_id = subAttribute_id;
	}
	public int getAttribute_subtype() {
		return attribute_subtype;
	}
	public void setAttribute_subtype(int attribute_subtype) {
		this.attribute_subtype = attribute_subtype;
	}
	public String getSubAttribute_name() {
		return subAttribute_name;
	}
	public void setSubAttribute_name(String subAttribute_name) {
		this.subAttribute_name = subAttribute_name;
	}
	public int getMainAttribute_id() {
		return mainAttribute_id;
	}
	public void setMainAttribute_id(int mainAttribute_id) {
		this.mainAttribute_id = mainAttribute_id;
	}
	public int getIs_active() {
		return is_active;
	}
	public void setIs_active(int is_active) {
		this.is_active = is_active;
	}
	public int getIs_active1() {
		return is_active1;
	}
	public void setIs_active1(int is_active1) {
		this.is_active1 = is_active1;
	}
	

}
