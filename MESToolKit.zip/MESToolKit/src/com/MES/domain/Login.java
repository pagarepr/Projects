package com.MES.domain;

import com.MES.services.PasswordSecurity;

public class Login 
{
	private String userid;
	private String password;
	private String username;
	private String company;
	private int pwdQues;
	private String pwdAns;
	private String site;
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	private int roleId;
	
	public int getRoleId() {
		return roleId;
	}
	public void setRoleId(int roleId) {
		this.roleId = roleId;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String setEncryptedPwd(String pwd) {
		String pswd=null;
	
	try{
		pswd=PasswordSecurity.encrypt(pwd);
		}catch(Exception e){}
	return pswd;
	}
	public String getSite() {
		return site;
	}
	public void setSite(String site) {
		this.site = site;
	}
	public int getPwdQues() {
		return pwdQues;
	}
	public void setPwdQues(int pwdQues) {
		this.pwdQues = pwdQues;
	}
	public String getPwdAns() {
		return pwdAns;
	}
	public void setPwdAns(String pwdAns) {
		this.pwdAns = pwdAns;
	}
	
}
