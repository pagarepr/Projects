package com.MES.domain;

public class Supplier_Info_Questions {
	private int sInfo_id;
	private int cat_id;
	private String cat_id1;
	private int sd_id;
	private String info_ques;
	private String ratings;
	private String comments;
	private String company;
	private int is_active;
	public int getsInfo_id() {
		return sInfo_id;
	}
	public void setsInfo_id(int sInfo_id) {
		this.sInfo_id = sInfo_id;
	}
	public int getCat_id() {
		return cat_id;
	}
	public void setCat_id(int cat_id) {
		this.cat_id = cat_id;
	}
	public int getSd_id() {
		return sd_id;
	}
	public void setSd_id(int sd_id) {
		this.sd_id = sd_id;
	}
	public String getInfo_ques() {
		return info_ques;
	}
	public void setInfo_ques(String info_ques) {
		this.info_ques = info_ques;
	}
	public String getRatings() {
		return ratings;
	}
	public void setRatings(String ratings) {
		this.ratings = ratings;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getCat_id1() {
		return cat_id1;
	}
	public void setCat_id1(String cat_id1) {
		this.cat_id1 = cat_id1;
	}
	public int getIs_active() {
		return is_active;
	}
	public void setIs_active(int is_active) {
		this.is_active = is_active;
	}
}
