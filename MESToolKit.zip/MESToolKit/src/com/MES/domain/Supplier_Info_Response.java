package com.MES.domain;

public class Supplier_Info_Response {
	private int[] sInfo_id;
	private int[] cat_id;
	private int[] sd_id;
	private String ratings;
	private String[] comments;
	public int[] getsInfo_id() {
		return sInfo_id;
	}
	public void setsInfo_id(int[] sInfo_id) {
		this.sInfo_id = sInfo_id;
	}
	public int[] getCat_id() {
		return cat_id;
	}
	public void setCat_id(int[] cat_id) {
		this.cat_id = cat_id;
	}
	public int[] getSd_id() {
		return sd_id;
	}
	public void setSd_id(int[] sd_id) {
		this.sd_id = sd_id;
	}
	public String getRatings() {
		return ratings;
	}
	public void setRatings(String ratings) {
		this.ratings = ratings;
	}
	public String[] getComments() {
		return comments;
	}
	public void setComments(String[] comments) {
		this.comments = comments;
	}
	
}
