package com.MES.services;   


import java.util.List;   

import org.springframework.beans.factory.annotation.Autowired;   
import org.springframework.stereotype.Service;

import com.MES.domain.AssementmentForm;
import com.MES.dao.TablesDao;
import com.MES.domain.Category;
import com.MES.domain.CompanyDetails;
import com.MES.domain.Criteria_Details;
import com.MES.domain.Criteria_titles;
import com.MES.domain.Login;
import com.MES.domain.NewUser;
import com.MES.domain.Process_Details;
import com.MES.domain.Ratings;
import com.MES.domain.RequirementFormDetails;
import com.MES.domain.RequirementsList;
import com.MES.domain.Role;
import com.MES.domain.SiteDetails;
import com.MES.domain.StdBusinessProcess;
import com.MES.domain.SubBusinessProcess;
import com.MES.domain.SubProcess;
import com.MES.domain.HomeDetails;
import com.MES.domain.SupplierRatingDetails;
import com.MES.domain.Supplier_Info_Questions;
import com.MES.domain.System_Attribute;
import com.MES.domain.System_Details;
import com.MES.domain.System_SubAttributes;
import com.MES.domain.Systems;
import com.MES.domain.Technical_Info_Questions;
 
  @Service("userService")
public class DataServiceImpl implements DataService {   
  
 @Autowired  
 TablesDao userdao; 


 @Override  
 public List<StdBusinessProcess> getSBPList() {   
  return userdao.getSBPList();   
 }  
 @Override
 public List<Process_Details> getProcessDetails(){   
	  return userdao. getProcessDetails();   
	 } 
 @Override
 public List<SubBusinessProcess>  getSubBusinessProcess(int array[]){   
	  return userdao.getSubBusinessProcess(array);   
	 }

 @Override  
 public List<SubProcess>  getSubProcessList(int a) {   
  return userdao. getSubProcessList(a);   
 } 
 @Override  
 public List<HomeDetails> getUserList() {   
  return userdao.getUserList();   
 }   
  
 @Override  
 public void deleteData(String id,String active,int role,String company,String site) {   
  userdao.deleteData(id,active,role,company,site);   
     
 }   
  
 @Override  
 public HomeDetails getUser(String id) {   
  return userdao.getUser(id);   
 }   
  
 @Override  
 public void updateData(HomeDetails processDetails) {   
  userdao.updateData(processDetails);   
     
 }   
 @Override  
 public void insertData(HomeDetails processDetails,int role,String company,String site) {   
  userdao.insertData(processDetails,role,company,site);   
     
 }
@Override
public List<NewUser> getUserIDList() {
	return userdao.getUserIDList();
	
}
@Override
public NewUser getUserOfID(String userid) {
	return userdao.getUserOfID(userid);
}
@Override
public boolean setRole(String rolename,String userid) {
	
	return userdao.setRole(rolename,userid);
}  
@Override
public List<Role> getRoleList() {
	return userdao.getRoleList();
}
@Override
public List<StdBusinessProcess> getStandardProcessList(int[] array) {
	
	return userdao.getStandardProcessList(array);
}
@Override
public void insertRequirements(List<AssementmentForm> formValues) {
	userdao.insertRequirements(formValues);
	
}
@Override
public void saveInTemporary(String string, int[] array, String userid) {
	userdao.saveInTemporary(string,array,userid);
	
}
@Override
public void deleteFromTemporary(String userid) {
	userdao.deleteFromTemporary(userid);
	
}
@Override
public List<HomeDetails> getSavedProcess(String userid) {
	
	return userdao.getSavedProcess(userid);
}
@Override
public int checkForSubmittedAndSaved(String userId) {
	
	return userdao.checkForSubmittedAndSaved(userId);
}
@Override
public String validateID(String customerReqId) {
	
	return userdao.validateID(customerReqId);
}
@Override
public List<AssementmentForm> generateReport(String attribute) {
	
	return userdao.generateReport(attribute);
}
@Override
public List<AssementmentForm> getReqId(String userId) {
	
	return userdao.getReqId(userId);
}
@Override
public void generateReqID(String attribute, String userid,String company,String site) {
	userdao.generateReqID(attribute,userid,company,site);
	
}
@Override
public void editReport(AssementmentForm form) {
	userdao.editReport(form);
	
}
@Override
public void deleteReportDetails(String id, String subP) {
	userdao.deleteReportDetails(id,subP);
	
}
@Override
public List<Systems> getSystems(String company,String site) {
	return userdao.getSystems(company,site);
}
@Override
public void addNewSystem(Systems newSystem) {
	userdao.addNewSystem(newSystem);
	
}
@Override
public List<System_Attribute> getSystemAttributes() {
	return userdao.getSystemAttributes();
}
@Override
public List<System_SubAttributes> getSystemSubAttributes() {
	
	return userdao.getSystemSubAttributes();
}
@Override
public List<System_Details> getSystemEnteredDetails(int id) {
	return userdao.getSystemEnteredDetails(id);
}
@Override
public void insertSystemDetails(System_Details inserted_details) {
	userdao.insertSystemDetails(inserted_details);
	
}
@Override
public void deleteSystem(int parseInt) {
	userdao.deleteSystem(parseInt);
	
}
@Override
public void deleteSystemDetails(int parseInt) {
	userdao.deleteSystemDetails(parseInt);
	
}
@Override
public void updateSystemDetails(Systems updated_details) {
	userdao.updateSystemDetails(updated_details);
	
}
@Override
public int checkForSubmittedAndSavedRequirement(String userid) {
	
	return userdao.checkForSubmittedAndSavedRequirement(userid);
}
@Override
public String validateIDReq(String customerReqId) {
	return userdao.validateIDReq(customerReqId);
}
@Override
public void deleteSystemDetails1(int parseInt) {
	userdao.deleteSystemDetails1(parseInt);
	
}
@Override
public void changeSystemDetails(System_Details changeDetails) {
	userdao.changeSystemDetails(changeDetails);
	
}
@Override
public void deleteFromTemporaryReq(String userid) {
	userdao.deleteFromTemporaryReq(userid);
	
}
@Override
public void saveInTemporaryReq(String attribute,
		int[] selectedModulesRequirement, String userid) {
	userdao.saveInTemporaryReq(attribute,selectedModulesRequirement,userid);
	
}
@Override
public List<Process_Details> getProcessDetailsById(int sp_id) {
	return userdao.getProcessDetailsById(sp_id);
}
@Override
public void insertRequirementsGathering(List<RequirementFormDetails> formValues) {
	userdao.insertRequirementsGathering(formValues);
	
}
@Override
public List<RequirementFormDetails> getSavedDetails(String subProcessName,
		String attribute) {
	
	return userdao.getSavedDetails(subProcessName,attribute);
}
@Override
public List<HomeDetails> getSavedProcessReq(String userid) {
	
	return userdao.getSavedProcessReq(userid);
}
@Override
public List<RequirementFormDetails> getNumberOfEntries(String sbp_NAME,
		String attribute) {
	
	return userdao.getNumberOfEntries(sbp_NAME,attribute);
}
@Override
public void createReqID(String attribute, Login userid) {
	userdao.createReqID(attribute,userid);
	
}
@Override
public List<RequirementFormDetails> createReport(String attribute) {
	
	return userdao.createReport(attribute);
}
@Override
public List<RequirementFormDetails> getNumberOfEntriesList(String name,
		String sp_Name, String id) {
	
	return userdao.getNumberOfEntriesList(name,sp_Name,id);
}
@Override
public List<RequirementFormDetails> getReqIds(String userId) {
	return userdao.getReqIds(userId);
}
@Override
public List<Process_Details> getProcessDetailsTotal(int sbp_ID) {
	
	return userdao.getProcessDetailsTotal(sbp_ID);
}
@Override
public void clearConnections() {
	userdao.clearConnections();
	
}
@Override
public void addNewSubAtt(System_SubAttributes newSubAtt) {
	userdao.addNewSubAtt(newSubAtt);
	
}
@Override
public void addNewAtt(System_Attribute newAtt) {
	userdao.addNewAtt(newAtt);
	
}
@Override
public void updateAtt(System_Attribute updateAtt) {
	userdao.updateAtt(updateAtt);
	
}
@Override
public void updateSubAtt(System_SubAttributes updateSubAtt) {
	userdao.updateSubAtt(updateSubAtt);
	
}
@Override
public void delSubAtt(int subAttId, int active) {
	userdao.delSubAtt(subAttId,active);
	
}
@Override
public void delAtt(int attId, int active) {
	userdao.delAtt(attId,active);
	
}
@Override
public int getActiveProcessDetails() {
	return userdao.getActiveProcessDetails();
}
@Override
public int getRequirementDetailsFilled(String attribute) {
	
	return userdao.getRequirementDetailsFilled(attribute);
}
@Override
public void deletePreviousDetailsReq(String moduleName) {
	userdao.deletePreviousDetailsReq(moduleName);
	
}
@Override
public void deletePreviousDetailsMIA(String moduleName) {
	userdao.deletePreviousDetailsMIA(moduleName);
	
}
@Override
public void addSystemsToSubProcess(HomeDetails systemForm) {
	userdao.addSystemsToSubProcess(systemForm);
}
@Override
public void addSystemsToSBP(HomeDetails systemForm) {
	userdao.addSystemsToSBP(systemForm);
	
}
@Override
public List<SiteDetails> getListOfSites(int id) {
	
	return userdao.getListOfSites(id);
}
@Override
public List<CompanyDetails> getListOfCompanies() {

	return userdao.getListOfCompanies() ;
}
@Override
public List<Category> getDetailsCategory() {
	
	return userdao.getDetailsCategory();
}
@Override
public List<Supplier_Info_Questions> getInfoQues(int cat_id1) {
	
	return userdao.getInfoQues(cat_id1);
}
@Override
public List<Role> getSupDetails() {
	
	return userdao.getSupDetails();
}
@Override
public List<Ratings> getCategoryRatings(int cat_id1) {
	
	return userdao.getCategoryRatings(cat_id1);
}
@Override
public List<Supplier_Info_Questions> getSavedInfo(int cat_id1, String company) {
	
	return userdao.getSavedInfo(cat_id1, company);
}
@Override
public void insertInfo(List<Supplier_Info_Questions> response, String company) {
	userdao.insertInfo(response, company);
	
}
@Override
public List<Criteria_titles> getCriteriaTitles() {
	
	return userdao.getCriteriaTitles();
}
@Override
public List<Criteria_Details> getCriteria_details() {
	
	return userdao.getCriteria_details();
}
@Override
public List<RequirementFormDetails> getRequirementSavedProcess(String id) {
	
	return userdao.getRequirementSavedProcess(id);
}
@Override
public List<RequirementFormDetails> getSavedReqDetailFromStdP(String attribute,
		String std) {
	
	return userdao.getSavedReqDetailFromStdP(attribute,std);
}
@Override
public List<RequirementFormDetails> getNumberOfEntriesFromIDSBP(int sub,
		String attribute) {
	
	return userdao.getNumberOfEntriesFromIDSBP(sub,attribute);
}
@Override
public List<RequirementFormDetails> getNumberOfEntriesFromIdSP(int sp_id,
		String attribute) {
	
	return userdao.getNumberOfEntriesFromIdSP(sp_id,attribute);
}
@Override
public List<Ratings> getTechRatings(int i) {
	
	return userdao.getTechRatings(i);
}
@Override
public List<SupplierRatingDetails> getSavedSupplierRatings(int sp_id,
		String attribute) {
	
	return userdao.getSavedSupplierRatings(sp_id,attribute);
}
@Override
public void addSupplierRatingsCustomers(List<SupplierRatingDetails> save) {
	userdao.addSupplierRatingsCustomers(save);
	
}
@Override
public List<NewUser> getCustomerList() {
	
	return userdao.getCustomerList();
}

@Override
public List<Category> getTech_Category() {
	
	return userdao.getTech_Category();
}
@Override
public List<Category> getTech_sub_category(int cat_id1) {
	
	return userdao.getTech_sub_category(cat_id1);
}
@Override
public List<System_SubAttributes> getTech_Ques(int cat_id1) {
	
	return userdao.getTech_Ques(cat_id1);
}
@Override
public List<Category> getTechSubQues() {
	
	return userdao.getTechSubQues();
}
@Override
public List<Technical_Info_Questions> getSavedTecInfo(int cat_id1,
		String company,String site) {
	
	return userdao.getSavedTecInfo(cat_id1,company,site);
}
@Override
public void insertTechInfo(List<Technical_Info_Questions> response,
		String company) {
	userdao.insertTechInfo(response,company);
	
}

@Override
public List<Process_Details> getProcessDetailsByIdAll(int sp_id) {
	
	return userdao.getProcessDetailsByIdAll(sp_id);
}
@Override
public List<Process_Details> insertedByCustomers(int id,String company,String site) {
	
	return userdao.insertedByCustomers(id,company,site);
}
@Override
public void addSubCat(Role newSubCat) {
	userdao.addSubCat(newSubCat);
	
}
@Override
public void updateSubCat(Role newSubCat) {
	userdao.updateSubCat(newSubCat);
	
}
@Override
public void updateQues(Supplier_Info_Questions newQues) {
	userdao.updateQues(newQues);
	
}
@Override
public void addNewQues(Supplier_Info_Questions newQues) {
	userdao.addNewQues(newQues);
}
@Override
public void doActivation(String active, String quesid) {
	userdao.doActivation(active,quesid);
	
}
@Override
public void doSubactivation(String active, String cat_id, String subcat_id) {
	userdao.doSubactivation(active,cat_id,subcat_id);
	
}
@Override
public void addNewTechCat(Category newCat) {
	userdao.addNewTechCat(newCat);
	
}
@Override
public void doQuesActivation(String active, String ques_id, String subcat_id) {
	userdao.doQuesActivation(active,ques_id,subcat_id);
	
}
@Override
public void doSubQuesActivation(String active, String ques_id, String subcat_id) {
	userdao.doSubQuesActivation(active,ques_id,subcat_id);
	
}
@Override
public void updateTechQues(System_SubAttributes newQues) {
	userdao.updateTechQues(newQues);
	
}
@Override
public void updateTechSubQues(Category newSubQues) {
	userdao.updateTechSubQues(newSubQues);
	
}
@Override
public void addNewTechQues(System_SubAttributes newQues) {
	userdao.addNewTechQues(newQues);
	
}
@Override
public void addNewTechSubCat(Category newSubCat) {
	userdao.addNewTechSubCat(newSubCat);
	
}
@Override
public int getLastCount() {
	
	return userdao.getLastCount() ;
}
@Override
public void updateTechSubCat(Category newSubCat) {
	userdao.updateTechSubCat(newSubCat);
	
}
@Override
public void doSubCatActivation(String active, String subcat_id) {
userdao.doSubCatActivation(active,subcat_id);	
}
@Override
public void catActivation(String active, String cat_id1) {
	userdao.catActivation(active,cat_id1);
	
}
@Override
public String create(NewUser register) {
	return userdao.create(register);
}
@Override
public boolean validate(Login login) {
	return userdao.validate(login);
}
@Override
public List<RequirementsList> getSubmittedReqList() {
	
	return userdao.getSubmittedReqList();
}
@Override
public int getStdIdName(String userid) {
	return userdao.getStdIdName(userid);
}
@Override
public int getBusiProcessIdFromName(String company) {
	return userdao.getBusiProcessIdFromName(company);
}
@Override
public List<RequirementFormDetails> viewAllReqDetails(int i, int recordsPerPage,
		String searchTable) {
	return userdao.viewAllReqDetails(i,recordsPerPage,searchTable);
}
@Override
public int getNoOfRecordsValue() {
	return userdao.getNoOfRecordsValue();
}
@Override
public List<RequirementFormDetails> getRequirementsToExcel(String searchTable) {
	return userdao.getRequirementsToExcel(searchTable);
}
@Override
public Role checkModuleData(int processId) {
	return userdao.checkModuleData(processId);
}
@Override
public SupplierRatingDetails getSupplierRatingsScore(String string, int sbp_ID) {
	return userdao.getSupplierRatingsScore(string,sbp_ID);
}
@Override
public List<SubBusinessProcess> getSubBP() {
	return userdao.getSubBP();
}
@Override
public List<String> getSupplierList() {
	return userdao.getSupplierList();
}
@Override
public String formExists(String userid) {
	return userdao.formExists(userid);
}
@Override
public String formPresent(String userid) {
	return userdao.formPresent(userid);
}
@Override
public List<RequirementsList> getSubmittedMiaList() {
	return userdao.getSubmittedMiaList();
}
@Override
public List<String> viewAllMiaDetails(int i, int recordsPerPage,
		String searchMiaTable) {
	return userdao.viewAllMiaDetails(i,recordsPerPage,searchMiaTable);
}
@Override
public int getNoOfRecordsValueMia() {
	return userdao.getNoOfRecordsValueMia();
}
@Override
public List<String> getMiaToExcel(String searchMiaTable) {
	return userdao.getMiaToExcel(searchMiaTable);
}
@Override
public List<HomeDetails> getCustomerSystemList() {
	return userdao.getCustomerSystemList();
}
@Override
public List<Role> getAges(int[] systemsID, List<Systems> systems) {
	return userdao.getAges(systemsID,systems);
}
@Override
public List<Role> getUsers(int[] systemsID, List<Systems> systems) {
	return userdao.getUsers(systemsID,systems);
}
@Override
public List<Role> getPswdRecoveryQues() {
	return userdao.getPswdRecoveryQues();
}
@Override
public List<CompanyDetails> checkIdPresent(String userid) {
	return userdao.checkIdPresent(userid);
	
}
@Override
public String getSecretQuestion(int number) {
	
	return userdao.getSecretQuestion(number);
}
   
}  
