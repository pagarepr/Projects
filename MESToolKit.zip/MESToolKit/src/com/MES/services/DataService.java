package com.MES.services;   

import java.util.List;   
import com.MES.domain.AssementmentForm;
import com.MES.domain.Category;
import com.MES.domain.CompanyDetails;
import com.MES.domain.Criteria_Details;
import com.MES.domain.Criteria_titles;
import com.MES.domain.Login;
import com.MES.domain.NewUser;
import com.MES.domain.Process_Details;
import com.MES.domain.Ratings;
import com.MES.domain.RequirementFormDetails;
import com.MES.domain.RequirementsList;
import com.MES.domain.Role;
import com.MES.domain.SiteDetails;
import com.MES.domain.StdBusinessProcess;
import com.MES.domain.SubBusinessProcess;
import com.MES.domain.SubProcess;
import com.MES.domain.HomeDetails;
import com.MES.domain.SupplierRatingDetails;
import com.MES.domain.Supplier_Info_Questions;
import com.MES.domain.System_Attribute;
import com.MES.domain.System_Details;
import com.MES.domain.System_SubAttributes;
import com.MES.domain.Systems;
import com.MES.domain.Technical_Info_Questions;

public interface DataService {   

	public List<StdBusinessProcess> getSBPList();   
	public List<HomeDetails> getUserList();   
	public void deleteData(String id,String active,int role,String company,String site);   
	public HomeDetails getUser(String id);   
	public void updateData(HomeDetails processDetails);
	public List<SubProcess> getSubProcessList(int a); 
	public List<Process_Details> getProcessDetails();
	public void insertData(HomeDetails processDetails,int role,String company,String site);
	public List<NewUser> getUserIDList();
	public NewUser getUserOfID(String userid);
	public boolean setRole(String rolename,String userid);
	public List<Role> getRoleList(); 
	public List<SubBusinessProcess>  getSubBusinessProcess(int array[]);
	public List<StdBusinessProcess> getStandardProcessList(int[] array);
	public void insertRequirements(List<AssementmentForm> formValues);
	public void saveInTemporary(String string, int[] array, String userid);
	public void deleteFromTemporary(String userid);
	public List<HomeDetails> getSavedProcess(String userid);
	public int checkForSubmittedAndSaved(String userId);
	public String validateID(String customerReqId);
	public List<AssementmentForm> generateReport(String attribute);
	public List<AssementmentForm> getReqId(String userId);
	public void generateReqID(String attribute, String userid,String company,String site);
	public void editReport(AssementmentForm form);
	public void deleteReportDetails(String id, String subP);
	public List<Systems> getSystems(String string, String string2);
	public void addNewSystem(Systems newSystem);
	public List<System_Attribute> getSystemAttributes();
	public List<System_SubAttributes> getSystemSubAttributes();
	public List<System_Details> getSystemEnteredDetails(int i);
	public void insertSystemDetails(System_Details inserted_details);
	public void deleteSystem(int parseInt);
	public void deleteSystemDetails(int parseInt);
	public void updateSystemDetails(Systems updated_details);
	public int checkForSubmittedAndSavedRequirement(String userid);
	public String validateIDReq(String customerReqId);
	public void deleteSystemDetails1(int parseInt);
	public void changeSystemDetails(System_Details changeDetails);
	public void deleteFromTemporaryReq(String userid);
	public void saveInTemporaryReq(String attribute,
			int[] selectedModulesRequirement, String userid);
	public List<Process_Details> getProcessDetailsById(int sp_id);
	public void insertRequirementsGathering(
			List<RequirementFormDetails> formValues);
	public List<RequirementFormDetails> getSavedDetails(String subProcessName,
			String attribute);
	public List<HomeDetails> getSavedProcessReq(String userid);
	public List<RequirementFormDetails> getNumberOfEntries(
			String sbp_NAME, String attribute);
	public void createReqID(String attribute, Login userid);
	public List<RequirementFormDetails> createReport(String attribute);
	public List<RequirementFormDetails> getNumberOfEntriesList(String name,
			String sp_Name, String id);
	public List<RequirementFormDetails> getReqIds(String userId);
	public List<Process_Details> getProcessDetailsTotal(int sbp_ID);
	public void clearConnections();
	public void addNewSubAtt(System_SubAttributes newSubAtt);
	public void addNewAtt(System_Attribute newAtt);
	public void updateAtt(System_Attribute updateAtt);
	public void updateSubAtt(System_SubAttributes updateSubAtt);
	public void delSubAtt(int subAttId, int active);
	public void delAtt(int attId, int active);
	public int getActiveProcessDetails();
	public int getRequirementDetailsFilled(String attribute);
	public void deletePreviousDetailsReq(String moduleName);
	public void deletePreviousDetailsMIA(String moduleName);
	public void addSystemsToSubProcess(HomeDetails systemForm);
	public void addSystemsToSBP(HomeDetails systemForm);
	public List<SiteDetails> getListOfSites(int id);
	public List<CompanyDetails> getListOfCompanies();
	public List<Category> getDetailsCategory();
	public List<Supplier_Info_Questions> getInfoQues(int cat_id1);
	public List<Role> getSupDetails();
	public List<Ratings> getCategoryRatings(int cat_id1);
	public List<Supplier_Info_Questions> getSavedInfo(int cat_id1,
			String company);
	public void insertInfo(List<Supplier_Info_Questions> response,
			String company);
	public List<Criteria_titles> getCriteriaTitles();
	public List<Criteria_Details> getCriteria_details();
	public List<RequirementFormDetails> getRequirementSavedProcess(String id);
	public List<RequirementFormDetails> getSavedReqDetailFromStdP(
			String attribute, String std);
	public List<RequirementFormDetails> getNumberOfEntriesFromIDSBP(int sub,
			String attribute);
	public List<RequirementFormDetails> getNumberOfEntriesFromIdSP(int sp_id,
			String attribute);
	public List<Ratings> getTechRatings(int i);
	public List<SupplierRatingDetails> getSavedSupplierRatings(
			int sp_id, String attribute);
	public void addSupplierRatingsCustomers(List<SupplierRatingDetails> save);
	public List<NewUser> getCustomerList();
	public List<Category> getTech_Category();
	public List<Category> getTech_sub_category(int cat_id1);
	public List<System_SubAttributes> getTech_Ques(int cat_id1);
	public List<Category> getTechSubQues();
	public List<Technical_Info_Questions> getSavedTecInfo(int cat_id1,
			String company,String site);
	public void insertTechInfo(List<Technical_Info_Questions> response,
			String company);
	public List<Process_Details> getProcessDetailsByIdAll(int sp_id);
	public List<Process_Details> insertedByCustomers(int sp_id,String company,String site);
	public void addSubCat(Role newSubCat);
	public void updateSubCat(Role newSubCat);
	public void updateQues(Supplier_Info_Questions newQues);
	public void addNewQues(Supplier_Info_Questions newQues);
	public void doActivation(String active, String quesid);
	public void doSubactivation(String active, String cat_id, String subcat_id);
	public void addNewTechCat(Category newCat);
	public void doQuesActivation(String active, String ques_id, String subcat_id);
	public void doSubQuesActivation(String active, String ques_id,
			String subcat_id);
	public void updateTechQues(System_SubAttributes newQues);
	public void updateTechSubQues(Category newSubQues);
	public void addNewTechQues(System_SubAttributes newQues);
	public void addNewTechSubCat(Category newSubCat);
	public int getLastCount();
	public void updateTechSubCat(Category newSubCat);
	public void doSubCatActivation(String active, String subcat_id);
	public void catActivation(String active, String cat_id1);
	public String create(NewUser register);
	public boolean validate(Login login);
	public List<RequirementsList> getSubmittedReqList();
	public int getStdIdName(String userid);
	public int getBusiProcessIdFromName(String company);
	public List<RequirementFormDetails> viewAllReqDetails(int i,
			int recordsPerPage, String searchTable);
	public int getNoOfRecordsValue();
	public List<RequirementFormDetails> getRequirementsToExcel(
			String searchTable);
	public Role checkModuleData(int processId);
	public SupplierRatingDetails getSupplierRatingsScore(String string,
			int sbp_ID);
	public List<SubBusinessProcess> getSubBP();
	public List<String> getSupplierList();
	public String formExists(String userid);
	public String formPresent(String userid);
	public List<RequirementsList> getSubmittedMiaList();
	public List<String> viewAllMiaDetails(int i, int recordsPerPage,
			String searchMiaTable);
	public int getNoOfRecordsValueMia();
	public List<String> getMiaToExcel(String searchMiaTable);
	public List<HomeDetails> getCustomerSystemList();
	public List<Role> getAges(int[] systemsID, List<Systems> systems);
	public List<Role> getUsers(int[] systemsID, List<Systems> systems);
	public List<Role> getPswdRecoveryQues();
	public List<CompanyDetails> checkIdPresent(String userid);
	public String getSecretQuestion(int number);
	
}  
