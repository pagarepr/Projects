package com.MES.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.awt.Color;
import java.awt.Font;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.imageio.ImageIO;

import org.apache.log4j.Logger;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.labels.StandardCategoryToolTipGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.SpiderWebPlot;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.title.TextTitle;
import org.jfree.data.category.DefaultCategoryDataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.validation.ValidationUtils;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;   
import org.springframework.web.bind.annotation.RequestMapping;   
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;   
import org.springframework.web.servlet.ModelAndView;   
import org.springframework.web.servlet.view.RedirectView;

import com.MES.domain.Category;
import com.MES.domain.CompanyDetails;
import com.MES.domain.Criteria_Details;
import com.MES.domain.Criteria_titles;
import com.MES.domain.Login;
import com.MES.domain.LoginModel;
import com.MES.domain.NewUser;
import com.MES.domain.Process_Details;
import com.MES.domain.Ratings;
import com.MES.domain.RegisterModel;
import com.MES.domain.AssementmentForm;
import com.MES.domain.RequirementForm;
import com.MES.domain.RequirementFormDetails;
import com.MES.domain.RequirementsList;
import com.MES.domain.Role;
import com.MES.domain.SiteDetails;
import com.MES.domain.StdBusinessProcess;
import com.MES.domain.SubBusinessProcess;
import com.MES.domain.SubProcess;
import com.MES.domain.HomeDetails;
import com.MES.domain.SuplierRating;
import com.MES.domain.SupplierRatingDetails;
import com.MES.domain.Supplier_Customer;
import com.MES.domain.Supplier_Info_Questions;
import com.MES.domain.Supplier_Info_Response;
import com.MES.domain.System_Attribute;
import com.MES.domain.System_Details;
import com.MES.domain.System_SubAttributes;
import com.MES.domain.Systems;
import com.MES.domain.Technical_Info_Questions;
import com.MES.domain.Technical_Info_Response;
import com.MES.services.DataService;
import com.MES.services.PasswordSecurity;


@Controller
public class HomePageController{   

	int selectedModulesRequirement[]={1,2,3,4,5};
	int reqid=100;
	int percentageDone=0;
	List<String> stdProcess=new ArrayList<String>();
	 @Autowired
	 DataService userService;   
	 Login login;
	 NewUser register;
	 
	
	@RequestMapping("/showDetails")   
	public ModelAndView showDetails(@RequestParam String param,@RequestParam String id,@RequestParam String pageno,@RequestParam String module,@RequestParam String active,HttpServletRequest request,@ModelAttribute("processDetails") Process_Details processDetails,ModelMap model) throws Exception {
		LoginModel lgModel = new LoginModel();
		login = (Login)request.getSession().getAttribute("loggedIn");
		if(Integer.parseInt(id)>0)
			userService.deleteData(id,active,login.getRoleId(),login.getCompany(),login.getSite());
		if(login==null)
			return new ModelAndView("login", "loginDetails", new Login());
		lgModel.setLoginModel(login);
		model.addAttribute("lgModel",lgModel);
		int[] moduleDetails={Integer.parseInt(param)}; 
		List<StdBusinessProcess> standardProcesses=userService.getStandardProcessList(selectedModulesRequirement);
		List<SubBusinessProcess>SupPList= userService.getSubBusinessProcess(moduleDetails);
		List<SubProcess> details_List=null;
		List<Process_Details> process_details_list=null;
		model.addAttribute("standardProcesses",standardProcesses);
		model.addAttribute("expandOuterTree",Integer.parseInt(param));
		
		if(!SupPList.isEmpty())
		{	
			if(Integer.parseInt(pageno)==0)
			{	
				details_List = userService.getSubProcessList(SupPList.get(0).getSBP_ID());
				process_details_list=userService.getProcessDetailsByIdAll(details_List.get(0).getSP_id());
			}
			else
			{
				details_List = userService.getSubProcessList(Integer.parseInt(pageno));
				if(Integer.parseInt(module)==0)
				{
					process_details_list=userService.getProcessDetailsByIdAll(details_List.get(0).getSP_id());
				}
				else
					process_details_list=userService.getProcessDetailsByIdAll(Integer.parseInt(module));
			}
			Collections.sort(process_details_list, new Comparator<Process_Details>() {
		        @Override public int compare(Process_Details p1, Process_Details p2) {
		            return p1.getDetails_Id() - p2.getDetails_Id(); // Ascending
		        }});
			model.addAttribute("process_details_list", process_details_list);
			model.addAttribute("expandTree",details_List.get(0).getSBP_id() );
			model.addAttribute("expandInnerTree", process_details_list.get(0).getSP_Id());
			model.addAttribute("details", details_List);
			if(login.getRoleId()==5)
			{
				List<Process_Details> insertProcessByCustomers=userService.insertedByCustomers(process_details_list.get(0).getSP_Id(),login.getCompany(),login.getSite());
				if(insertProcessByCustomers.size()==0)
					insertProcessByCustomers=null;
				model.addAttribute("insertProcessByCustomers", insertProcessByCustomers);
			}
			
		}
		else
		{
			model.addAttribute("noValues", 0);
		}
		model.addAttribute("processDetails", new HomeDetails());
		return new ModelAndView("SBPDetails","TopList",SupPList);  
	}
	@RequestMapping("contactUs")   
	public ModelAndView contactUs(HttpServletResponse response,HttpServletRequest request,ModelMap model)
	{
		LoginModel lgModel = new LoginModel();
		login = (Login)request.getSession().getAttribute("loggedIn");
		if(login==null)
			return new ModelAndView("login", "loginDetails", new Login());
		lgModel.setLoginModel(login);
		model.addAttribute("lgModel",lgModel);
		return new ModelAndView("contactUS");
	}
	
	@RequestMapping("/showDetails1")   
	public ModelAndView showDetails1(@RequestParam String param,@RequestParam String id,@RequestParam String pageno,@RequestParam String module,@RequestParam String active,HttpServletRequest request,@ModelAttribute("processDetails") Process_Details processDetails,ModelMap model) throws Exception {
		LoginModel lgModel = new LoginModel();
		login = (Login)request.getSession().getAttribute("loggedIn");
		if(Integer.parseInt(id)>0)
			userService.deleteData(id,active,login.getRoleId(),login.getCompany(),login.getSite());
		if(login==null)
			return new ModelAndView("login", "loginDetails", new Login());
		lgModel.setLoginModel(login);
		model.addAttribute("lgModel",lgModel);
		int[] moduleDetails={Integer.parseInt(param)}; 
		List<StdBusinessProcess> standardProcesses=userService.getStandardProcessList(selectedModulesRequirement);
		List<SubBusinessProcess>SupPList= userService.getSubBusinessProcess(moduleDetails);
		List<SubProcess> details_List=null;
		List<Process_Details> process_details_list=null;
		model.addAttribute("standardProcesses",standardProcesses);
		model.addAttribute("expandOuterTree",Integer.parseInt(param));
		
		if(!SupPList.isEmpty())
		{	
			if(Integer.parseInt(pageno)==0)
			{	
				details_List = userService.getSubProcessList(SupPList.get(0).getSBP_ID());
				process_details_list=userService.getProcessDetailsByIdAll(details_List.get(0).getSP_id());
			}
			else
			{
				details_List = userService.getSubProcessList(Integer.parseInt(pageno));
				if(Integer.parseInt(module)==0)
				{
					process_details_list=userService.getProcessDetailsByIdAll(details_List.get(0).getSP_id());
				}
				else
					process_details_list=userService.getProcessDetailsByIdAll(Integer.parseInt(module));
			}
			Collections.sort(process_details_list, new Comparator<Process_Details>() {
		        @Override public int compare(Process_Details p1, Process_Details p2) {
		            return p1.getDetails_Id() - p2.getDetails_Id(); // Ascending
		        }});
			model.addAttribute("process_details_list", process_details_list);
			model.addAttribute("expandTree",details_List.get(0).getSBP_id() );
			model.addAttribute("expandInnerTree", process_details_list.get(0).getSP_Id());
			model.addAttribute("details", details_List);
			if(login.getRoleId()==5)
			{
				List<Process_Details> insertProcessByCustomers=userService.insertedByCustomers(process_details_list.get(0).getSP_Id(),login.getCompany(),login.getSite());
				if(insertProcessByCustomers.size()==0)
					insertProcessByCustomers=null;
				model.addAttribute("insertProcessByCustomers", insertProcessByCustomers);
			}
			
		}
		else
		{
			model.addAttribute("noValues", 0);
		}
		model.addAttribute("processDetails", new HomeDetails());
		return new ModelAndView("SBPEditDetails","TopList",SupPList);  
	}
	
	@RequestMapping("/update")   
	public String updateDetail(HttpServletRequest request,@ModelAttribute("processDetails") HomeDetails processDetails,ModelMap model)  throws Exception{
		login = (Login)request.getSession().getAttribute("loggedIn");
		userService.updateData(processDetails);   
		return "redirect:"+processDetails.getDescription(); 
	}
	
	@RequestMapping("/insert")   
	public String insertDetails(@ModelAttribute("processDetails") HomeDetails processDetails,HttpServletRequest request,ModelMap model) throws Exception{
		login = (Login)request.getSession().getAttribute("loggedIn");
		userService.insertData(processDetails,login.getRoleId(),login.getCompany(),login.getSite()); 
		return "redirect:"+processDetails.getDescription(); 
	}
	
	   
	@RequestMapping("/systemDetails")   
	public ModelAndView getSystemDetails(@RequestParam String system_id,HttpServletRequest request,Model model)  throws Exception{
		LoginModel lgModel = new LoginModel();
		login = (Login)request.getSession().getAttribute("loggedIn");
		if(login==null)
			return new ModelAndView("login", "loginDetails", new Login());
		lgModel.setLoginModel(login);
		model.addAttribute("lgModel",lgModel);
		List<Systems> systems = userService.getSystems(login.getCompany(),login.getSite());
		List<System_Attribute> system_details=userService.getSystemAttributes();
		List<System_SubAttributes> system_subDetails=userService.getSystemSubAttributes();
		List<System_Details> system_EnteredDetails=userService.getSystemEnteredDetails(Integer.parseInt(system_id));
		model.addAttribute("system_id",Integer.parseInt(system_id));
		model.addAttribute("update", new Systems());
		model.addAttribute("systems",systems);
		model.addAttribute("system_EnteredDetails",system_EnteredDetails);
		model.addAttribute("system_details", system_details);
		model.addAttribute("system_subDetails", system_subDetails);
		model.addAttribute("inserted_details", new System_Details());
		model.addAttribute("changeSystemDetails",new System_Details() ); 
		return new ModelAndView("SystemDetails");   
	}    
	
	@RequestMapping(value="/updateSystemDetails", method = RequestMethod.POST)   
	public ModelAndView updateSystemDetails(@RequestParam String system_id,HttpServletRequest request,Model model,@ModelAttribute("update") Systems updated_details)  throws Exception{
		userService.updateSystemDetails(updated_details);
		return new ModelAndView("redirect:systemDetails?system_id="+system_id);   
	}  
	@RequestMapping(value="/insertSystemDetails", method = RequestMethod.GET)   
	public ModelAndView getInsertSystemDetails(HttpServletRequest request,Model model,@ModelAttribute("inserted_details") System_Details inserted_details)  throws Exception{
		if(inserted_details.getDetails()!=""){
		userService.insertSystemDetails(inserted_details);
		
		}return new ModelAndView("redirect:systemDetails?system_id="+inserted_details.getSys_ID());   
	}   
	@RequestMapping(value="/success1", method = RequestMethod.GET)
	public ModelAndView init(HttpServletRequest request, HttpServletResponse response,ModelMap model) throws Exception 
	{
		LoginModel lgModel = new LoginModel();
		login =(Login)request.getSession().getAttribute("loggedIn");
		if(login==null)
			return new ModelAndView("login", "loginDetails", new Login());
		lgModel.setLoginModel(login);
		LoginModel newuser=new LoginModel();
		newuser.setLoginModel(login); 
		List<HomeDetails> userList = userService.getUserList();  
		Collections.sort(userList, new Comparator<HomeDetails>() {
	        @Override public int compare(HomeDetails p1, HomeDetails p2) {
	            return p1.getModuleid() - p2.getModuleid(); // Ascending
	        }});
		model.addAttribute("userList", userList);
		return new ModelAndView("home", "lgModel", lgModel);
	}
	
	@RequestMapping(value="/success", method = RequestMethod.GET)
	public ModelAndView init1(HttpServletRequest request, HttpServletResponse response)  throws Exception
	{
		RegisterModel rgModel = new RegisterModel();
		register = (NewUser)request.getSession().getAttribute("registered");
		rgModel.setRegisterModel(register);
		return new ModelAndView("success", "rgModel", rgModel);
	}
	
	@RequestMapping(value="/logout", method = RequestMethod.GET)
	public ModelAndView logout(HttpServletRequest request, HttpServletResponse response)  throws Exception
	{
		//request.getSession().setAttribute("loggedIn",null);
		request.getSession().invalidate();
		response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
		response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
		response.setDateHeader("Expires", 0); // Proxies.
		login = new Login();
		return new ModelAndView("login", "loginDetails", login);
	}
	
	@RequestMapping("MIA_Modules")   
	public ModelAndView getMIA_Modules(HttpServletRequest request,Model model) throws Exception {
		login = (Login)request.getSession().getAttribute("loggedIn");
		if(login==null)
			return new ModelAndView("login", "loginDetails", new Login());
		String company = login.getCompany();
		String customerReqId =null;
		String check=userService.formPresent(login.getUserid());
		if(!check.equals("no"))
		{
			customerReqId = check;
		}
		else{
			customerReqId = company.toUpperCase().substring(0, 3)+Long.toString(reqid);
			customerReqId = userService.validateID(customerReqId);
		}
		request.getSession().setAttribute("reqId", customerReqId);
		return new ModelAndView("redirect:businessProcessMapping?module=1&pageno=0&saved=0&det=0");   
	}    
	@RequestMapping("businessProcessMapping")   
	public ModelAndView getBusinessProcessMapping(@RequestParam String det,@RequestParam String module,@RequestParam String pageno,@RequestParam String saved,@ModelAttribute("reqDetails")StdBusinessProcess sbp,BindingResult bindingResult,HttpServletRequest request,ModelMap	model,HttpServletResponse response)  throws Exception{
		userService.clearConnections();
		LoginModel lgModel = new LoginModel();
		login = (Login)request.getSession().getAttribute("loggedIn");
		if(login==null)
			return new ModelAndView("login", "loginDetails", new Login());
		lgModel.setLoginModel(login);
		model.addAttribute("lgModel",lgModel);
		int[] moduleDetails={Integer.parseInt(module)};
		List<StdBusinessProcess> standardProcesses=userService.getStandardProcessList(selectedModulesRequirement);
		List<SubBusinessProcess>SupPList= userService.getSubBusinessProcess(moduleDetails);
		List<SubProcess> details_List=null;
		model.addAttribute("standardProcesses",standardProcesses);
		model.addAttribute("expandOuterTree",Integer.parseInt(module));
		int pagenumber=0;	
		if(!SupPList.isEmpty())
		{	
			
			if(saved.equals("1"))
			{
				model.addAttribute("pageNo",SupPList.get(0).getSBP_ID());
				model.addAttribute("moduleNo",standardProcesses.get(0).getProcessId());
				details_List = userService.getSubProcessList(SupPList.get(0).getSBP_ID());
				pagenumber=SupPList.get(0).getSBP_ID();
			}
			else if(Integer.parseInt(pageno)==0)
			{	
				userService.deleteFromTemporary(login.getUserid());
				userService.saveInTemporary((String)request.getSession().getAttribute("reqId"),selectedModulesRequirement,login.getUserid());
				details_List = userService.getSubProcessList(SupPList.get(0).getSBP_ID());
				model.addAttribute("pageNo",SupPList.get(0).getSBP_ID());
				model.addAttribute("moduleNo",Integer.parseInt(module));
				pagenumber=SupPList.get(0).getSBP_ID();
			}
			else
			{
				
				model.addAttribute("moduleNo",Integer.parseInt(module));
				if(Integer.parseInt(pageno)==1)
				{
					details_List = userService.getSubProcessList(SupPList.get(0).getSBP_ID());
				}
				else
					details_List = userService.getSubProcessList(Integer.parseInt(pageno));
				model.addAttribute("pageNo",details_List.get(0).getSBP_id());
				pagenumber=details_List.get(0).getSBP_id();
			}
			
			model.addAttribute("expandTree",details_List.get(0).getSBP_id() );
			model.addAttribute("details", details_List);
			List<AssementmentForm> report=userService.generateReport((String)request.getSession().getAttribute("reqId"));
			model.addAttribute("savedList", report);
			
			
		}
		else
		{
			model.addAttribute("noValues", 0);
		}
		model.addAttribute("form", new AssementmentForm());
		List<Systems> systems = userService.getSystems(login.getCompany(),login.getSite());
		model.addAttribute("systems",systems);
		if(saved.equals("2"))
		{	model.addAttribute("innerSystemsDisplay",2);
			for(SubBusinessProcess subProcess:SupPList)
			{
				if(subProcess.getSBP_ID()==pagenumber)
				{
					model.addAttribute("SubProcessName",subProcess.getSBP_NAME());
				}
			}
			for(StdBusinessProcess process:standardProcesses)
			{
				if(process.getProcessId()==Integer.parseInt(module))
				{
					model.addAttribute("ProcessName",process.getProcessName());
				}
			}
		}
		if(saved.equals("3"))
		{
			model.addAttribute("innerSystemsDisplay",1);
			List<Systems> systems1 = userService.getSystems(login.getCompany(),login.getSite());
			model.addAttribute("systems",systems1);
			model.addAttribute("id",Integer.parseInt(module));
			for(StdBusinessProcess process:standardProcesses)
			{
				if(process.getProcessId()==Integer.parseInt(module))
				{
					model.addAttribute("ProcessName",process.getProcessName());
				}
			}
		}
		if(Integer.parseInt(det)!=0)
		{
			model.addAttribute("det",Integer.parseInt(det));
			model.addAttribute("show", 1);
		}
		
		return new ModelAndView("businessProcessMapping", "TopList",SupPList);  
	} 
	@RequestMapping("addSystemsToSubProcess")
	public ModelAndView addSystemsToSubProcess(@RequestParam String name,@RequestParam String id,@RequestParam String sys,@ModelAttribute("systemForm")HomeDetails systemForm,@RequestParam String module,HttpServletRequest request,@RequestParam String pageno)  throws Exception
	{
		systemForm.setLink((String)request.getSession().getAttribute("reqId"));
		systemForm.setModuleid(Integer.parseInt(id));
		systemForm.setModuleName(name);
		systemForm.setDescription(sys);
		userService.addSystemsToSubProcess(systemForm);	
		return new ModelAndView("redirect:businessProcessMapping?module="+module+"&pageno="+pageno+"&saved=0&det=0"); 
		
	} 
	
	@RequestMapping("addSystemsToSBP")
	public ModelAndView addSystemsToSBP(@RequestParam String name,@RequestParam String sys,@ModelAttribute("systemForm")HomeDetails systemForm,@RequestParam String module,HttpServletRequest request)  throws Exception
	{
		systemForm.setLink((String)request.getSession().getAttribute("reqId"));
		
		systemForm.setModuleName(name);
		systemForm.setDescription(sys);
		userService.addSystemsToSBP(systemForm);	
		return new ModelAndView("redirect:businessProcessMapping?module="+module+"&pageno=0&saved=0&det=0"); 
		
	} 
	@RequestMapping("savedForm")
	public ModelAndView savedForm(@RequestParam String module,HttpServletRequest request,@RequestParam String pageno) throws Exception
	{
		login = (Login)request.getSession().getAttribute("loggedIn");
		List<HomeDetails> standardProcessSaved=userService.getSavedProcess(login.getUserid());
		request.getSession().setAttribute("reqId",standardProcessSaved.get(0).getModuleName());
		String[] processSaved=(standardProcessSaved.get(0).getDescription()).split(",");
		int[] arrayList=new int[processSaved.length];
		for(int length=0;length<processSaved.length;length++)
		{
			arrayList[length]=Integer.parseInt(processSaved[length]);
		}
		selectedModulesRequirement=arrayList;
		return new ModelAndView("redirect:businessProcessMapping?module=1&pageno=0&saved=1&det=0"); 
		
	} 
	@RequestMapping("MIA_Page_Start")
	public ModelAndView viewSystems(HttpServletRequest request,HttpServletResponse response,ModelMap model) throws Exception
	{
		LoginModel lgModel = new LoginModel();
		login = (Login)request.getSession().getAttribute("loggedIn");
		if(login==null)
			return new ModelAndView("login", "loginDetails", new Login());
		lgModel.setLoginModel(login);
		model.addAttribute("lgModel",lgModel);
		model.addAttribute("tab", 1);
		model.addAttribute("system", new Systems());
		List<Systems> systems = userService.getSystems(login.getCompany(),login.getSite());
		Collections.sort(systems, new Comparator<Systems>() {
	        @Override public int compare(Systems p1, Systems p2) {
	            return p1.getSys_ID() - p2.getSys_ID(); // Ascending
	        }});
		return new ModelAndView("MIA_Page","systems",systems);
	}
//	@RequestMapping("MIA_Page")
//	public ModelAndView viewOptions(HttpServletRequest request,HttpServletResponse response,ModelMap model) throws Exception
//	{
//		LoginModel lgModel = new LoginModel();
//		login = (Login)request.getSession().getAttribute("loggedIn");
//		if(login==null)
//			return new ModelAndView("login", "loginDetails", new Login());
//		lgModel.setLoginModel(login);
//		model.addAttribute("lgModel",lgModel);
//		//String userId = login.getUserid();
//		//int count =userService.checkForSubmittedAndSaved(userId);
//		model.addAttribute("system", new Systems());
////		model.addAttribute("tab", 2);
////		if(count>0)
////		{
////			Login noOfButtons = new Login();
////			noOfButtons.setRoleId(count);
////			return new ModelAndView("MIA_Page","buttons",noOfButtons);
////		}
//		return new ModelAndView("redirect:MIA_Modules");
//	}
	@RequestMapping("MIA_Page1")
	public ModelAndView enterReqID(HttpServletRequest request,HttpServletResponse response,ModelMap model) throws Exception
	{
		LoginModel lgModel = new LoginModel();
		login = (Login)request.getSession().getAttribute("loggedIn");
		if(login==null)
			return new ModelAndView("login", "loginDetails", new Login());
		lgModel.setLoginModel(login);
		model.addAttribute("lgModel",lgModel);
		String userId = login.getUserid();
		List<AssementmentForm> reqIDList = userService.getReqId(userId);
		model.addAttribute("selectedReqID",new AssementmentForm());
		model.addAttribute("tab",2);
		return new ModelAndView("MIA_Page","reqIDList",reqIDList);
	}  
	@RequestMapping("next")   
	public ModelAndView getReqGather(@ModelAttribute("form")AssementmentForm form,@RequestParam String module,@RequestParam String pageno,HttpServletRequest request) throws Exception {
		
		saveProcessDetails(form,(String)request.getSession().getAttribute("reqId") );
		return new ModelAndView("redirect:businessProcessMapping?module="+module+"&pageno="+(Integer.parseInt(pageno)+1)+"&saved=0&det=0");  
	} 
	@RequestMapping("previous")   
	public ModelAndView getReqGather1(@ModelAttribute("form")AssementmentForm form,@RequestParam String module,@RequestParam String pageno,HttpServletRequest request) throws Exception {
		
		
		saveProcessDetails(form,(String)request.getSession().getAttribute("reqId") );
		return new ModelAndView("redirect:businessProcessMapping?module="+module+"&pageno="+(Integer.parseInt(pageno)-1)+"&saved=0&det=0");  
	} 
	@RequestMapping("insertSystems")
	public ModelAndView saveRequirements(@RequestParam String module,@RequestParam String pageno,@ModelAttribute("form")AssementmentForm form,BindingResult bindingResult,HttpServletRequest request,ModelMap	model,HttpServletResponse response) throws Exception
	{
		saveProcessDetails(form,(String)request.getSession().getAttribute("reqId") );
		return new ModelAndView("redirect:businessProcessMapping?module="+module+"&pageno="+pageno+"&saved=0&det=0"); 
		
	} 
	
	public void saveProcessDetails(AssementmentForm form,String reqId)  throws Exception
	{
		int[] arraycheck = form.getElements();
		if (arraycheck!=null)
		{
		String[] array1 =form.getExistingSystem();
		String[] array2=form.getSubProcessSystems();
		int[] id=form.getId();
		List<AssementmentForm> formValues=new ArrayList<AssementmentForm>();
		for(int i=0;i<arraycheck.length;i++)
		{
			AssementmentForm newForm=new AssementmentForm();
			newForm.setReqID(reqId);
			newForm.setStdProcess(form.getStdProcess());
			newForm.setSp_id((id[arraycheck[i]]));
			newForm.setExistingSystemEntered(array1[arraycheck[i]]);
			newForm.setSubProcess(array2[arraycheck[i]]);
			formValues.add(newForm);
		}
		userService.insertRequirements(formValues);
		}
	}
	@RequestMapping("addSystems")
	public ModelAndView addSystems(@RequestParam String det,@ModelAttribute("form")AssementmentForm form,@RequestParam String module,@RequestParam String pageno,@RequestParam String saved,@ModelAttribute("reqDetails")StdBusinessProcess sbp,BindingResult bindingResult,HttpServletRequest request,ModelMap model,HttpServletResponse response)  throws Exception
	{
		saveProcessDetails(form,(String)request.getSession().getAttribute("reqId") );
		return new ModelAndView("redirect:businessProcessMapping?module="+module+"&pageno="+pageno+"&saved=0&det="+Integer.parseInt(det));
	}
	
	
	@RequestMapping(value="/underConstruction")
	 public ModelAndView init2(HttpServletRequest request,ModelMap model, HttpServletResponse response)  throws Exception
	 {
		LoginModel lgModel = new LoginModel();
		login = (Login)request.getSession().getAttribute("loggedIn");
		if(login==null)
			return new ModelAndView("login", "loginDetails", new Login());
		lgModel.setLoginModel(login);
		model.addAttribute("lgModel",lgModel);
	 	return new ModelAndView("underConstruction");
	 }   
	@RequestMapping("deleteSystem")
	public ModelAndView deleteSystem(@RequestParam String id,HttpServletRequest request,HttpServletResponse response,ModelMap model)  throws Exception
	{
		userService.deleteSystem(Integer.parseInt(id));
		userService.deleteSystemDetails(Integer.parseInt(id));
		return new ModelAndView("redirect:MIA_Page_Start");
	}
	
	@RequestMapping("addAttributesPage")
	public ModelAndView addingAttributes(HttpServletRequest request, HttpServletResponse response,ModelMap model)  throws Exception
	{
		LoginModel lgModel = new LoginModel();
		login = (Login)request.getSession().getAttribute("loggedIn");
		if(login==null)
			return new ModelAndView("login", "loginDetails", new Login());
		lgModel.setLoginModel(login);
		model.addAttribute("lgModel",lgModel);
		List<System_Attribute> system_details=userService.getSystemAttributes();
		List<System_SubAttributes> system_subDetails=userService.getSystemSubAttributes();
		model.addAttribute("system_details", system_details);
		model.addAttribute("system_subDetails", system_subDetails);
		model.addAttribute("subAtt", new System_SubAttributes());
		model.addAttribute("att", new System_Attribute());
		return new ModelAndView("AddAttributesPage");

	}

	@RequestMapping("addSub")
	public ModelAndView addsubAtt(@ModelAttribute("subAtt") System_SubAttributes newSubAtt,ModelMap model) throws Exception
	{
		if(!newSubAtt.getSubAttribute_name().equals(""))
		userService.addNewSubAtt(newSubAtt);
		return new ModelAndView("redirect:addAttributesPage");	
	}

	@RequestMapping("addAtt")
	public ModelAndView addAtt(@ModelAttribute("att") System_Attribute newAtt,ModelMap model) throws Exception
	{
		if(!newAtt.getAttribute_name().equals(""))
		userService.addNewAtt(newAtt);
		return new ModelAndView("redirect:addAttributesPage");
	}
	@RequestMapping("updateAtt")
	public ModelAndView updateAtt(@ModelAttribute("att") System_Attribute updateAtt,ModelMap model) throws Exception
	{
		userService.updateAtt(updateAtt);
		return  new ModelAndView("redirect:addAttributesPage");
	}

	@RequestMapping("updateSubAtt")
	public ModelAndView updateSubAtt(@ModelAttribute("att") System_SubAttributes updateSubAtt,ModelMap model) throws Exception
	{
		userService.updateSubAtt(updateSubAtt);
		return  new ModelAndView("redirect:addAttributesPage");
	}

	@RequestMapping("delSubAtt")
	public ModelAndView delSubAtt(@RequestParam int subAttId,@RequestParam int active) throws Exception
	{
		userService.delSubAtt(subAttId,active);
		return  new ModelAndView("redirect:addAttributesPage");
	}

	@RequestMapping("delAtt")
	public ModelAndView delAtt(@RequestParam int AttId,@RequestParam int active) throws Exception
	{
		userService.delAtt(AttId,active);
		return  new ModelAndView("redirect:addAttributesPage");
	} 
	@RequestMapping("Requirement_Page")
	public ModelAndView Requirement_Page_Options(HttpServletRequest request,HttpServletResponse response,ModelMap model) throws Exception
	{
		LoginModel lgModel = new LoginModel();
		login = (Login)request.getSession().getAttribute("loggedIn");
		if(login==null)
			return new ModelAndView("login", "loginDetails", new Login());
		lgModel.setLoginModel(login);
		model.addAttribute("lgModel",lgModel);
		int count =userService.checkForSubmittedAndSavedRequirement(login.getUserid());
		if(count>0)
		{
			Login noOfButtons = new Login();
			noOfButtons.setRoleId(count);
			return new ModelAndView("Requirement_Page","buttons",noOfButtons);
		}
		else 
			{
			return new ModelAndView("redirect:Requirement_Modules");}
	}
	@RequestMapping("Requirement_Modules")   
	public ModelAndView getRequirement_Modules(HttpServletRequest request)  throws Exception{
		login = (Login)request.getSession().getAttribute("loggedIn");
		String customerReqId= null;
		String company = login.getCompany();
		String check= userService.formExists(login.getUserid());
		if(!check.equals("no"))
		{
			customerReqId = check;
		}
		else{
			customerReqId = company.toUpperCase().substring(0, 3)+Long.toString(reqid);
			customerReqId = userService.validateIDReq(customerReqId);
		}

		request.getSession().setAttribute("reqId_Gathering", customerReqId);

		return new ModelAndView("redirect:RequirementGathering?stdp=1&module=0&pageno=0&saved=0");   
	}   
	
	
	List<Integer> totalQuestions=new ArrayList<Integer>();
	@RequestMapping("RequirementGathering")   
	public ModelAndView getRequirementGathering(@RequestParam String stdp,@RequestParam String module,@RequestParam String pageno,@RequestParam String saved,@ModelAttribute("reqDetails")StdBusinessProcess sbp,BindingResult bindingResult,HttpServletRequest request,ModelMap	model,HttpServletResponse response) throws Exception {
		userService.clearConnections();
		LoginModel lgModel = new LoginModel();
		login = (Login)request.getSession().getAttribute("loggedIn");
		if(login==null)
			return new ModelAndView("login", "loginDetails", new Login());
		lgModel.setLoginModel(login);
		model.addAttribute("lgModel",lgModel);
		int[] moduleDetails={Integer.parseInt(stdp)};
		List<StdBusinessProcess> standardProcesses=userService.getStandardProcessList(selectedModulesRequirement);
		List<SubBusinessProcess>SupPList= userService.getSubBusinessProcess(moduleDetails);
		List<SubProcess> details_List=null;
		List<Process_Details> process_details_list=null;
		model.addAttribute("standardProcesses",standardProcesses);
		model.addAttribute("expandOuterTree",Integer.parseInt(stdp));
		if(!SupPList.isEmpty())
		{	
			int totalActiveProcessDetails=userService.getActiveProcessDetails();
			if(saved.equals("1"))
			{
				
				details_List = userService.getSubProcessList(SupPList.get(0).getSBP_ID());
				process_details_list=userService.getProcessDetailsByIdAll(details_List.get(0).getSP_id());
				totalQuestions=getTotalNoOfQuestions(SupPList);
			}
			else if(Integer.parseInt(pageno)==0)
			{	
				userService.deleteFromTemporaryReq(login.getUserid());
				userService.saveInTemporaryReq((String)request.getSession().getAttribute("reqId_Gathering"),selectedModulesRequirement,login.getUserid());
				
				details_List = userService.getSubProcessList(SupPList.get(0).getSBP_ID());
				process_details_list=userService.getProcessDetailsByIdAll(details_List.get(0).getSP_id());
				totalQuestions=getTotalNoOfQuestions(SupPList);
			}
			else
			{
				details_List = userService.getSubProcessList(Integer.parseInt(pageno));
				if(Integer.parseInt(module)==1)
				{
					process_details_list=userService.getProcessDetailsByIdAll(details_List.get(0).getSP_id());
				}
				else
					process_details_list=userService.getProcessDetailsByIdAll(Integer.parseInt(module));
			}
			
			String SubProcessName=null;
			for(SubProcess checkingIfDataPresent:details_List)
			{
				if(process_details_list.get(0).getSP_Id()==checkingIfDataPresent.getSP_id())
				{
					SubProcessName=checkingIfDataPresent.getSP_Name();
					break;
				}
			}
			ArrayList<Integer> totalInnerQuestions=innerQuestions(details_List);
			List<RequirementFormDetails> savedProcess=userService.getSavedDetails(SubProcessName,(String)request.getSession().getAttribute("reqId_Gathering"));
			model.addAttribute("savedProcess", savedProcess);
			if(process_details_list.size()==0)
				process_details_list=null;
			model.addAttribute("process_details_list", process_details_list);
			model.addAttribute("expandTree",details_List.get(0).getSBP_id() );
			model.addAttribute("expandInnerTree", process_details_list.get(0).getSP_Id());
			ArrayList<Integer> completedListPercent=checkCompletedList(SupPList,(String)request.getSession().getAttribute("reqId_Gathering"));
			String subProcessName=null;
			for(SubBusinessProcess toplist:SupPList)
			{
				if(details_List.get(0).getSBP_id()==toplist.getSBP_ID())
				{	subProcessName=toplist.getSBP_NAME();
					break;
				}
			}
			ArrayList<Integer> completedInnerListPercent=checkCompletedListInner(subProcessName,details_List,(String)request.getSession().getAttribute("reqId_Gathering"));
			
			for(int loop=0;loop<details_List.size();loop++)
			{
				SubProcess objectValue=details_List.get(loop);
				objectValue.setPercentageCompleted((int)((float)completedInnerListPercent.get(loop)/(float)totalInnerQuestions.get(loop)*(float)100));
				details_List.set(loop,objectValue);
			}
			
			for(int loop=0;loop<SupPList.size();loop++)
			{
				SubBusinessProcess objectValue=SupPList.get(loop);
				objectValue.setPercentageCompleted((int)((float)completedListPercent.get(loop)/(float)totalQuestions.get(loop)*(float)100));
				SupPList.set(loop,objectValue);
			}
			int numberOfdetailsFilled=userService.getRequirementDetailsFilled((String)request.getSession().getAttribute("reqId_Gathering"));
			percentageDone=numberOfdetailsFilled*100/totalActiveProcessDetails;
			
			model.addAttribute("details", details_List);
			
		}
		else
		{
			model.addAttribute("noValues", 0);
		}
		model.addAttribute("percentageDone",percentageDone);
		model.addAttribute("ratings", userService.getTechRatings(1));
		model.addAttribute("form", new RequirementForm());
		return new ModelAndView("RequirementGathering", "TopList",SupPList);  
	}
	public ArrayList<Integer> innerQuestions(List<SubProcess> detail_List)  throws Exception
	{
		ArrayList<Integer> totalInnerQuestions=new ArrayList<Integer>();
		for(int i=0;i<detail_List.size();i++)
		{
			int questions=0;
			List<Process_Details> process_details_list=userService.getProcessDetailsById(detail_List.get(i).getSP_id());
			questions+=process_details_list.size();
			totalInnerQuestions.add(questions);
		}
		return totalInnerQuestions;
	}
	
	public ArrayList<Integer> checkCompletedListInner(String name,List<SubProcess> detail_List,String id) throws Exception
	{
		ArrayList<Integer> completedListPercent=new ArrayList<Integer>();
		for(SubProcess toplist:detail_List)
		{
			List<RequirementFormDetails> completedValueDetails=userService.getNumberOfEntriesList(name,toplist.getSP_Name(),id);
			completedListPercent.add(completedValueDetails.size());
		}
		return completedListPercent;
	}
	public ArrayList<Integer> checkCompletedList(List<SubBusinessProcess> SupPList,String id) throws Exception
	{
		ArrayList<Integer> completedListPercent=new ArrayList<Integer>();
		for(SubBusinessProcess toplist:SupPList)
		{
			List<RequirementFormDetails> completedValueDetails=userService.getNumberOfEntries(toplist.getSBP_NAME(),id);
			completedListPercent.add(completedValueDetails.size());
		}
		return completedListPercent;
	}
	public ArrayList<Integer> getTotalNoOfQuestions(List<SubBusinessProcess> SupPList) throws Exception
	{
		ArrayList<Integer> numberOfquestions=new ArrayList<Integer>();
		for(SubBusinessProcess toplist:SupPList)
		{
			int questions=(userService.getProcessDetailsTotal(toplist.getSBP_ID())).size();
			
			numberOfquestions.add(questions);
		}
		
		return numberOfquestions;
	}
	@RequestMapping("getIDs")
	 public ModelAndView getReqID(HttpServletRequest request,HttpServletResponse response,ModelMap model) throws Exception
		{
			LoginModel lgModel = new LoginModel();
			login = (Login)request.getSession().getAttribute("loggedIn");
			if(login==null)
				return new ModelAndView("login", "loginDetails", new Login());
			lgModel.setLoginModel(login);
			model.addAttribute("lgModel",lgModel);
			String userId = login.getUserid();
			List<RequirementFormDetails> reqIDList = userService.getReqIds(userId);
			model.addAttribute("selectedReqID",new RequirementFormDetails());
			return new ModelAndView("Requirement_Page","reqIDList",reqIDList);
		}   
	@RequestMapping("insertdat")
	public ModelAndView insertDat(@RequestParam String stdp,@ModelAttribute("form")RequirementForm form,@RequestParam String module,@RequestParam String pageno,@RequestParam String saved,HttpServletRequest request,ModelMap model,HttpServletResponse response)  throws Exception
	{
		
		if(form.getRating()!=null)
			saveProcessDetailsRequirement(form,(String)request.getSession().getAttribute("reqId_Gathering"));
		return 	new ModelAndView("redirect:RequirementGathering?stdp="+stdp+"&module="+module+"&pageno="+pageno+"&saved=0");  
	}
	@RequestMapping("savedFormRequirement")
	public ModelAndView savedFormRequirement(HttpServletRequest request) throws Exception
	{
		login = (Login)request.getSession().getAttribute("loggedIn");
		List<HomeDetails> standardProcessSaved=userService.getSavedProcessReq(login.getUserid());
		request.getSession().setAttribute("reqId_Gathering",standardProcessSaved.get(0).getModuleName());
		return new ModelAndView("redirect:RequirementGathering?stdp=1&module=1&pageno=0&saved=1"); 
		
	} 
	
	public void saveProcessDetailsRequirement(RequirementForm form,String reqId) throws Exception
	{
		String[] ratings = (form.getRating()).split(",");
		String[] SBP_Name =form.getSBP_Name();
		String[] Std_name=form.getStd_Name();
		String[] SBP_ID=form.getSBP_id();
		String[] SP_ID=form.getSP_id();
		String[] SP_Name=form.getSP_Name();
		String[] Process_Details=form.getProcess_Details();
		String[] comments=form.getComments();
		int[] ids=form.getDetails_id();
		List<RequirementFormDetails> formValues=new ArrayList<RequirementFormDetails>();
		for(int i=0;i<ratings.length;i++)
		{
			if(!(ratings[i].equals("Select")))
			{
				RequirementFormDetails newForm=new RequirementFormDetails();
				newForm.setReq_id(reqId);
				newForm.setSBP_name(SBP_Name[i]);
				newForm.setSBP_id(Integer.parseInt(SBP_ID[i]));
				newForm.setSP_id(Integer.parseInt(SP_ID[i]));
				newForm.setStd_name(Std_name[i]);
				newForm.setSP_name(SP_Name[i]);
				newForm.setProcess_details(Process_Details[i]);
				newForm.setRating(ratings[i]);
				if(comments.length==0)
					newForm.setCommentsGiven("");
				else
					newForm.setCommentsGiven(comments[i]);
				newForm.setDetails_id(ids[i]);
				formValues.add(newForm);
			}
		}
		if(formValues.isEmpty())
		{
			RequirementFormDetails newForm=new RequirementFormDetails();
			newForm.setReq_id(reqId);
			newForm.setSP_id(Integer.parseInt(SP_ID[0]));
			newForm.setRating("0");
			formValues.add(newForm);
		}
		userService.insertRequirementsGathering(formValues);
		
	}
	@RequestMapping("nextRequirementGathering")
	public ModelAndView getNextRequirementGathering(@RequestParam String stdp,@ModelAttribute("form")RequirementForm form,@RequestParam String module,@RequestParam String pageno,@RequestParam String saved,HttpServletRequest request,ModelMap	model,HttpServletResponse response)  throws Exception
	{
		saveProcessDetailsRequirement(form,(String)request.getSession().getAttribute("reqId_Gathering"));
		return new ModelAndView("redirect:RequirementGathering?stdp="+stdp+"&module="+module+"&pageno="+pageno+"&saved=0");  
	}
	@RequestMapping("createReqID")
	public ModelAndView createReqID(@ModelAttribute("form")RequirementForm form,HttpServletRequest request,ModelMap model,HttpServletResponse response) throws Exception
	{
		login = (Login)request.getSession().getAttribute("loggedIn");
		saveProcessDetailsRequirement(form,(String)request.getSession().getAttribute("reqId_Gathering"));
		userService.createReqID((String)request.getSession().getAttribute("reqId_Gathering"),login);
		//userService.deleteFromTemporaryReq(login.getUserid());
		
		return new ModelAndView("redirect:ReqViewReport1");

	}

 @RequestMapping("ReqViewReport1")
	public ModelAndView reqViewReqReport1(HttpServletRequest request,ModelMap model) throws Exception
	{
		LoginModel lgModel = new LoginModel();
		login = (Login)request.getSession().getAttribute("loggedIn");
		if(login==null)
			return new ModelAndView("login", "loginDetails", new Login());
		lgModel.setLoginModel(login);
		model.addAttribute("lgModel",lgModel);
		RequirementFormDetails reqIDSession = new RequirementFormDetails();
		reqIDSession.setReq_id((String)request.getSession().getAttribute("reqId_Gathering"));
		model.addAttribute("reqID",reqIDSession);

		List<RequirementFormDetails> report = userService.createReport((String)request.getSession().getAttribute("reqId_Gathering"));
		return new ModelAndView("ReqViewReport","report",report);
	}

 @RequestMapping("ReqViewReport")
	public ModelAndView reqViewReqReport(@ModelAttribute("selectedReqID")RequirementFormDetails form,BindingResult bindingResult,HttpServletRequest request,ModelMap model,HttpServletResponse response) throws Exception
	{
		LoginModel lgModel = new LoginModel();
		login = (Login)request.getSession().getAttribute("loggedIn");
		if(login==null)
			return new ModelAndView("login", "loginDetails", new Login());
		lgModel.setLoginModel(login);
		model.addAttribute("lgModel",lgModel);
		RequirementFormDetails reqID = form;
		model.addAttribute("reqID",reqID);
		List<RequirementFormDetails> report = userService.createReport(form.getReq_id());
		return new ModelAndView("ReqViewReport","report",report);

	} 
	@RequestMapping("previousRequirementGathering")
	public ModelAndView getPreviousRequirementGathering(@RequestParam String stdp,@ModelAttribute("form")RequirementForm form,@RequestParam String module,@RequestParam String pageno,@RequestParam String saved,HttpServletRequest request,ModelMap	model,HttpServletResponse response)  throws Exception
	{
		saveProcessDetailsRequirement(form,(String)request.getSession().getAttribute("reqId_Gathering"));
		return new ModelAndView("redirect:RequirementGathering?stdp="+stdp+"&module="+module+"&pageno="+pageno+"&saved=0");  
	}
	@RequestMapping("deleteSystemDetails1")
	public ModelAndView deleteSystemDetails(@RequestParam String id,String detailsId,HttpServletRequest request,Model model,@ModelAttribute("update") Systems updated_details) throws Exception 
		{
			userService.deleteSystemDetails1(Integer.parseInt(detailsId));
			return new ModelAndView("redirect:systemDetails?system_id="+id);  
		}

	@RequestMapping(value="/changeSystemDetails", method = RequestMethod.POST) 
	public ModelAndView changeSystemDetails(@RequestParam String system_id,HttpServletRequest request,Model model,@ModelAttribute("changeSystemDetails") System_Details changeDetails)  throws Exception{
		userService.changeSystemDetails(changeDetails);
		return new ModelAndView("redirect:systemDetails?system_id="+system_id);   
	} 
	@RequestMapping("insertSystemName")
	public ModelAndView insertSystemName(@ModelAttribute("system")Systems system,HttpServletRequest request,HttpServletResponse response,ModelMap model) throws Exception
	{
		LoginModel lgModel = new LoginModel();
		login = (Login)request.getSession().getAttribute("loggedIn");
		if(login==null)
			return new ModelAndView("login", "loginDetails", new Login());
		lgModel.setLoginModel(login);
		model.addAttribute("lgModel",lgModel);
		model.addAttribute("tab", 1);
		Systems newSystem = new Systems();
		newSystem.setSys_Name(system.getSys_Name());
		newSystem.setSys_Description(system.getSys_Description());
		newSystem.setCompany(login.getCompany());
		newSystem.setInserted_By(login.getUsername());
		newSystem.setSite(login.getSite());
		model.addAttribute("system", new Systems());
		userService.addNewSystem(newSystem);
		List<Systems> systems = userService.getSystems(login.getCompany(),login.getSite());
		Collections.sort(systems, new Comparator<Systems>() {
	        @Override public int compare(Systems p1, Systems p2) {
	            return p1.getSys_ID() - p2.getSys_ID(); // Ascending
	        }});
		return new ModelAndView("MIA_Page","systems",systems);
	}
	
	
	@RequestMapping("viewReport")
	public ModelAndView viewReqReport(@ModelAttribute("selectedReqID")AssementmentForm form,BindingResult bindingResult,HttpServletRequest request,ModelMap model,HttpServletResponse response) throws Exception
	{
		LoginModel lgModel = new LoginModel();
		login = (Login)request.getSession().getAttribute("loggedIn");
		if(login==null)
			return new ModelAndView("login", "loginDetails", new Login());
		lgModel.setLoginModel(login);
		model.addAttribute("lgModel",lgModel);
		AssementmentForm reqID = form;
		model.addAttribute("reqID",reqID);
		List<AssementmentForm> report = userService.generateReport(form.getReqID());
		return new ModelAndView("viewReport","report",report);

	}

	@RequestMapping("generateReqID")
	public ModelAndView generateReqID(HttpServletRequest request,ModelMap model,HttpServletResponse response) throws Exception
	{
		login = (Login)request.getSession().getAttribute("loggedIn");
		userService.generateReqID((String)request.getSession().getAttribute("reqId"),login.getUserid(),login.getCompany(),login.getSite());
		//userService.deleteFromTemporary(login.getUserid());
		return new ModelAndView("redirect:viewReport1");

	}
	@RequestMapping("reviewEdit")
	public ModelAndView reviewEdit(@ModelAttribute("reviewDetails")AssementmentForm form) throws Exception
	{
		userService.editReport(form);
		return new ModelAndView("redirect:reviewReport");

	}
	@RequestMapping("deleteReportDetails")
	public ModelAndView deleteReportDetails(@RequestParam String id,@RequestParam String subP) throws Exception
	{
		userService.deleteReportDetails(id,subP);
		return new ModelAndView("redirect:reviewReport");

	}
	@RequestMapping("reviewReport")
	public ModelAndView reviewReport(HttpServletRequest request,ModelMap model,HttpServletResponse response) throws Exception
	{
		LoginModel lgModel = new LoginModel();
		login = (Login)request.getSession().getAttribute("loggedIn");
		if(login==null)
			return new ModelAndView("login", "loginDetails", new Login());
		lgModel.setLoginModel(login);
		model.addAttribute("lgModel",lgModel);
		AssementmentForm reqIDSession = new AssementmentForm();
		reqIDSession.setReqID((String)request.getSession().getAttribute("reqId"));
		model.addAttribute("reqID",reqIDSession);
		List<AssementmentForm> report = userService.generateReport((String)request.getSession().getAttribute("reqId"));
		model.addAttribute("reviewDetails",new AssementmentForm());
		return new ModelAndView("reviewReport","report",report);

	}
	@RequestMapping("viewReport1")
	public ModelAndView viewReqReport1(HttpServletRequest request,ModelMap model) throws Exception
	{
		LoginModel lgModel = new LoginModel();
		login = (Login)request.getSession().getAttribute("loggedIn");
		if(login==null)
			return new ModelAndView("login", "loginDetails", new Login());
		lgModel.setLoginModel(login);
		model.addAttribute("lgModel",lgModel);
		AssementmentForm reqIDSession = new AssementmentForm();
		reqIDSession.setReqID((String)request.getSession().getAttribute("reqId"));
		model.addAttribute("reqID",reqIDSession);
		List<AssementmentForm> report = userService.generateReport((String)request.getSession().getAttribute("reqId"));
		return new ModelAndView("viewReport","report",report);
	} 
	
	@RequestMapping("product_evaluation_start")
	public ModelAndView showCriteria(HttpServletRequest request, ModelMap model)  throws Exception{
		LoginModel lgModel = new LoginModel();
		login = (Login) request.getSession().getAttribute("loggedIn");
		if (login == null)
			return new ModelAndView("login", "loginDetails", new Login());
		lgModel.setLoginModel(login);
		model.addAttribute("lgModel", lgModel);
		List<Criteria_titles> titles = userService.getCriteriaTitles();
		model.addAttribute("titles", titles);
		List<Criteria_Details> criteria_details = userService
				.getCriteria_details();
		model.addAttribute("criteria_details", criteria_details);
		return new ModelAndView("criteria");
	} 
	@RequestMapping("/roleManagement")
	public ModelAndView getUserIDList(ModelMap model, HttpServletRequest request)  throws Exception{
		List<NewUser> userList = userService.getUserIDList();
		model.addAttribute("idDetails", new NewUser());
		LoginModel lgModel = new LoginModel();
		login = (Login) request.getSession().getAttribute("loggedIn");
		if (login == null)
			return new ModelAndView("login", "loginDetails", new Login());
		lgModel.setLoginModel(login);
		model.addAttribute("lgModel", lgModel);
		model.addAttribute("removeFirstList", 0);
		model.addAttribute("customers", new NewUser());
		model.addAttribute( "userid",0);
		model.addAttribute("role",0);
		model.addAttribute("supplierAssigned",new Supplier_Customer());
		return new ModelAndView("roleManagement", "userList", userList);
	}

	@RequestMapping("/roleManagement1")
	public ModelAndView getUsernameRole(
			@ModelAttribute("idDetails") NewUser user,
			BindingResult bindingResult, HttpServletRequest request,
			ModelMap model, HttpServletResponse response) throws Exception {
		
		List<Role> roleList = userService.getRoleList();
		model.addAttribute("roleList", roleList);
		List<NewUser> userList = userService.getUserIDList();
		model.addAttribute("userList", userList);
		NewUser newuser = userService.getUserOfID(user.getUserid());
		LoginModel lgModel = new LoginModel();
		login = (Login) request.getSession().getAttribute("loggedIn");
		if (login == null)
			return new ModelAndView("login", "loginDetails", new Login());
		lgModel.setLoginModel(login);
		model.addAttribute("idDetails", new NewUser());
		model.addAttribute("removeFirstList", 1);
		model.addAttribute("lgModel", lgModel);
		model.addAttribute("customers", new NewUser());
		model.addAttribute( "userid",0);
		model.addAttribute("role",0);
		model.addAttribute("supplierAssigned",new Supplier_Customer());
		return new ModelAndView("roleManagement", "newuser", newuser);

	}

	@RequestMapping("/roleManagement2")
	public ModelAndView setRole(@ModelAttribute("idDetails") NewUser user,
			BindingResult bindingResult, HttpServletRequest request,
			ModelMap model, HttpServletResponse response)  throws Exception{
		List<HomeDetails> userList = userService.getUserList();
		model.addAttribute("userList", userList);
		LoginModel lgModel = new LoginModel();
		login = (Login) request.getSession().getAttribute("loggedIn");
		if (login == null)
			return new ModelAndView("login", "loginDetails", new Login());
		lgModel.setLoginModel(login);
		model.addAttribute("lgModel", lgModel);
		if (userService.setRole(user.getCmpswd(), user.getUserid()) ) 
		{
			return new ModelAndView("home");
		} 
		else {
			return new ModelAndView("roleManagement");
		}
		
	}
	
	

	@RequestMapping("supplier_info")
	public ModelAndView showSupplier_Info(@RequestParam String cat_id,ModelMap model,HttpServletRequest request, HttpServletResponse response) throws Exception
	{
		int cat_id1= Integer.parseInt(cat_id);
		userService.clearConnections();
		LoginModel lgModel = new LoginModel();
		login = (Login) request.getSession().getAttribute("loggedIn");
		if (login == null)
			return new ModelAndView("login", "loginDetails", new Login());
		lgModel.setLoginModel(login);
		model.addAttribute("lgModel", lgModel);
		List<Category> category = userService.getDetailsCategory();
		model.addAttribute("category", category);
		List<Supplier_Info_Questions> ques = userService.getInfoQues(cat_id1);
		model.addAttribute("ques", ques);
		List<Role> supDetails = userService.getSupDetails();
		model.addAttribute("supDet", supDetails);
		if(ques.size()==0 )
		{
			model.addAttribute("nothing",0);
		}
		else model.addAttribute("nothing",1);
		List<Ratings> rating = userService.getCategoryRatings(cat_id1);
		model.addAttribute("info", new Supplier_Info_Response());
		model.addAttribute("ratings", rating);
		List<Supplier_Info_Questions> savedInfo = userService.getSavedInfo(cat_id1,login.getCompany());
		model.addAttribute("savedInfo",savedInfo);
		model.addAttribute("cat_id123",cat_id1);
		return new ModelAndView("supplier_info");	
	}
	@RequestMapping("insertCustTechInfo")
	public ModelAndView saveInfo1(@RequestParam String cat_id1234,@ModelAttribute("info") Technical_Info_Response info,HttpServletRequest request) throws Exception 
	{
		login = (Login) request.getSession().getAttribute("loggedIn");
		String company = login.getCompany();
		String site = login.getSite();
		String[] ids = (cat_id1234.split(","));
		int cat_id1= Integer.parseInt(ids[0]);
		if(info.getRatings()!=null)
		saveTechnicalInfo(info, company,site);
		return new ModelAndView("redirect:customer_tech_info?cat_id="+cat_id1);
	} 
	
	@RequestMapping("insertInfo")
	public ModelAndView saveInfo(@RequestParam String cat_id1234,@ModelAttribute("info") Supplier_Info_Response info,HttpServletRequest request) throws Exception
	{
		login = (Login) request.getSession().getAttribute("loggedIn");
		String company = login.getCompany();
		int cat_id1= Integer.parseInt(cat_id1234);
		if(info.getRatings()!=null)
		{
			saveSupplierInfo(info,company);
		}
		
		return new ModelAndView("redirect:supplier_info?cat_id="+cat_id1);
	}
	
	public void saveSupplierInfo(Supplier_Info_Response info, String company) throws Exception {
		
		String[] ratings = (info.getRatings()).split(",");
		int[] c_ids = info.getCat_id(); 
		int[] s_ids = info.getSd_id();
		int[] sInfo_ids = info.getsInfo_id();
		String[] comments = info.getComments();
		
		List<Supplier_Info_Questions> response = new ArrayList<Supplier_Info_Questions>();
		for (int i = 0; i < ratings.length; i++) {
			if (!(ratings[i].equals("Select"))) {
				Supplier_Info_Questions newForm = new Supplier_Info_Questions();
				newForm.setCat_id(c_ids[i]);
				newForm.setSd_id(s_ids[i]);
				newForm.setsInfo_id(sInfo_ids[i]);
				newForm.setRatings(ratings[i]);
				if(comments.length==0)
					newForm.setComments("");
				else
					newForm.setComments(comments[i]);
				newForm.setCompany(company);
				response.add(newForm);
			}
		}
		if(response.isEmpty())
		{
			Supplier_Info_Questions newForm = new Supplier_Info_Questions();
			newForm.setCat_id(c_ids[0]);
			newForm.setCompany(company);
			newForm.setRatings("0");
			response.add(newForm);
		}
		userService.insertInfo(response,company);
		
	}
	
	
	
public void saveTechnicalInfo(Technical_Info_Response info, String company,String site)  throws Exception{
		
		String[] ratings = (info.getRatings()).split(",");
		int[] cat_ids = info.getCat_id(); 
		int[] sub_cat_ids = info.getSub_cat_id();
		int[] ques_ids = info.getQues_id();
		int[] sub_ques_ids = info.getSub_ques_id();
		String[] comments = info.getComments();
		
		List<Technical_Info_Questions> response = new ArrayList<Technical_Info_Questions>();
		for (int i = 0; i < ratings.length; i++) {
			if (!(ratings[i].equals("Select"))) {
				Technical_Info_Questions newForm = new Technical_Info_Questions();
				newForm.setCat_id(cat_ids[i]);
				newForm.setSub_cat_id(sub_cat_ids[i]);
				newForm.setQues_id(ques_ids[i]);
				newForm.setSub_ques_id(sub_ques_ids[i]);
				newForm.setRatings(ratings[i]);
				if(comments.length==0)
					newForm.setComments("");
				else
					newForm.setComments(comments[i]);
				newForm.setCompany(company);
				newForm.setSite(site);
				response.add(newForm);
			}
		}
		if(response.isEmpty())
		{
			Technical_Info_Questions newForm = new Technical_Info_Questions();
			newForm.setCat_id(cat_ids[0]);
			newForm.setCompany(company);
			newForm.setSite(site);
			newForm.setRatings("0");
			response.add(newForm);
		}
		userService.insertTechInfo(response,company);
		
	}
	@RequestMapping("supplier_rating_page")
	public ModelAndView supplier_rating_page(HttpServletRequest request, ModelMap model)  throws Exception{
		request.getSession().setAttribute("supplierRating_id",login.getCompany());
		return new ModelAndView("redirect:supplier_ratings?std=1&sub=0&page=0");
	} 
	@RequestMapping("supplier_ratings")
	public ModelAndView supplier_ratings(@RequestParam String sub,@RequestParam String std ,@RequestParam String page,HttpServletRequest request, ModelMap model) throws Exception {
		LoginModel lgModel = new LoginModel();
		login = (Login)request.getSession().getAttribute("loggedIn");
		if(login==null)
			return new ModelAndView("login", "loginDetails", new Login());
		lgModel.setLoginModel(login);
		model.addAttribute("lgModel",lgModel);
		int[] moduleDetails={Integer.parseInt(std)};
		List<StdBusinessProcess> standardProcesses=userService.getStandardProcessList(selectedModulesRequirement);
		List<SubBusinessProcess>SupPList= userService.getSubBusinessProcess(moduleDetails);
		List<SubProcess> details_List=null;
		List<Process_Details> process_details_list=null;
		model.addAttribute("stdProcess",standardProcesses);
		model.addAttribute("expandOuterTree",Integer.parseInt(std));
		if(!SupPList.isEmpty())
		{	
			List<SupplierRatingDetails> savedRatings=new ArrayList<SupplierRatingDetails>();
			 if(Integer.parseInt(sub)==0)
			{	
				details_List = userService.getSubProcessList(SupPList.get(0).getSBP_ID());
				process_details_list=userService.getProcessDetailsByIdAll(details_List.get(0).getSP_id());
				
			}
			else
			{
				details_List = userService.getSubProcessList(Integer.parseInt(sub));
				if(Integer.parseInt(page)==0)
				{
					process_details_list=userService.getProcessDetailsByIdAll(details_List.get(0).getSP_id());
				}
				else
					process_details_list=userService.getProcessDetailsByIdAll(Integer.parseInt(page));
			}
			 if(page.equals("0"))
				{
					model.addAttribute("expandInnerTree",process_details_list.get(0).getSP_Id());
					 savedRatings=userService.getSavedSupplierRatings(process_details_list.get(0).getSP_Id(),(String)request.getSession().getAttribute("supplierRating_id"));
					
				}
				else
				{
					model.addAttribute("expandInnerTree",Integer.parseInt(page));
					savedRatings=userService.getSavedSupplierRatings(Integer.parseInt(page),(String)request.getSession().getAttribute("supplierRating_id"));
					
				}
			model.addAttribute("process_details_list", process_details_list);
			model.addAttribute("expandTree",details_List.get(0).getSBP_id() );
			model.addAttribute("expandInnerTree", process_details_list.get(0).getSP_Id());
			model.addAttribute("SupList", SupPList);
			model.addAttribute("details", details_List);
			model.addAttribute("savedRatings",savedRatings);
			
		}
		else
		{
			model.addAttribute("noValues", 0);
		}
		List<Ratings> supplierRatings=userService.getTechRatings(2);
		model.addAttribute("supplierRatings", supplierRatings);
		model.addAttribute("form",new SuplierRating());
		return new ModelAndView("supplier_rating_page");
	}

	@RequestMapping("saveSupplierRating")
	public ModelAndView saveSupplierRating(@RequestParam String sub,@RequestParam String std ,@RequestParam String page,@ModelAttribute("form")SuplierRating form, BindingResult bindingResult, 
	HttpServletRequest request,	HttpServletResponse response)  throws Exception
	{
		saveSupplierRatingDetails(form,(String)request.getSession().getAttribute("supplierRating_id"));
		return new ModelAndView("redirect:supplier_ratings?std="+std+"&sub="+sub+"&page="+page);
	}
	public void saveSupplierRatingDetails(SuplierRating form,String Supplier_id) throws Exception
	{
		String[] ratings = (form.getRating()).split(",");
		String[] comment= form.getComments();
		int[] sp_id=form.getSp_id();
		int[] detail_id=form.getDetails_id();
		List<SupplierRatingDetails> save=new ArrayList<SupplierRatingDetails>();
		for (int i = 0; i < ratings.length; i++) {
			if (!(ratings[i].equals("Select"))) {
				SupplierRatingDetails newForm = new SupplierRatingDetails();
				newForm.setReq_id(Supplier_id);
				newForm.setRating(Integer.parseInt(ratings[i]));
				if(comment.length==0)
					newForm.setComments("");
				else
					newForm.setComments(comment[i]);
				newForm.setDetails_id(detail_id[i]);
				newForm.setSp_id(sp_id[i]);
				save.add(newForm);
			}
		}
		if(save.isEmpty())
		{
			SupplierRatingDetails newForm = new SupplierRatingDetails();
			newForm.setReq_id(Supplier_id);
			newForm.setSp_id(sp_id[0]);
			newForm.setRating(0);
			save.add(newForm);
		}
		userService.addSupplierRatingsCustomers(save);
	}
	@RequestMapping("edit_sup_info")
	public ModelAndView showSupplier_Info1(@RequestParam String cat_id,ModelMap model,HttpServletRequest request, HttpServletResponse response) throws Exception
	{
		int cat_id1= Integer.parseInt(cat_id);
		userService.clearConnections();
		LoginModel lgModel = new LoginModel();
		login = (Login) request.getSession().getAttribute("loggedIn");
		if (login == null)
			return new ModelAndView("login", "loginDetails", new Login());
		lgModel.setLoginModel(login);
		model.addAttribute("lgModel", lgModel);
		List<Category> category = userService.getDetailsCategory();
		model.addAttribute("category", category);
		List<Supplier_Info_Questions> ques = userService.getInfoQues(cat_id1);
		model.addAttribute("ques", ques);
		List<Role> supDetails = userService.getSupDetails();
		model.addAttribute("supDet", supDetails);
		model.addAttribute("cat_id123",cat_id1);
		model.addAttribute("newSubCat",new Role());
		model.addAttribute("newQues",new Supplier_Info_Questions());
		return new ModelAndView("editSupInfo");	
	}

	@RequestMapping("addSubCat")
	public ModelAndView addSubCat(@RequestParam String cat_id,@ModelAttribute("newSubCat") Role newSubCat,ModelMap model,HttpServletRequest request, HttpServletResponse response) throws Exception
	{
		if(!newSubCat.getRoleName().equals(""))
		{
		userService.addSubCat(newSubCat);
		}
		return new ModelAndView("redirect:edit_sup_info?cat_id="+cat_id);
	}

	@RequestMapping("updateSubCat")
	public ModelAndView updateSubCat(@RequestParam String cat_id,@ModelAttribute("newSubCat") Role newSubCat,ModelMap model,HttpServletRequest request, HttpServletResponse response) throws Exception
	{
		if(!newSubCat.getRoleName().equals(""))
		{
		userService.updateSubCat(newSubCat);
		}
		return new ModelAndView("redirect:edit_sup_info?cat_id="+cat_id);
	}

	@RequestMapping("updateQues")
	public ModelAndView updateQues(@RequestParam String cat_id,@ModelAttribute("newQues") Supplier_Info_Questions newQues,ModelMap model,HttpServletRequest request, HttpServletResponse response) throws Exception
	{
		if(!newQues.getInfo_ques().equals(""))
		{
		userService.updateQues(newQues);
		}
		return new ModelAndView("redirect:edit_sup_info?cat_id="+cat_id);
	}

	@RequestMapping("addNewQues")
	public ModelAndView addNewQues(@RequestParam String cat_id,@ModelAttribute("newQues") Supplier_Info_Questions newQues,ModelMap model,HttpServletRequest request, HttpServletResponse response) throws Exception
	{
		if(!newQues.getInfo_ques().equals(""))
		{
		userService.addNewQues(newQues);
		}
		return new ModelAndView("redirect:edit_sup_info?cat_id="+cat_id);
	}

	@RequestMapping("addNewSubCat")
	public ModelAndView addNewSubCat(@RequestParam String cat_id,@ModelAttribute("newQues") Supplier_Info_Questions newQues,ModelMap model,HttpServletRequest request, HttpServletResponse response) throws Exception
	{

		userService.addNewQues(newQues);
		return new ModelAndView("redirect:edit_sup_info?cat_id="+cat_id);
	}

	@RequestMapping("activation")
	public ModelAndView doActivation(@RequestParam String cat_id,@RequestParam String active,@RequestParam String quesid,ModelMap model,HttpServletRequest request, HttpServletResponse response) throws Exception
	{
		userService.doActivation(active,quesid);
		return new ModelAndView("redirect:edit_sup_info?cat_id="+cat_id);
	}

	@RequestMapping("Subactivation")
	public ModelAndView doSubactivation(@RequestParam String cat_id,@RequestParam String active,@RequestParam String subcat_id,ModelMap model,HttpServletRequest request, HttpServletResponse response) throws Exception
	{
		userService.doSubactivation(active,cat_id,subcat_id);
		return new ModelAndView("redirect:edit_sup_info?cat_id="+cat_id);
	}
	 
	@RequestMapping("customer_tech_info")
	public ModelAndView showCust_Tech_Info(@RequestParam String cat_id,ModelMap model,HttpServletRequest request, HttpServletResponse response) throws Exception
	{

		int cat_id1= Integer.parseInt(cat_id);
		userService.clearConnections();
		LoginModel lgModel = new LoginModel();
		login = (Login) request.getSession().getAttribute("loggedIn");
		if (login == null)
			return new ModelAndView("login", "loginDetails", new Login());
		lgModel.setLoginModel(login);
		model.addAttribute("lgModel", lgModel);
		List<Category> tech_cat = userService.getTech_Category();
		model.addAttribute("tech_cat",tech_cat);
		model.addAttribute("cat_id1",cat_id1);
		List<Category> tech_sub_cat = userService.getTech_sub_category(cat_id1);
		List<System_SubAttributes> tech_ques = userService.getTech_Ques(cat_id1);
		model.addAttribute("tech_ques",tech_ques);
		if(!tech_sub_cat.isEmpty())
		{
			model.addAttribute("tech_sub_cat",tech_sub_cat);
			model.addAttribute("present",1);
		}
		else {
			model.addAttribute("present",0);
		}
		List<Category> sub_ques = userService.getTechSubQues();
		model.addAttribute("sub_ques",sub_ques);
		List<Ratings> ratings = userService.getTechRatings(1);
		model.addAttribute("ratings",ratings);
		model.addAttribute("lastCount",userService.getLastCount()); 
		model.addAttribute("info", new Technical_Info_Response());
		List<Technical_Info_Questions> savedInfo = userService.getSavedTecInfo(cat_id1,login.getCompany(),login.getSite());
		model.addAttribute("savedInfo",savedInfo);

		return new ModelAndView("customer_technical_info");
	} 
	@RequestMapping("edit_tech_info")
	public ModelAndView showTech_Info1(@RequestParam String cat_id,ModelMap model,HttpServletRequest request, HttpServletResponse response)
	{
		int cat_id1= Integer.parseInt(cat_id);
		userService.clearConnections();
		LoginModel lgModel = new LoginModel();
		login = (Login) request.getSession().getAttribute("loggedIn");
		if (login == null)
			return new ModelAndView("login", "loginDetails", new Login());
		lgModel.setLoginModel(login);
		model.addAttribute("lgModel", lgModel);
		List<Category> tech_cat = userService.getTech_Category();
		model.addAttribute("tech_cat",tech_cat);

		List<Category> tech_sub_cat = userService.getTech_sub_category(cat_id1);
		List<System_SubAttributes> tech_ques = userService.getTech_Ques(cat_id1);
		model.addAttribute("tech_ques",tech_ques);
		if( tech_sub_cat.isEmpty() || tech_ques.isEmpty())
		{
			model.addAttribute("nothing",0);
		}
		else model.addAttribute("nothing",1);
		if(!tech_sub_cat.isEmpty())
		{
			model.addAttribute("tech_sub_cat",tech_sub_cat);
			model.addAttribute("present",1);
		}
		else {
			model.addAttribute("present",0);
		}
		model.addAttribute("lastCount",userService.getLastCount());
		List<Category> sub_ques = userService.getTechSubQues();
		model.addAttribute("sub_ques",sub_ques);
		model.addAttribute("newSubCat",new Category());
		model.addAttribute("newCat",new Category());
		model.addAttribute("cat_id1",cat_id1);
		model.addAttribute("newQues",new System_SubAttributes());
		model.addAttribute("newSubQues",new Category());
		return new ModelAndView("editTechInfo");
	}

	@RequestMapping("addNewTechSubCat")
	public ModelAndView addNewTechSubCat(@RequestParam String cat_id,@ModelAttribute("newSubCat") Category newSubCat,ModelMap model,HttpServletRequest request, HttpServletResponse response)
	{
		if(!newSubCat.getCat_name().equals(""))
		{
			userService.addNewTechSubCat(newSubCat);
		}
		return new ModelAndView("redirect:edit_tech_info?cat_id="+cat_id);
	}

	@RequestMapping("addNewTechQues")
	public ModelAndView addNewTechQues(@RequestParam String cat_id,@ModelAttribute("newQues") System_SubAttributes newQues,ModelMap model,HttpServletRequest request, HttpServletResponse response)
	{	
		if(!newQues.getSubAttribute_name().equals(""))
		{
			userService.addNewTechQues(newQues);
		}
		return new ModelAndView("redirect:edit_tech_info?cat_id="+cat_id);
	}


	@RequestMapping("updateTechSubQues")
	public ModelAndView updateTechSubQues(@RequestParam String cat_id,@ModelAttribute("newSubQues") Category newSubQues,ModelMap model,HttpServletRequest request, HttpServletResponse response)
	{
		if(!newSubQues.getCat_name().equals(""))
		{
			userService.updateTechSubQues(newSubQues);
		}
		return new ModelAndView("redirect:edit_tech_info?cat_id="+cat_id);
	}

	@RequestMapping("updateTechQues")
	public ModelAndView updateTechQues(@RequestParam String cat_id,@ModelAttribute("newQues") System_SubAttributes newQues,ModelMap model,HttpServletRequest request, HttpServletResponse response)
	{
		if(!newQues.getSubAttribute_name().equals(""))
		{
			userService.updateTechQues(newQues);
		}
		return new ModelAndView("redirect:edit_tech_info?cat_id="+cat_id);
	}

	@RequestMapping("SubQuesActivation")
	public ModelAndView doSubQuesActivation(@RequestParam String cat_id,@RequestParam String active,@RequestParam String ques_id,@RequestParam String subcat_id,ModelMap model,HttpServletRequest request, HttpServletResponse response)
	{
		userService.doSubQuesActivation(active,ques_id,subcat_id);
		return new ModelAndView("redirect:edit_tech_info?cat_id="+cat_id);
	}

	@RequestMapping("QuesActivation")
	public ModelAndView doQuesActivation(@RequestParam String cat_id,@RequestParam String active,@RequestParam String ques_id,@RequestParam String subcat_id,ModelMap model,HttpServletRequest request, HttpServletResponse response)
	{
		userService.doQuesActivation(active,ques_id,subcat_id);
		return new ModelAndView("redirect:edit_tech_info?cat_id="+cat_id);
	}

	@RequestMapping("addNewCat")
	public ModelAndView addNewTechCat(@RequestParam String cat_id,@ModelAttribute("newCat") Category newCat,ModelMap model,HttpServletRequest request, HttpServletResponse response)
	{
		if(!newCat.getCat_name().equals(""))
		{
			userService.addNewTechCat(newCat);
		}
		return new ModelAndView("redirect:edit_tech_info?cat_id="+cat_id);
	}

	@RequestMapping("tech_info")
	public ModelAndView showTech_Info(@RequestParam String cat_id,ModelMap model,HttpServletRequest request, HttpServletResponse response)
	{

		int cat_id1= Integer.parseInt(cat_id);
		userService.clearConnections();
		LoginModel lgModel = new LoginModel();
		login = (Login) request.getSession().getAttribute("loggedIn");
		if (login == null)
			return new ModelAndView("login", "loginDetails", new Login());
		lgModel.setLoginModel(login);
		model.addAttribute("lgModel", lgModel);
		List<Category> tech_cat = userService.getTech_Category();
		model.addAttribute("tech_cat",tech_cat);
		model.addAttribute("cat_id1",cat_id1);
		List<Category> tech_sub_cat = userService.getTech_sub_category(cat_id1);
		List<System_SubAttributes> tech_ques = userService.getTech_Ques(cat_id1);
		model.addAttribute("tech_ques",tech_ques);
		if(!tech_sub_cat.isEmpty())
		{
			model.addAttribute("tech_sub_cat",tech_sub_cat);
			model.addAttribute("present",1);
		}
		else {
			model.addAttribute("present",0);
		}
		List<Category> sub_ques = userService.getTechSubQues();
		model.addAttribute("sub_ques",sub_ques);
		List<Ratings> ratings = userService.getTechRatings(2);
		model.addAttribute("ratings",ratings);
		model.addAttribute("info", new Technical_Info_Response());
		List<Technical_Info_Questions> savedInfo = userService.getSavedTecInfo(cat_id1,login.getCompany(),login.getSite());
		model.addAttribute("savedInfo",savedInfo);
		model.addAttribute("lastCount",userService.getLastCount());
		return new ModelAndView("technical_info");
	}

	@RequestMapping("updateTechSubCat")
	public ModelAndView updateTechSubCat(@RequestParam String cat_id,@ModelAttribute("newSubCat") Category newSubCat,HttpServletRequest request)
	{

		if(!newSubCat.getCat_name().equals(""))
		{
		userService.updateTechSubCat(newSubCat);
		}
		return new ModelAndView("redirect:edit_tech_info?cat_id="+cat_id);
	}

	@RequestMapping("SubCatActivation")
	public ModelAndView doSubCatActivation(@RequestParam String cat_id,@RequestParam String active,@RequestParam String subcat_id,HttpServletRequest request)
	{
		userService.doSubCatActivation(active,subcat_id);
		return new ModelAndView("redirect:edit_tech_info?cat_id="+cat_id);
	}

	@RequestMapping("Catactivation")
	public ModelAndView catActivation(@RequestParam String cat_id,@RequestParam String active,@RequestParam String Cat_id1,HttpServletRequest request)
	{
		userService.catActivation(active,Cat_id1);
		return new ModelAndView("redirect:edit_tech_info?cat_id="+cat_id);
	}

	@RequestMapping("insertTechInfo")
	public ModelAndView saveInfo(@RequestParam String cat_id1234,@ModelAttribute("info") Technical_Info_Response info,HttpServletRequest request) throws Exception 
	{
		login = (Login) request.getSession().getAttribute("loggedIn");
		String company = login.getCompany();
		String site = login.getSite();
		String[] ids = (cat_id1234.split(","));
		int cat_id1= Integer.parseInt(ids[0]);
		if(info.getRatings()!=null)
		saveTechnicalInfo(info, company,site);
		return new ModelAndView("redirect:tech_info?cat_id="+cat_id1);
	}
	@RequestMapping("exporttoexcel")
	public ModelAndView exporttoexcel(@RequestParam String id,HttpServletRequest request,ModelMap model,HttpServletResponse response) throws Exception
	{
		LoginModel lgModel = new LoginModel();
		login = (Login)request.getSession().getAttribute("loggedIn");
		if(login==null)
			return new ModelAndView("login", "loginDetails", new Login());
		lgModel.setLoginModel(login);
		model.addAttribute("lgModel",lgModel);
		model.addAttribute("reqID",id);
		List<AssementmentForm> report = userService.generateReport(id);
		return new ModelAndView("exporttoexcelMia","report",report);

	} 
	
	@RequestMapping("searchCriteria")
	public ModelAndView searchCriteria(@RequestParam String id,@ModelAttribute("idOfRequirement")RequirementsList requirment,HttpServletRequest request,ModelMap model,HttpServletResponse response) throws Exception
	{
		LoginModel lgModel = new LoginModel();
		login = (Login)request.getSession().getAttribute("loggedIn");
		if(login==null)
			return new ModelAndView("login", "loginDetails", new Login());
		lgModel.setLoginModel(login);
		model.addAttribute("lgModel",lgModel);
		List<RequirementsList> listOfSubmittedReqReport=userService.getSubmittedReqList();
		List<RequirementsList> requirementReport=new ArrayList<>();
		List<CompanyDetails> companies=userService.getListOfCompanies();
		for(RequirementsList name:listOfSubmittedReqReport)
		{
			for(CompanyDetails company:companies)
			{
				if(name.getCompany().equals(company.getCompanyName()))
				{
					if(company.getType().equals("Customer"))
						requirementReport.add(name);
				}
			}
		}
		model.addAttribute("listOfSubmittedReqReport", requirementReport);
		int i=1;
		if(Integer.parseInt(id)>0)
		{
			i=2;
			if(Integer.parseInt(id)==1)
				requirment.setUserid(null);
			List<StdBusinessProcess> stdProcess=userService.getSBPList();
			model.addAttribute("stdProcess",stdProcess);
			if(Integer.parseInt(id)>1)
			{
				i=3;
				int[] array={userService.getStdIdName(requirment.getUserid())};
				List<SubBusinessProcess> SupList=userService.getSubBusinessProcess(array);
				model.addAttribute("SupList",SupList);
				if(Integer.parseInt(id)>2)
				{
					i=4;
					List<SubProcess> detailsList= userService.getSubProcessList(userService.getBusiProcessIdFromName(requirment.getCompany()));
					model.addAttribute("detailsList",detailsList);
				}
			}
		}
		else
		{
			requirment= new RequirementsList();
		}
		model.addAttribute("idOfRequirement",requirment);
		model.addAttribute("disablelevel",i);
		return new ModelAndView("RequirementReport");
	}
	String searchTable=null;
	RequirementsList listofReq=null;
	@RequestMapping("submitSearchCriteria")
	public ModelAndView submitSearchCriteria(@ModelAttribute("idOfRequirement")RequirementsList requirment,HttpServletRequest request,ModelMap model) throws Exception
	{
		if(requirment.getReq_id()!=null){
		if(requirment.getSite()==null)
		{
			if(requirment.getCompany()==null)
			{
				if(requirment.getUserid().equals("All"))
				{
					searchTable="select REQ_ID,STD_PROCESS,SUB_PROCESS,PROCESS_NAME,submitted_RATING,submitted_comments,DETAILS_ID,STD_BUSINESS_PROCESS,SBP_ID,SP_ID from REQUIREMENT_FORM where req_id='"+requirment.getReq_id()+"'";
				}
			}
			else if(requirment.getCompany().equals("All"))
			{
				searchTable="select REQ_ID,STD_PROCESS,SUB_PROCESS,PROCESS_NAME,submitted_RATING,submitted_comments,DETAILS_ID,STD_BUSINESS_PROCESS,SBP_ID,SP_ID from REQUIREMENT_FORM where req_id='"+requirment.getReq_id()+"' and STD_BUSINESS_PROCESS='"+requirment.getUserid()+"'";
			}
		}
		else if(requirment.getSite().equals("All"))
		{
			searchTable="select REQ_ID,STD_PROCESS,SUB_PROCESS,PROCESS_NAME,submitted_RATING,submitted_comments,DETAILS_ID,STD_BUSINESS_PROCESS,SBP_ID,SP_ID from REQUIREMENT_FORM where req_id='"+requirment.getReq_id()+"' and STD_BUSINESS_PROCESS='"+requirment.getUserid()+"' and STD_PROCESS='"+requirment.getCompany()+"'";
		}
		else
			searchTable="select REQ_ID,STD_PROCESS,SUB_PROCESS,PROCESS_NAME,submitted_RATING,submitted_comments,DETAILS_ID,STD_BUSINESS_PROCESS,SBP_ID,SP_ID from REQUIREMENT_FORM where req_id='"+requirment.getReq_id()+"' and STD_BUSINESS_PROCESS='"+requirment.getUserid()+"' and STD_PROCESS='"+requirment.getCompany()+"' and SUB_PROCESS='"+requirment.getSite()+"'";
		}
		else
			searchTable="select REQ_ID,STD_PROCESS,SUB_PROCESS,PROCESS_NAME,submitted_RATING,submitted_comments,DETAILS_ID,STD_BUSINESS_PROCESS,SBP_ID,SP_ID from REQUIREMENT_FORM where req_id='"+requirment.getIdSelected()+"'";
		listofReq=requirment;
		presentSort=0;
		return new ModelAndView("redirect:paginationRequirementRep?page=1&sort=0"); 		
	}
	int presentSort=0;
	@RequestMapping("paginationRequirementRep")
	public ModelAndView paginationRequirementRep(@ModelAttribute("idOfRequirement")RequirementsList requirment,@RequestParam String page,@RequestParam String sort,HttpServletRequest request,ModelMap model) throws Exception
	{
		LoginModel lgModel = new LoginModel();
		login = (Login)request.getSession().getAttribute("loggedIn");
		if(login==null)
			return new ModelAndView("login", "loginDetails", new Login());
		lgModel.setLoginModel(login);
		model.addAttribute("lgModel",lgModel);
		if(sort.equals("1"))
		{
			searchTable+="order by ratings asc";
			presentSort=1;
		}
		else if(sort.equals("2"))
		{
			searchTable=searchTable.substring(0,searchTable.length()-4);
			searchTable+=" desc";
			presentSort=2;
		}
		else if(sort.equals("3"))
		{
			presentSort=3;
			int i=searchTable.indexOf("order by ratings");
			searchTable=searchTable.substring(0,i);
		}
		else{
			
		}
		model.addAttribute("presentSort", presentSort);
		int pageno=Integer.parseInt(page);
		int recordsPerPage =7;
		List<RequirementFormDetails> list = userService.viewAllReqDetails((pageno-1)*recordsPerPage,
								 recordsPerPage,searchTable);
		int noOfRecords = userService.getNoOfRecordsValue();
		int noOfPages = (int) Math.ceil(noOfRecords * 1.0 / recordsPerPage);
		int i=1;
		if(listofReq.getReq_id()!=null){
			
		if(listofReq.getSite()==null)
		{
			if(listofReq.getCompany()==null)
			{
				i=2;
				List<StdBusinessProcess> stdProcess=userService.getSBPList();
				model.addAttribute("stdProcess",stdProcess);
			}
			else
			{
				List<StdBusinessProcess> stdProcess=userService.getSBPList();
				model.addAttribute("stdProcess",stdProcess);
				int[] array={userService.getStdIdName(listofReq.getUserid())};
				List<SubBusinessProcess> SupList=userService.getSubBusinessProcess(array);
				model.addAttribute("SupList",SupList);
				i=3;
			}
		}
		else
		{
			List<StdBusinessProcess> stdProcess=userService.getSBPList();
			model.addAttribute("stdProcess",stdProcess);
			int[] array={userService.getStdIdName(listofReq.getUserid())};
			List<SubBusinessProcess> SupList=userService.getSubBusinessProcess(array);
			model.addAttribute("SupList",SupList);
			List<SubProcess> detailsList= userService.getSubProcessList(userService.getBusiProcessIdFromName(listofReq.getCompany()));
			model.addAttribute("detailsList",detailsList);
			i=4;
		}
		}
		else
		{
			i=5;
		}
		if(list.isEmpty())
			model.addAttribute("noData",1);
		model.addAttribute("idOfRequirement",listofReq);
		List<RequirementsList> listOfSubmittedReqReport=userService.getSubmittedReqList();
		List<RequirementsList> requirementReport=new ArrayList<>();
		List<CompanyDetails> companies=userService.getListOfCompanies();
		for(RequirementsList name:listOfSubmittedReqReport)
		{
			for(CompanyDetails company:companies)
			{
				if(name.getCompany().equals(company.getCompanyName()))
				{
					if(company.getType().equals("Customer"))
						requirementReport.add(name);
				}
			}
		}
		model.addAttribute("listOfSubmittedReqReport", requirementReport);
		model.addAttribute("disablelevel",i);
		model.addAttribute("List", list);
		model.addAttribute("displayTable", 1);
		model.addAttribute("noOfPages", noOfPages);
		model.addAttribute("currentPage", pageno);
		return new ModelAndView("RequirementReport"); 
	}
	@RequestMapping("showMIAReport")
	public ModelAndView showMIAReport(@ModelAttribute("idOfMia")RequirementsList requirment,@RequestParam String id,HttpServletRequest request,ModelMap model) throws Exception
	{
		LoginModel lgModel = new LoginModel();
		login = (Login)request.getSession().getAttribute("loggedIn");
		if(login==null)
			return new ModelAndView("login", "loginDetails", new Login());
		lgModel.setLoginModel(login);
		model.addAttribute("lgModel",lgModel);
		List<RequirementsList> listOfSubmittedMiaReport1=userService.getSubmittedMiaList();
		List<RequirementsList> listOfSubmittedMiaReport= new ArrayList<>();
		List<CompanyDetails> companies=userService.getListOfCompanies();
		for(RequirementsList name:listOfSubmittedMiaReport1)
		{
			for(CompanyDetails company:companies)
			{
				if(name.getCompany().equals(company.getCompanyName()))
				{
					if(company.getType().equals("Customer"))
						listOfSubmittedMiaReport.add(name);
				}
			}
		}
		int i=0;
		if(Integer.parseInt(id)>0)
		{	
			i=1;
			List<StdBusinessProcess> stdProcess=userService.getSBPList();
			model.addAttribute("stdProcess",stdProcess);
		}
		else
		{
			requirment= new RequirementsList();
		}
		model.addAttribute("displayTable", 0);
		model.addAttribute("disableLevel", i);
		model.addAttribute("idOfMia", requirment);
		model.addAttribute("listOfSubmittedMiaReport",listOfSubmittedMiaReport);
		return new ModelAndView("MIASystemsReport");
	}
	
	String searchMiaTable=null;
	RequirementsList listofMia=null;
	@RequestMapping("submitMiaSearchCriteria")
	public ModelAndView submitMiaSearchCriteria(@RequestParam String page,@ModelAttribute("idOfMia")RequirementsList requirment,HttpServletRequest request,ModelMap model) throws Exception
	{
		LoginModel lgModel = new LoginModel();
		login = (Login)request.getSession().getAttribute("loggedIn");
		if(login==null)
			return new ModelAndView("login", "loginDetails", new Login());
		lgModel.setLoginModel(login);
		model.addAttribute("lgModel",lgModel);
		int pageno=Integer.parseInt(page);
		if(pageno==0)
		{
			listofMia=requirment;
			pageno=1;
		}
		List<RequirementsList> listOfSubmittedMiaReport1=userService.getSubmittedMiaList();
		List<RequirementsList> listOfSubmittedMiaReport= new ArrayList<>();
		List<CompanyDetails> companies=userService.getListOfCompanies();
		for(RequirementsList name:listOfSubmittedMiaReport1)
		{
			for(CompanyDetails company:companies)
			{
				if(name.getCompany().equals(company.getCompanyName()))
				{
					if(company.getType().equals("Customer"))
						listOfSubmittedMiaReport.add(name);
				}
			}
		}
		searchMiaTable="select DISTINCT submitted_systems from ( SELECT SUBSTR(submitted_systems,(DECODE(LEVEL,1,1,INSTR(submitted_systems, ',', 1, LEVEL - 1) + 1)),(DECODE((INSTR(submitted_systems, ',', 1, LEVEL)),0,LENGTH(submitted_systems) + 1,INSTR(submitted_systems, ',', 1, LEVEL))-DECODE(LEVEL,1,1,INSTR(submitted_systems, ',', 1, LEVEL - 1) + 1))) submitted_systems  FROM (SELECT  LISTAGG(submitted_systems, ',') WITHIN GROUP (ORDER BY submitted_systems) AS submitted_systems from (SELECT  LISTAGG(submitted_systems, ',') WITHIN GROUP (ORDER BY submitted_systems) AS submitted_systems from (select distinct submitted_systems from MIA_FORM where STD_PROCESS='"+listofMia.getUserid()+"' and REQ_ID='"+listofMia.getReq_id()+"' )))CONNECT BY LEVEL <= LENGTH(submitted_systems)-LENGTH(TRANSLATE(submitted_systems, '~,', '~')) + 1)";
		List<StdBusinessProcess> stdProcess=userService.getSBPList();
		model.addAttribute("stdProcess",stdProcess);
		model.addAttribute("disableLevel", 1);
		model.addAttribute("listOfSubmittedMiaReport",listOfSubmittedMiaReport);
		model.addAttribute("idOfMia", listofMia);
		int recordsPerPage =7;
		List<String> list = userService.viewAllMiaDetails((pageno-1)*recordsPerPage,
								 recordsPerPage,searchMiaTable);
		int noOfRecords = userService.getNoOfRecordsValueMia();
		int noOfPages = (int) Math.ceil(noOfRecords * 1.0 / recordsPerPage);
		model.addAttribute("noOfPages", noOfPages);
		model.addAttribute("currentPage", pageno);
		model.addAttribute("List", list);
		model.addAttribute("displayTable", 1);
		String company=null,site=null;
			for(RequirementsList name:listOfSubmittedMiaReport1)
			{	if(requirment.getReq_id().equals(name.getReq_id()))
			{
				company=name.getCompany();
				site=name.getSite();
				
			}
				
			}
				List<Systems> systems = userService.getSystems(company,site);	
				model.addAttribute("systems",systems);
				
		if(list.isEmpty())
		{	model.addAttribute("noData",1);}
		return new ModelAndView("MIASystemsReport");
	}
	@RequestMapping("exportToExcelMIASystems")
	public ModelAndView exportToExcelMIASystems(HttpServletRequest request,ModelMap model) throws Exception
	{
		LoginModel lgModel = new LoginModel();
		login = (Login)request.getSession().getAttribute("loggedIn");
		if(login==null)
			return new ModelAndView("login", "loginDetails", new Login());
		lgModel.setLoginModel(login);
		model.addAttribute("lgModel",lgModel);
		model.addAttribute("idOfRequirement",listofMia);
		List<String> list =userService.getMiaToExcel(searchMiaTable);
		return new ModelAndView("exportToExcelMIASystems","List",list);
	}
	@RequestMapping("exportRequirements")
	public ModelAndView exportRequirements(HttpServletRequest request,ModelMap model) throws Exception
	{
		LoginModel lgModel = new LoginModel();
		login = (Login)request.getSession().getAttribute("loggedIn");
		if(login==null)
			return new ModelAndView("login", "loginDetails", new Login());
		lgModel.setLoginModel(login);
		model.addAttribute("lgModel",lgModel);
		model.addAttribute("idOfRequirement",listofReq);
		List<RequirementFormDetails> list =userService.getRequirementsToExcel(searchTable);
		return new ModelAndView("exportRequirementGathering","List",list);
	} 
	@RequestMapping("showSupplierSummaryScore")
	public ModelAndView showSupplierSummaryScore(ModelMap model,HttpServletRequest request, HttpServletResponse response) 
	{
		userService.clearConnections();
		LoginModel lgModel = new LoginModel();
		login = (Login) request.getSession().getAttribute("loggedIn");
		if (login == null)
			return new ModelAndView("login", "loginDetails", new Login());
		lgModel.setLoginModel(login);
		model.addAttribute("lgModel",lgModel);
		List<String> suppliers1 = userService.getSupplierList();
		List<String> suppliers=new ArrayList<>();
		List<CompanyDetails> companies=userService.getListOfCompanies();
		for(String name:suppliers1)
		{
			for(CompanyDetails company:companies)
			{
				if(name.equals(company.getCompanyName()))
				{
					if(company.getType().equals("Supplier"))
						suppliers.add(name);
				}
			}
		}
		model.addAttribute("suppliers",suppliers);
		List<StdBusinessProcess> modules = userService.getSBPList();
		model.addAttribute("modules",modules);
		model.addAttribute("searchCriteria",new Role());
		model.addAttribute("report",0);
		return new ModelAndView("SupplierScore");
	}
	@RequestMapping("showSupplierSummaryFitment")
	public ModelAndView showSupplierSummaryFitment(ModelMap model,HttpServletRequest request, HttpServletResponse response) 
	{
		userService.clearConnections();
		LoginModel lgModel = new LoginModel();
		login = (Login) request.getSession().getAttribute("loggedIn");
		if (login == null)
			return new ModelAndView("login", "loginDetails", new Login());
		lgModel.setLoginModel(login);
		model.addAttribute("lgModel", lgModel);
		List<StdBusinessProcess> modules = userService.getSBPList();
		model.addAttribute("modules",modules);
		model.addAttribute("searchCriteria",new Role());
		model.addAttribute("report",0);
		return new ModelAndView("SummaryFitment");
	}@RequestMapping("exportFitmentReport")
	public ModelAndView exportFitmentReport(@ModelAttribute("searchCriteria")Role searchCriteria,ModelMap model,HttpServletRequest request, HttpServletResponse response) throws FileNotFoundException, IOException 
	{
		userService.clearConnections();
		LoginModel lgModel = new LoginModel();
		login = (Login) request.getSession().getAttribute("loggedIn");
		if (login == null)
			return new ModelAndView("login", "loginDetails", new Login());
		lgModel.setLoginModel(login);
		model.addAttribute("lgModel", lgModel);
		List<String> suppliers1 = userService.getSupplierList();
		List<String> suppliers=new ArrayList<>();
		List<CompanyDetails> companies=userService.getListOfCompanies();
		for(String name:suppliers1)
		{
			for(CompanyDetails company:companies)
			{
				if(name.equals(company.getCompanyName()))
				{
					if(company.getType().equals("Supplier"))
					{suppliers.add(name);
					}
				}
			}
		}
		model.addAttribute("suppliers",suppliers);
		List<StdBusinessProcess> modules = userService.getSBPList();
		model.addAttribute("modules",modules);
		model.addAttribute("searchCriteria",searchCriteria);
		List<SubBusinessProcess> sub_business_process = userService.getSubBP();
		model.addAttribute("sub_business_process", sub_business_process);
		List<SupplierRatingDetails> scoresList = new ArrayList<>();
		for(int count=0;count<suppliers.size();count++)
		{
			for(int count1=0;count1<sub_business_process.size();count1++)
			{
				SupplierRatingDetails score = userService.getSupplierRatingsScore(suppliers.get(count),sub_business_process.get(count1).getSBP_ID());
				score.setComments(Integer.toString((int)Math.floor(Double.parseDouble(score.getComments())/9*100)));
				
				scoresList.add(score);
			}
		}
		model.addAttribute("report",1);
		model.addAttribute("scoresList", scoresList);
		List<Role> moduleData = new ArrayList<>();
		Role modulePresent = new Role();
		for(int count2=0;count2<modules.size();count2++)
		{
			modulePresent = userService.checkModuleData(modules.get(count2).getProcessId());
			moduleData.add(modulePresent);
		}
		
		List<Role> paths = new ArrayList<>();
		if(searchCriteria.getRoleid()==0)
		{
			List<Ratings> scores=new ArrayList<Ratings>();
			scores=exportplotGroupChart(request,modules,scoresList,suppliers,sub_business_process);
			model.addAttribute("scores", scores);
		}
		else{
		for(int i=0;i<modules.size();i++)
		{
			Role path = new Role();
				path.setRoleName("images/"+modules.get(i).getProcessName()+"1.png");
				path.setRoleid(modules.get(i).getProcessId());
				paths.add(path);
				model.addAttribute("paths", paths);
			}
			
		}
		
		model.addAttribute("moduleData", moduleData);
		
		return new ModelAndView("exportSummaryFitment");
	}
	public List<Ratings> exportplotGroupChart(HttpServletRequest request,List<StdBusinessProcess> module,List<SupplierRatingDetails> scoresList,List<String> suppliers,List<SubBusinessProcess> sub_business_process ) throws FileNotFoundException, IOException
	{
		List<Ratings> score=new ArrayList<Ratings>();
		int total=0;
		for(StdBusinessProcess id2: module)
		{
			for(String  name:suppliers)
			{
				Ratings suppplierDetails=new Ratings();
				double avg=0;
				total=0;
				for(SupplierRatingDetails test:scoresList)
				{
					if(test.getReq_id().equals(name))
					{
						for(SubBusinessProcess id: sub_business_process)
						{
							if(id2.getProcessId()==id.getPROCESS_ID() && id.getSBP_ID()==test.getSp_id())
							{
							avg=avg+Double.parseDouble(test.getComments());
							
							++total;
							}
						}
					}
				}
			avg=avg/total;
			suppplierDetails.setDescription(name);
			suppplierDetails.setNumber((int)Math.round(avg));
			suppplierDetails.setRating(id2.getProcessId());
			score.add(suppplierDetails);
		}}
		 
		total=0;
		int value=0;
		for(int i=0;i<suppliers.size();i++)
		{
			total=0;
			Ratings suppplierDetails=new Ratings();
			value=0;
			for(int j=0;j<score.size();j++)
			{
				if(suppliers.get(i).equals(score.get(j).getDescription()))
				{
					if(score.get(j).getNumber()!=0){
					value=value+score.get(j).getNumber();
					++total;}
				}
			}
			value=value/total;
			suppplierDetails.setDescription(suppliers.get(i));
			suppplierDetails.setRating(0);
			suppplierDetails.setNumber(value);
			score.add(suppplierDetails);
		}
		return score;
	}
	@RequestMapping("getFitmentReport")
	public ModelAndView getFitmentReport(@ModelAttribute("searchCriteria")Role searchCriteria,ModelMap model,HttpServletRequest request, HttpServletResponse response) throws FileNotFoundException, IOException 
	{
		userService.clearConnections();
		LoginModel lgModel = new LoginModel();
		login = (Login) request.getSession().getAttribute("loggedIn");
		if (login == null)
			return new ModelAndView("login", "loginDetails", new Login());
		lgModel.setLoginModel(login);
		model.addAttribute("lgModel", lgModel);
		List<String> suppliers1 = userService.getSupplierList();
		List<String> suppliers=new ArrayList<>();
		List<CompanyDetails> companies=userService.getListOfCompanies();
		for(String name:suppliers1)
		{
			for(CompanyDetails company:companies)
			{
				if(name.equals(company.getCompanyName()))
				{
					if(company.getType().equals("Supplier"))
					{suppliers.add(name);
					}
				}
			}
		}
		model.addAttribute("suppliers",suppliers);
		List<StdBusinessProcess> modules = userService.getSBPList();
		model.addAttribute("modules",modules);
		model.addAttribute("searchCriteria",searchCriteria);
		List<SubBusinessProcess> sub_business_process = userService.getSubBP();
		model.addAttribute("sub_business_process", sub_business_process);
		List<SupplierRatingDetails> scoresList = new ArrayList<>();
		for(int count=0;count<suppliers.size();count++)
		{
			for(int count1=0;count1<sub_business_process.size();count1++)
			{
				SupplierRatingDetails score = userService.getSupplierRatingsScore(suppliers.get(count),sub_business_process.get(count1).getSBP_ID());
				score.setComments(Integer.toString((int)Math.floor(Double.parseDouble(score.getComments())/9*100)));
				
				scoresList.add(score);
			}
		}
		model.addAttribute("report",1);
		model.addAttribute("scoresList", scoresList);
		List<Role> moduleData = new ArrayList<>();
		Role modulePresent = new Role();
		for(int count2=0;count2<modules.size();count2++)
		{
			modulePresent = userService.checkModuleData(modules.get(count2).getProcessId());
			moduleData.add(modulePresent);
		}
		
		List<Role> paths = new ArrayList<>();
		if(searchCriteria.getRoleid()==0)
		{
			List<Ratings> scores=new ArrayList<Ratings>();
			scores=plotGroupChart(request,modules,scoresList,suppliers,sub_business_process);
			model.addAttribute("scores", scores);
		}
		else{
		for(int i=0;i<modules.size();i++)
		{
			Role path = new Role();
				path.setRoleName(plotBarGraphFitment(request,modules.get(i),scoresList,suppliers,sub_business_process));
				path.setRoleid(modules.get(i).getProcessId());
				paths.add(path);
				model.addAttribute("paths", paths);
			}
			
		}
		
		model.addAttribute("moduleData", moduleData);
		
		return new ModelAndView("SummaryFitment");
	}
	public List<Ratings> plotGroupChart(HttpServletRequest request,List<StdBusinessProcess> module,List<SupplierRatingDetails> scoresList,List<String> suppliers,List<SubBusinessProcess> sub_business_process ) throws FileNotFoundException, IOException
	{
		List<Ratings> score=new ArrayList<Ratings>();
		int total=0;
		for(StdBusinessProcess id2: module)
		{
			for(String  name:suppliers)
			{
				Ratings suppplierDetails=new Ratings();
				double avg=0;
				total=0;
				for(SupplierRatingDetails test:scoresList)
				{
					if(test.getReq_id().equals(name))
					{
						for(SubBusinessProcess id: sub_business_process)
						{
							if(id2.getProcessId()==id.getPROCESS_ID() && id.getSBP_ID()==test.getSp_id())
							{
							avg=avg+Double.parseDouble(test.getComments());
							
							++total;
							}
						}
					}
				}
			avg=avg/total;
			suppplierDetails.setDescription(name);
			suppplierDetails.setNumber((int)Math.round(avg));
			suppplierDetails.setRating(id2.getProcessId());
			score.add(suppplierDetails);
		}}
		DefaultCategoryDataset dataset = new DefaultCategoryDataset();  
		total=0;
		int value=0;
		for(int i=0;i<suppliers.size();i++)
		{
			total=0;
			Ratings suppplierDetails=new Ratings();
			value=0;
			for(int j=0;j<score.size();j++)
			{
				if(suppliers.get(i).equals(score.get(j).getDescription()))
				{
					for(StdBusinessProcess mod : module)
					{
						if(mod.getProcessId()==score.get(j).getRating())
						{
							if(score.get(j).getNumber()!=0)
							dataset.addValue(score.get(j).getNumber(), score.get(j).getDescription(), mod.getProcessName()+" Operation Management");
						}
					}
					if(score.get(j).getNumber()!=0){
					value=value+score.get(j).getNumber();
					++total;}
				}
			}
			value=value/total;
			dataset.addValue(value, suppliers.get(i),"Overall");
			suppplierDetails.setDescription(suppliers.get(i));
			suppplierDetails.setRating(0);
			suppplierDetails.setNumber(value);
			score.add(suppplierDetails);
		}
		
		JFreeChart chart = null;
		
		 chart = ChartFactory.createBarChart("Overall Supplier Summary Fitment", "Suppliers", "", dataset);

	
		
		  chart.getTitle().setPaint(Color.BLUE); 
		  TextTitle title = chart.getTitle();
          Font font = title.getFont();
          float size = font.getSize();
          chart.getTitle().setFont(font.deriveFont(size -3));
          
		  CategoryPlot cp = chart.getCategoryPlot();   
		  cp.setRangeGridlinePaint(Color.BLUE);
		  BufferedImage bi = chart.createBufferedImage(400,300);
		  String path=request.getServletContext().getRealPath("")+"/images/overall.png";
		  File file = new File(path);
		 
		  if(file.exists())
		  {
			  file.delete();
		  }
		  file.createNewFile();
		 FileOutputStream ioStream = new FileOutputStream(file);
		 ImageIO.write(bi, "png",ImageIO.createImageOutputStream(ioStream));
		 ioStream.flush();
		 ioStream.close();
		 
		return score;
	}
	public String plotBarGraphFitment(HttpServletRequest request,StdBusinessProcess module,List<SupplierRatingDetails> scoresList,List<String> suppliers,List<SubBusinessProcess> sub_business_process ) throws FileNotFoundException, IOException
	{
		
		DefaultCategoryDataset bardataset = new DefaultCategoryDataset();  
		List<Integer> scores=new ArrayList<Integer>();
		for(String  name:suppliers)
		{
			double avg=0;
			int total=0;
			for(SupplierRatingDetails test:scoresList)
			{
				if(test.getReq_id().equals(name))
				{
					for(SubBusinessProcess id: sub_business_process)
					{
					if(module.getProcessId()==id.getPROCESS_ID() && id.getSBP_ID()==test.getSp_id())
					{
					avg=avg+Double.parseDouble(test.getComments());
					++total;
					}
					}
				}
			}
			avg=avg/total;
			scores.add((int)Math.round(avg));
		}
		for(int i=0;i<scores.size();i++)
			{
				bardataset.setValue(scores.get(i),suppliers.get(i),suppliers.get(i) );  
			}
		
		 
		JFreeChart chart = null;
		
			 chart = ChartFactory.createBarChart(module.getProcessName()+" Operation Management", "Suppliers", "", bardataset);

		
			
			  chart.getTitle().setPaint(Color.BLUE);  
			  TextTitle title = chart.getTitle();
	            Font font = title.getFont();
	            float size = font.getSize();
	            chart.getTitle().setFont(font.deriveFont(size -3));
	            
			  CategoryPlot cp = chart.getCategoryPlot();   
			  BarRenderer renderer = (BarRenderer) cp.getRenderer();
			  renderer.setItemMargin(-1);
			        cp.setRangeGridlinePaint(Color.BLUE);
			  BufferedImage bi = chart.createBufferedImage(400,300);
			  String path=request.getServletContext().getRealPath("")+"/images/"+module.getProcessName()+"1.png";
			  File file = new File(path);
			 
			  if(file.exists())
			  {
				  file.delete();
			  }
			  file.createNewFile();
			 FileOutputStream ioStream = new FileOutputStream(file);
			 ImageIO.write(bi, "png",ImageIO.createImageOutputStream(ioStream));
			 ioStream.flush();
			 ioStream.close();
			 return "images/"+module.getProcessName()+"1.png";
	}
	@RequestMapping("reportList")
	public ModelAndView showReportList(HttpServletRequest request, HttpServletResponse response,ModelMap model)
	{
		LoginModel lgModel = new LoginModel();
		login = (Login) request.getSession().getAttribute("loggedIn");
		if (login == null)
			return new ModelAndView("login", "loginDetails", new Login());
		lgModel.setLoginModel(login);
		model.addAttribute("lgModel", lgModel);	
		return new ModelAndView("selectReport");
	}  
	@RequestMapping("downloadScoreReport")
	public ModelAndView downloadScoreReport(@ModelAttribute("searchCriteria")Role searchCriteria,ModelMap model,HttpServletRequest request, HttpServletResponse response) 
	{
		userService.clearConnections();
		LoginModel lgModel = new LoginModel();
		login = (Login) request.getSession().getAttribute("loggedIn");
		if (login == null)
			return new ModelAndView("login", "loginDetails", new Login());
		lgModel.setLoginModel(login);
		model.addAttribute("lgModel", lgModel);
		List<String> suppliers1 = userService.getSupplierList();
		List<String> suppliers=new ArrayList<>();
		List<CompanyDetails> companies=userService.getListOfCompanies();
		for(String name:suppliers1)
		{
			for(CompanyDetails company:companies)
			{
				if(name.equals(company.getCompanyName()))
				{
					if(company.getType().equals("Supplier"))
						suppliers.add(name);
				}
			}
		}
		model.addAttribute("suppliers",suppliers);
		List<StdBusinessProcess> modules = userService.getSBPList();
		model.addAttribute("modules",modules);
		model.addAttribute("searchCriteria",searchCriteria);
		List<SubBusinessProcess> sub_business_process = userService.getSubBP();
		model.addAttribute("sub_business_process", sub_business_process);
		List<SupplierRatingDetails> scoresList = new ArrayList<>();
		for(int count=0;count<suppliers.size();count++)
		{
			for(int count1=0;count1<sub_business_process.size();count1++)
			{
				SupplierRatingDetails score = userService.getSupplierRatingsScore(suppliers.get(count),sub_business_process.get(count1).getSBP_ID());
				scoresList.add(score);
			}
		}
		model.addAttribute("report",1);
		model.addAttribute("scoresList", scoresList);
		List<Role> moduleData = new ArrayList<>();
		Role modulePresent = new Role();
		for(int count2=0;count2<modules.size();count2++)
		{
			modulePresent = userService.checkModuleData(modules.get(count2).getProcessId());
			moduleData.add(modulePresent);
		}
		
		List<Role> paths = new ArrayList<>();
		
		for(int i=0;i<modules.size();i++)
		{
			Role path = new Role();
			if(searchCriteria.getRoleName().equals("All"))
			{
			path.setRoleName("images/"+modules.get(i).getProcessName()+".png");
			}
			else 
				{
				List<String> supp =  new ArrayList<String>();
				supp.add(searchCriteria.getRoleName());
				path.setRoleName("images/"+modules.get(i).getProcessName()+".png");
				}
			path.setRoleid(modules.get(i).getProcessId());
			paths.add(path);
		}
		model.addAttribute("paths", paths);
		model.addAttribute("moduleData", moduleData);
		
		return new ModelAndView("DownloadScoreReport");
	} 
	@RequestMapping("changeCriteria")
	public ModelAndView changeCriteria(@ModelAttribute("searchCriteria")Role searchCriteria,ModelMap model,HttpServletRequest request, HttpServletResponse response) 
	{
		userService.clearConnections();
		LoginModel lgModel = new LoginModel();
		login = (Login) request.getSession().getAttribute("loggedIn");
		if (login == null)
			return new ModelAndView("login", "loginDetails", new Login());
		lgModel.setLoginModel(login);
		model.addAttribute("lgModel", lgModel);
		List<String> suppliers1 = userService.getSupplierList();
		List<String> suppliers=new ArrayList<>();
		List<CompanyDetails> companies=userService.getListOfCompanies();
		for(String name:suppliers1)
		{
			for(CompanyDetails company:companies)
			{
				if(name.equals(company.getCompanyName()))
				{
					if(company.getType().equals("Supplier"))
						suppliers.add(name);
				}
			}
		}
		model.addAttribute("suppliers",suppliers);
		List<StdBusinessProcess> modules = userService.getSBPList();
		model.addAttribute("modules",modules);
		model.addAttribute("searchCriteria",searchCriteria);
		model.addAttribute("report",0);
		return new ModelAndView("SupplierScore");
	} 
	
	@RequestMapping("getScoreReport")
	public ModelAndView getScoreReport(@ModelAttribute("searchCriteria")Role searchCriteria,ModelMap model,HttpServletRequest request, HttpServletResponse response) throws FileNotFoundException, IOException 
	{
		userService.clearConnections();
		LoginModel lgModel = new LoginModel();
		login = (Login) request.getSession().getAttribute("loggedIn");
		if (login == null)
			return new ModelAndView("login", "loginDetails", new Login());
		lgModel.setLoginModel(login);
		model.addAttribute("lgModel", lgModel);
		List<String> suppliers1 = userService.getSupplierList();
		List<String> suppliers=new ArrayList<>();
		List<CompanyDetails> companies=userService.getListOfCompanies();
		for(String name:suppliers1)
		{
			for(CompanyDetails company:companies)
			{
				if(name.equals(company.getCompanyName()))
				{
					if(company.getType().equals("Supplier"))
						suppliers.add(name);
				}
			}
		}
		model.addAttribute("suppliers",suppliers);
		List<StdBusinessProcess> modules = userService.getSBPList();
		model.addAttribute("modules",modules);
		model.addAttribute("searchCriteria",searchCriteria);
		List<SubBusinessProcess> sub_business_process = userService.getSubBP();
		model.addAttribute("sub_business_process", sub_business_process);
		List<SupplierRatingDetails> scoresList = new ArrayList<>();
		for(int count=0;count<suppliers.size();count++)
		{
			for(int count1=0;count1<sub_business_process.size();count1++)
			{
				SupplierRatingDetails score = userService.getSupplierRatingsScore(suppliers.get(count),sub_business_process.get(count1).getSBP_ID());
				scoresList.add(score);
			}
		}
		model.addAttribute("report",1);
		model.addAttribute("scoresList", scoresList);
		List<Role> moduleData = new ArrayList<>();
		Role modulePresent = new Role();
		for(int count2=0;count2<modules.size();count2++)
		{
			modulePresent = userService.checkModuleData(modules.get(count2).getProcessId());
			moduleData.add(modulePresent);
		}
		
		List<Role> paths = new ArrayList<>();
		
		for(int i=0;i<modules.size();i++)
		{
			Role path = new Role();
			if(searchCriteria.getRoleName().equals("All"))
			{
			path.setRoleName(plotGraph(request,modules.get(i),suppliers,sub_business_process,scoresList));
			}
			else 
				{
				List<String> supp =  new ArrayList<String>();
				supp.add(searchCriteria.getRoleName());
				path.setRoleName(plotGraph(request,modules.get(i),supp,sub_business_process,scoresList));
				}
			path.setRoleid(modules.get(i).getProcessId());
			paths.add(path);
		}
		model.addAttribute("paths", paths);
		model.addAttribute("moduleData", moduleData);
		
		return new ModelAndView("SupplierScore");
	}
	
	public String plotGraph(HttpServletRequest request,StdBusinessProcess modules ,List<String> supplier,List<SubBusinessProcess> sub_business_process,List<SupplierRatingDetails> scoresList) throws FileNotFoundException, IOException
	{
		String[] suppliers = new String[supplier.size()];
		for(int count=0;count<supplier.size();count++)
		{
			suppliers[count] = supplier.get(count);
		}
		
		DefaultCategoryDataset dataset = new DefaultCategoryDataset();  
		
		for(int count2=0;count2<supplier.size();count2++)
		{
			for(int count3=0;count3<sub_business_process.size();count3++)
			{
				if(sub_business_process.get(count3).getPROCESS_ID()==modules.getProcessId())
				{
				for(SupplierRatingDetails scores :scoresList)
				{
					if(scores.getSp_id()==sub_business_process.get(count3).getSBP_ID() && scores.getReq_id().equals(supplier.get(count2)) )
					{
						dataset.addValue(Double.parseDouble(scores.getComments()), suppliers[count2], sub_business_process.get(count3).getSBP_NAME());  
						
					}
				}}
				
			}
		}
			
			
			SpiderWebPlot plot = new SpiderWebPlot(dataset);        
			plot.setStartAngle(90);       
			plot.setInteriorGap(0.4);        
			plot.setToolTipGenerator(new StandardCategoryToolTipGenerator());        
			JFreeChart chart = new JFreeChart(modules.getProcessName()+" operation management", TextTitle.DEFAULT_FONT, plot, true); 
			BufferedImage bi = chart.createBufferedImage(500,300);
			bi.createGraphics();
			String path=request.getServletContext().getRealPath("")+"/images/"+modules.getProcessName()+".png";
		File file = new File(path);
	    if(file.exists())
	    {
	    	file.delete();
	    }
	    
	    file.createNewFile();
	    FileOutputStream a=new FileOutputStream(path);
	    ImageIO.write(bi, "png",ImageIO.createImageOutputStream(a));
	    
	    a.flush();
	    a.close();
	    bi.flush();
	    return "images/"+modules.getProcessName()+".png";
      
	}
	@RequestMapping("getSystemGraph")
	public ModelAndView getSystemGraph(ModelMap model,HttpServletRequest request, HttpServletResponse response) throws FileNotFoundException, IOException 
	{
		userService.clearConnections();
		LoginModel lgModel = new LoginModel();
		login = (Login) request.getSession().getAttribute("loggedIn");
		if (login == null)
			return new ModelAndView("login", "loginDetails", new Login());
		lgModel.setLoginModel(login);
		model.addAttribute("lgModel", lgModel);
		List<HomeDetails> customers1 = userService.getCustomerSystemList();
		List<Supplier_Customer> customers=new ArrayList<>();
		List<CompanyDetails> companies=userService.getListOfCompanies();
		int id=1;
		for(HomeDetails name:customers1)
		{
			for(CompanyDetails company:companies)
			{
				if(name.getModuleName().equals(company.getCompanyName()))
				{
					Supplier_Customer cust = new Supplier_Customer();
					if(company.getType().equals("Customer") )
					{
						cust.setSupplier_id(name.getModuleName());
						cust.setCustomer_company(name.getDescription());
						cust.setId(id);
						customers.add(cust);
						id++;
					}
				}
			}
		}
		model.addAttribute("customers",customers);
		model.addAttribute("report",0);
		model.addAttribute("searchCriteria",new Systems());
		model.addAttribute("system",0);
		return new ModelAndView("SystemGraph");
	}
	
	@RequestMapping("getSystemGraph1")
	public ModelAndView getSystemGraph1(ModelMap model,HttpServletRequest request, HttpServletResponse response) throws FileNotFoundException, IOException 
	{
		userService.clearConnections();
		LoginModel lgModel = new LoginModel();
		login = (Login) request.getSession().getAttribute("loggedIn");
		if (login == null)
			return new ModelAndView("login", "loginDetails", new Login());
		lgModel.setLoginModel(login);
		model.addAttribute("lgModel", lgModel);
		List<HomeDetails> customers1 = userService.getCustomerSystemList();
		List<Supplier_Customer> customers=new ArrayList<>();
		List<CompanyDetails> companies=userService.getListOfCompanies();
		
		int id=1;
		for(HomeDetails name:customers1)
		{
			for(CompanyDetails company:companies)
			{
				if(name.getModuleName().equals(company.getCompanyName()))
				{
					Supplier_Customer cust = new Supplier_Customer();
					if(company.getType().equals("Customer") )
					{
						cust.setSupplier_id(name.getModuleName());
						cust.setCustomer_company(name.getDescription());
						cust.setId(id);
						customers.add(cust);
						id++;
					}
				}
			}
		}
		model.addAttribute("customers",customers);
		model.addAttribute("report",0);
		model.addAttribute("searchCriteria",new Systems());
		model.addAttribute("system",0);
		return new ModelAndView("SystemDetailsGrid");
	}
	
	@RequestMapping("changeSearch")
	public ModelAndView changeSearch(@ModelAttribute ("searchCriteria")Systems searchCriteria ,ModelMap model,HttpServletRequest request, HttpServletResponse response) throws FileNotFoundException, IOException 
	{
		userService.clearConnections();
		LoginModel lgModel = new LoginModel();
		login = (Login) request.getSession().getAttribute("loggedIn");
		if (login == null)
			return new ModelAndView("login", "loginDetails", new Login());
		lgModel.setLoginModel(login);
		model.addAttribute("lgModel", lgModel);
		List<HomeDetails> customers1 = userService.getCustomerSystemList();
		List<Supplier_Customer> customers=new ArrayList<>();
		List<CompanyDetails> companies=userService.getListOfCompanies();
		
		int id=1;
		for(HomeDetails name:customers1)
		{
			for(CompanyDetails company:companies)
			{
				if(name.getModuleName().equals(company.getCompanyName()))
				{
					Supplier_Customer cust = new Supplier_Customer();
					if(company.getType().equals("Customer") )
					{
						cust.setSupplier_id(name.getModuleName());
						cust.setCustomer_company(name.getDescription());
						cust.setId(id);
						customers.add(cust);
						id++;
					}
				}
			}
		}
		model.addAttribute("customers",customers);
		model.addAttribute("report",0);
		model.addAttribute("searchCriteria",searchCriteria);
		model.addAttribute("system",0);
		return new ModelAndView("SystemGraph");
	}
	
	
	@RequestMapping("changeSearch1")
	public ModelAndView changeSearch1(@ModelAttribute ("searchCriteria")Systems searchCriteria ,ModelMap model,HttpServletRequest request, HttpServletResponse response) throws FileNotFoundException, IOException 
	{
		userService.clearConnections();
		LoginModel lgModel = new LoginModel();
		login = (Login) request.getSession().getAttribute("loggedIn");
		if (login == null)
			return new ModelAndView("login", "loginDetails", new Login());
		lgModel.setLoginModel(login);
		model.addAttribute("lgModel", lgModel);
		List<HomeDetails> customers1 = userService.getCustomerSystemList();
		List<Supplier_Customer> customers=new ArrayList<>();
		List<CompanyDetails> companies=userService.getListOfCompanies();
		
		int id=1;
		for(HomeDetails name:customers1)
		{
			for(CompanyDetails company:companies)
			{
				if(name.getModuleName().equals(company.getCompanyName()))
				{
					Supplier_Customer cust = new Supplier_Customer();
					if(company.getType().equals("Customer") )
					{
						cust.setSupplier_id(name.getModuleName());
						cust.setCustomer_company(name.getDescription());
						cust.setId(id);
						customers.add(cust);
						id++;
					}
				}
			}
		}
		model.addAttribute("customers",customers);
		model.addAttribute("report",0);
		model.addAttribute("searchCriteria",searchCriteria);
		model.addAttribute("system",0);
		return new ModelAndView("SystemDetailsGrid");
	}
	
	@RequestMapping("selectSystems")
	public ModelAndView selectSystems(@ModelAttribute ("searchCriteria")Systems searchCriteria ,ModelMap model,HttpServletRequest request, HttpServletResponse response) throws FileNotFoundException, IOException 
	{
		userService.clearConnections();
		LoginModel lgModel = new LoginModel();
		login = (Login) request.getSession().getAttribute("loggedIn");
		if (login == null)
			return new ModelAndView("login", "loginDetails", new Login());
		lgModel.setLoginModel(login);
		model.addAttribute("lgModel", lgModel);
		List<HomeDetails> customers1 = userService.getCustomerSystemList();
		List<Supplier_Customer> customers=new ArrayList<>();
		List<CompanyDetails> companies=userService.getListOfCompanies();
	
		int id=1;
		for(HomeDetails name:customers1)
		{
			for(CompanyDetails company:companies)
			{
				if(name.getModuleName().equals(company.getCompanyName()))
				{
					Supplier_Customer cust = new Supplier_Customer();
					if(company.getType().equals("Customer") )
					{
						cust.setSupplier_id(name.getModuleName());
						cust.setCustomer_company(name.getDescription());
						cust.setId(id);
						customers.add(cust);
						id++;
					}
				}
			}
		}
		model.addAttribute("customers",customers);
		model.addAttribute("report",0);
		model.addAttribute("system",1);
		List<Systems> systems = userService.getSystems(customers.get(searchCriteria.getSys_ID()-1).getSupplier_id(),customers.get(searchCriteria.getSys_ID()-1).getCustomer_company());

		model.addAttribute("systems", systems);
		model.addAttribute("searchCriteria",searchCriteria);
		return new ModelAndView("SystemGraph");
	}
	
	@RequestMapping("selectSystems1")
	public ModelAndView selectSystems1(@ModelAttribute ("searchCriteria")Systems searchCriteria ,ModelMap model,HttpServletRequest request, HttpServletResponse response) throws FileNotFoundException, IOException 
	{
		userService.clearConnections();
		LoginModel lgModel = new LoginModel();
		login = (Login) request.getSession().getAttribute("loggedIn");
		if (login == null)
			return new ModelAndView("login", "loginDetails", new Login());
		lgModel.setLoginModel(login);
		model.addAttribute("lgModel", lgModel);
		List<HomeDetails> customers1 = userService.getCustomerSystemList();
		List<Supplier_Customer> customers=new ArrayList<>();
		List<CompanyDetails> companies=userService.getListOfCompanies();
		int id=1;
		for(HomeDetails name:customers1)
		{
			for(CompanyDetails company:companies)
			{
				if(name.getModuleName().equals(company.getCompanyName()))
				{
					Supplier_Customer cust = new Supplier_Customer();
					if(company.getType().equals("Customer") )
					{
						cust.setSupplier_id(name.getModuleName());
						cust.setCustomer_company(name.getDescription());
						cust.setId(id);
						customers.add(cust);
						id++;
					}
				}
			}
		}
		model.addAttribute("customers",customers);
		model.addAttribute("report",0);
		model.addAttribute("system",1);
		List<Systems> systems = userService.getSystems(customers.get(searchCriteria.getSys_ID()-1).getSupplier_id(),customers.get(searchCriteria.getSys_ID()-1).getCustomer_company());
		model.addAttribute("systems", systems);
		model.addAttribute("searchCriteria",searchCriteria);
		return new ModelAndView("SystemDetailsGrid");
	}
	
	@RequestMapping("showBarChart")
	public ModelAndView showBarChart(@ModelAttribute ("searchCriteria")Systems searchCriteria ,ModelMap model,HttpServletRequest request, HttpServletResponse response) throws FileNotFoundException, IOException 
	{
		userService.clearConnections();
		LoginModel lgModel = new LoginModel();
		login = (Login) request.getSession().getAttribute("loggedIn");
		if (login == null)
			return new ModelAndView("login", "loginDetails", new Login());
		lgModel.setLoginModel(login);
		model.addAttribute("lgModel", lgModel);
		List<HomeDetails> customers1 = userService.getCustomerSystemList();
		List<Supplier_Customer> customers=new ArrayList<>();
		List<CompanyDetails> companies=userService.getListOfCompanies();
		int id=1;
		for(HomeDetails name:customers1)
		{
			for(CompanyDetails company:companies)
			{
				if(name.getModuleName().equals(company.getCompanyName()))
				{
					Supplier_Customer cust = new Supplier_Customer();
					if(company.getType().equals("Customer") )
					{
						cust.setSupplier_id(name.getModuleName());
						cust.setCustomer_company(name.getDescription());
						cust.setId(id);
						customers.add(cust);
						id++;
					}
				}
			}
		}
		model.addAttribute("customers",customers);
		model.addAttribute("report",1);
		model.addAttribute("searchCriteria",searchCriteria);
		model.addAttribute("disablelevel",1);
		model.addAttribute("system",0);
		model.addAttribute("load","44");
		List<Role> values = new ArrayList<>();
		String src= null;
		List<Systems> systems = userService.getSystems(customers.get(searchCriteria.getSys_ID()-1).getSupplier_id(),customers.get(searchCriteria.getSys_ID()-1).getCustomer_company());
		values= userService.getAges(searchCriteria.getSystemsID(),systems);
			src = plotBarGraph(request,values,"Age of System");
		values= userService.getUsers(searchCriteria.getSystemsID(),systems);
			String	src1 = plotBarGraph(request,values,"No. of Users");
				model.addAttribute("srcImg",src);
		model.addAttribute("srcImg1",src1);
		
		response.setContentType(src);
		return new ModelAndView("SystemGraph");
	}
	public String plotBarGraph(HttpServletRequest request,List<Role> values,String imgName) throws FileNotFoundException, IOException
	{
		DefaultCategoryDataset bardataset = new DefaultCategoryDataset();  
		 for(int i=0;i<values.size();i++)
			 {
			  bardataset.setValue(values.get(i).getRoleid(),values.get(i).getRoleName() ,values.get(i).getRoleName() );  
				
			 }
		JFreeChart chart = null;
		chart = ChartFactory.createBarChart("System Details("+imgName+")", "Name of Systems", imgName, bardataset);
		
			chart.getTitle().setPaint(Color.BLUE);  
			 TextTitle title = chart.getTitle();
	            Font font = title.getFont();
	            float size = font.getSize();
	            chart.getTitle().setFont(font.deriveFont(size -3));
            
		  CategoryPlot cp = chart.getCategoryPlot();  
		  BarRenderer renderer = (BarRenderer) cp.getRenderer();
		  renderer.setItemMargin(-1);
		  cp.setRangeGridlinePaint(Color.WHITE);
		  BufferedImage bi = chart.createBufferedImage(400,300);
		  String path=request.getServletContext().getRealPath("")+"/images/"+imgName+".png";
		  File file = new File(path);
		 
		  if(file.exists())
		  {
			  file.delete();
		  }
		  file.createNewFile();
		 FileOutputStream ioStream = new FileOutputStream(file);
		 ImageIO.write(bi, "png",ImageIO.createImageOutputStream(ioStream));
		 ioStream.flush();
		 ioStream.close();
		 return "images/"+imgName+".png";
	}
	@RequestMapping("showGrid")
	public ModelAndView showGrid(@ModelAttribute ("searchCriteria")Systems searchCriteria ,ModelMap model,HttpServletRequest request, HttpServletResponse response) throws FileNotFoundException, IOException 
	{
		userService.clearConnections();
		LoginModel lgModel = new LoginModel();
		login = (Login) request.getSession().getAttribute("loggedIn");
		if (login == null)
			return new ModelAndView("login", "loginDetails", new Login());
		lgModel.setLoginModel(login);
		model.addAttribute("lgModel", lgModel);
		List<HomeDetails> customers1 = userService.getCustomerSystemList();
		List<Supplier_Customer> customers=new ArrayList<>();
		List<CompanyDetails> companies=userService.getListOfCompanies();
		int id=1;
		for(HomeDetails name:customers1)
		{
			for(CompanyDetails company:companies)
			{
				if(name.getModuleName().equals(company.getCompanyName()))
				{
					Supplier_Customer cust = new Supplier_Customer();
					if(company.getType().equals("Customer") )
					{
						cust.setSupplier_id(name.getModuleName());
						cust.setCustomer_company(name.getDescription());
						cust.setId(id);
						customers.add(cust);
						id++;
					}
				}
			}
		}
		model.addAttribute("customers",customers);
		model.addAttribute("report",1);
		model.addAttribute("searchCriteria",searchCriteria);
		model.addAttribute("disablelevel",1);
		model.addAttribute("system",0);
		model.addAttribute("load","44");
		List<Role> values = new ArrayList<>();
		
		List<Systems> systems = userService.getSystems(customers.get(searchCriteria.getSys_ID()-1).getSupplier_id(),customers.get(searchCriteria.getSys_ID()-1).getCustomer_company());
		if(searchCriteria.getSys_Name().equals("Age"))
		{
			values= userService.getAges(searchCriteria.getSystemsID(),systems);
			
		}
		else 
			{
				values= userService.getUsers(searchCriteria.getSystemsID(),systems);
				
			}
		
		model.addAttribute("values",values);
		return new ModelAndView("SystemDetailsGrid");
	}
	
	
	@RequestMapping(value = "login", method = RequestMethod.GET)
	public ModelAndView login(@ModelAttribute("loginDetails")Login login, BindingResult bindingResult, 
	HttpServletRequest request,	HttpServletResponse response)  throws Exception
	{
				login = new Login();
				return new ModelAndView("login", "loginDetails", login);
	}

	@RequestMapping(value = "login",method = RequestMethod.POST)	
	public ModelAndView login1(@ModelAttribute("loginDetails")Login login, BindingResult bindingResult, 
	HttpServletRequest request,	HttpServletResponse response)  throws Exception
	{
				try 
				{
					ValidationUtils.rejectIfEmptyOrWhitespace(bindingResult,"userid","userid", "UserID cannot be empty.");
					ValidationUtils.rejectIfEmptyOrWhitespace(bindingResult,"password","password", "Password cannot be empty");

					if (bindingResult.hasErrors())
					{

						return new ModelAndView("login", "loginDetails", login);
					}
					else
					{

						if(userService.validate(login))
						{
							request.getSession().setAttribute("loggedIn", login);
							//Creating a redirection view to success page. This will redirect to UsersController
							RedirectView redirectView = new RedirectView("success1.do", true);
							return new ModelAndView(redirectView);
						}
						else
						{
							bindingResult.addError(new ObjectError("company", "Invalid credentials. " +
									"Username or Password is incorrect."));
							return new ModelAndView("login", "loginDetails", login);
						}
					}
				} catch (Exception e) {
					return new ModelAndView("login", "loginDetails", login);
				}
			}

@RequestMapping("forgotPassword") 
public ModelAndView pwdRecovery(HttpServletRequest request,	HttpServletResponse response,ModelMap model)
		{
	Login id=new Login();
	model.addAttribute("page",1);
			return new ModelAndView("forgotPassword","idCheck",id);
		}

@RequestMapping("checkValidId") 
public ModelAndView pwdRecovery1(@ModelAttribute("idCheck")Login id, BindingResult bindingResult,ModelMap model)
{
	List<CompanyDetails> check=userService.checkIdPresent(id.getUserid());
	if (check.isEmpty())
	{
		model.addAttribute("page",1);
		model.addAttribute("wrongId",1);
		return new ModelAndView("forgotPassword","idCheck",id);
	}
	else
	{	
		String question=userService.getSecretQuestion(check.get(0).getCompanyId());
		model.addAttribute("question",question);
		model.addAttribute("ans",check.get(0).getCompanyName());
		try{
		model.addAttribute("password",PasswordSecurity.decrypt(check.get(0).getType()));}
		catch(Exception e){}
		model.addAttribute("page",2);
		return new ModelAndView("forgotPassword","idCheck",id);
	}
}
@RequestMapping("reg")                         
public ModelAndView reg(@ModelAttribute("regDetails")NewUser register, BindingResult bindingResult, 
		HttpServletRequest request,	HttpServletResponse response,ModelMap model)  throws Exception

{
			List<CompanyDetails> companies=userService.getListOfCompanies();
			model.addAttribute("displaySites", 0);
			model.addAttribute("companies", companies);
			List<Role> recoveryQues = userService.getPswdRecoveryQues();
			model.addAttribute("recoveryQues", recoveryQues);
			register = new NewUser();
			return new ModelAndView("register", "regDetails", register);
}

@RequestMapping("register1")                         
public ModelAndView register1(@ModelAttribute("regDetails")NewUser register, BindingResult bindingResult, 
		HttpServletRequest request,	HttpServletResponse response,ModelMap model)  throws Exception

{
	List<Role> recoveryQues = userService.getPswdRecoveryQues();
	model.addAttribute("recoveryQues", recoveryQues);
			List<CompanyDetails> companies=userService.getListOfCompanies();
			for(CompanyDetails company:companies)
			{
				if(register.getCompany().equals(company.getCompanyName()))
				{
					if(company.getType().equals("Customer"))
					{
						List<SiteDetails> sites=userService.getListOfSites(company.getCompanyId());
						model.addAttribute("displaySites", 1);
						model.addAttribute("sites", sites);
					}
					else
						model.addAttribute("displaySites", 0);
				}
			}
			model.addAttribute("companies", companies);
			return new ModelAndView("register", "regDetails", register);
}
 @RequestMapping(value = "register", method = RequestMethod.POST)	
		public ModelAndView login3(@ModelAttribute("regDetails")NewUser register, BindingResult bindingResult, 
				HttpServletRequest request,	HttpServletResponse response,ModelMap model)  throws Exception
		{
	
	 		if(register.getSiteName()!= null && !register.getSiteName().isEmpty()) 
	 		{}
	 		else
	 			register.setSiteName("None");
			try 
			{
				ValidationUtils.rejectIfEmptyOrWhitespace(bindingResult,"userid","userid", "Field cannot be empty");
				ValidationUtils.rejectIfEmptyOrWhitespace(bindingResult,"firstName","firstName", "Field cannot be empty");
				ValidationUtils.rejectIfEmptyOrWhitespace(bindingResult,"lastName","lastName", "Field cannot be empty.");
				ValidationUtils.rejectIfEmptyOrWhitespace(bindingResult,"company","company", "Field cannot be empty");
				ValidationUtils.rejectIfEmptyOrWhitespace(bindingResult,"pswd","pswd", "Field cannot be empty");
				ValidationUtils.rejectIfEmptyOrWhitespace(bindingResult,"cmpswd","cmpswd", "Field cannot be empty");
				ValidationUtils.rejectIfEmptyOrWhitespace(bindingResult,"pwdQuesAns","pwdQuesAns", "Field cannot be empty");
				if (bindingResult.hasErrors())
				{
					List<CompanyDetails> companies=userService.getListOfCompanies();
					model.addAttribute("companies", companies);
					for(CompanyDetails company:companies)
					{
						if(register.getCompany().equals(company.getCompanyName()))
						{
							if(company.getType().equals("Customer"))
							{
								List<SiteDetails> sites=userService.getListOfSites(company.getCompanyId());
								model.addAttribute("displaySites", 1);
								model.addAttribute("sites", sites);
							}
							else
								model.addAttribute("displaySites", 0);
						}
					}
					
					return new ModelAndView("register", "regDetails", register);
				}
				else
				{
					// If the user details is validated then redirecting the user to success page, 
					// else returning the error message on login page.
					 String status = userService.create(register);
					if(status == "done")
					{
						request.getSession().setAttribute("registered", register);
						//Creating a redirection view to success page. This will redirect to UsersController
						RedirectView redirectView = new RedirectView("success.do", true);
						return new ModelAndView(redirectView);
					}
					else
					{
						List<CompanyDetails> companies=userService.getListOfCompanies();
						model.addAttribute("companies", companies);
						for(CompanyDetails company:companies)
						{
							if(register.getCompany().equals(company.getCompanyName()))
							{
								if(company.getType().equals("Customer"))
								{
									List<SiteDetails> sites=userService.getListOfSites(company.getCompanyId());
									model.addAttribute("displaySites", 1);
									model.addAttribute("sites", sites);
								}
								else
									model.addAttribute("displaySites", 0);
							}
						}
						
						bindingResult.addError(new ObjectError("Invalid", status));
						return new ModelAndView("register", "regDetails", register);
					}
				}
			} catch (Exception e) {
				return new ModelAndView("register", "regDetails", register);
			}
		}

 	@ExceptionHandler({Exception.class})
	public ModelAndView handleIOException(Exception ex,HttpServletRequest request) {
		Logger logger = Logger.getLogger(HomePageController.class);
	        try {   
	        	logger.error("Error Message", ex); 
	        	}catch(Exception e){}   
	    return new ModelAndView("error");
	}
 }
	 
	
