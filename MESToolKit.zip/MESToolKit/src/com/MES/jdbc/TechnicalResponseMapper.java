package com.MES.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;



import org.springframework.jdbc.core.RowMapper;

import com.MES.domain.Technical_Info_Questions;
public class TechnicalResponseMapper  implements RowMapper<Technical_Info_Questions> {   
	  
	 @Override  
	 public Technical_Info_Questions mapRow(ResultSet resultSet, int line) throws SQLException {   
	  DataExtractor userExtractor = new DataExtractor();   
	  return userExtractor.extractTechInfoSaved(resultSet);   
	 }   

}
