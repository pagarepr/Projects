package com.MES.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.MES.domain.NewUser;



public class CustomerMapper implements RowMapper<NewUser> {   
	  
	 @Override  
	 public NewUser mapRow(ResultSet resultSet, int line) throws SQLException {   
	  DataExtractor userExtractor = new DataExtractor();   
	  return userExtractor.extractCustomers(resultSet);   
	 }   

}
