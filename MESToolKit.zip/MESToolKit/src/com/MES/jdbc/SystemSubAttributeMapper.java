package com.MES.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

import com.MES.domain.System_SubAttributes;


public class SystemSubAttributeMapper  implements RowMapper<System_SubAttributes> {   

	 @Override  
	 public System_SubAttributes mapRow(ResultSet resultSet, int line) throws SQLException {   
	  DataExtractor userExtractor = new DataExtractor();   
	  return userExtractor.extractSystemSubAttributes(resultSet);   
	 }
}
