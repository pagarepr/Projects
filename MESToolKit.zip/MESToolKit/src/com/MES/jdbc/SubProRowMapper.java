package com.MES.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.MES.domain.SubProcess;

public class SubProRowMapper implements RowMapper<SubProcess> {   
	  
	 @Override  
	 public SubProcess mapRow(ResultSet resultSet, int line) throws SQLException {   
	  DataExtractor userExtractor = new DataExtractor();   
	  return userExtractor.extractSubProData(resultSet);   
	 }   

}
