package com.MES.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import com.MES.domain.RequirementFormDetails;

public class CheckRequirementsMapper implements RowMapper<RequirementFormDetails> {   
	  
	 @Override  
	 public RequirementFormDetails mapRow(ResultSet resultSet, int line) throws SQLException {   
	  DataExtractor userExtractor = new DataExtractor();   
	  return userExtractor.extractRequirementFormDetails(resultSet);   
	 }   
	  
	}  

