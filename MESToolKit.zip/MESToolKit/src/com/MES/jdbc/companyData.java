package com.MES.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;


import org.springframework.jdbc.core.RowMapper;


import com.MES.domain.CompanyDetails;

public class companyData implements RowMapper<CompanyDetails> {

	@Override  
	public CompanyDetails mapRow(ResultSet resultSet, int line) throws SQLException {   
		DataExtractor userExtractor = new DataExtractor();   
		return userExtractor.extractComapnyData(resultSet);  
	}

}
