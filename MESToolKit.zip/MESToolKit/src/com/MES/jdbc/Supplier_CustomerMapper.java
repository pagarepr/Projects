package com.MES.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;


import org.springframework.jdbc.core.RowMapper;

import com.MES.domain.Supplier_Customer;

public class Supplier_CustomerMapper implements RowMapper<Supplier_Customer> {   
	  
	 @Override  
	 public Supplier_Customer mapRow(ResultSet resultSet, int line) throws SQLException {   
	  DataExtractor userExtractor = new DataExtractor();   
	  return userExtractor.extractSupplierCustomer(resultSet);   
	 }   

}