package com.MES.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;


import org.springframework.jdbc.core.RowMapper;


public class count implements RowMapper<Integer> {

	@Override  
	public Integer mapRow(ResultSet resultSet, int line) throws SQLException {   
		DataExtractor userExtractor = new DataExtractor();   
		return userExtractor.extractCount(resultSet);  
	}

}

