package com.MES.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;



import org.springframework.jdbc.core.RowMapper;

import com.MES.domain.Criteria_titles;



public class CriteriaMapper implements  RowMapper<Criteria_titles>  {

	@Override  
	public Criteria_titles mapRow(ResultSet resultSet, int line) throws SQLException {   
		DataExtractor userExtractor = new DataExtractor();   
		return userExtractor.extractCriteria_titles(resultSet);  
	}   

}
