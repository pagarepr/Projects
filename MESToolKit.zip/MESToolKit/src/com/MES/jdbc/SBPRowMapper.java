package com.MES.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.MES.domain.StdBusinessProcess;
public class SBPRowMapper implements RowMapper<StdBusinessProcess> {   
	  
	 @Override  
	 public StdBusinessProcess mapRow(ResultSet resultSet, int line) throws SQLException {   
	  DataExtractor userExtractor = new DataExtractor();   
	  return userExtractor.extractStdBPData(resultSet);   
	 }   

}
