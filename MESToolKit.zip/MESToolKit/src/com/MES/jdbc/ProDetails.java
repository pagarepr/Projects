package com.MES.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.MES.domain.Process_Details;


public class ProDetails implements RowMapper<Process_Details>{
	 @Override  
	 public Process_Details mapRow(ResultSet resultSet, int line) throws SQLException {   
	  DataExtractor userExtractor = new DataExtractor();   
	  return userExtractor.extractProDetailsData(resultSet);   
	 }   


}
