package com.MES.jdbc;   




import java.sql.ResultSet;   
import java.sql.SQLException;   

import org.springframework.dao.DataAccessException;   

import com.MES.domain.Category;
import com.MES.domain.CompanyDetails;
import com.MES.domain.Criteria_Details;
import com.MES.domain.Criteria_titles;
import com.MES.domain.Login;
import com.MES.domain.NewUser;
import com.MES.domain.Process_Details;
import com.MES.domain.AssementmentForm;
import com.MES.domain.Ratings;
import com.MES.domain.RequirementFormDetails;
import com.MES.domain.RequirementsList;
import com.MES.domain.Role;
import com.MES.domain.SiteDetails;
import com.MES.domain.StdBusinessProcess;
import com.MES.domain.SubBusinessProcess;
import com.MES.domain.SubProcess;
import com.MES.domain.HomeDetails;
import com.MES.domain.SupplierRatingDetails;
import com.MES.domain.Supplier_Customer;
import com.MES.domain.Supplier_Info_Questions;
import com.MES.domain.System_Attribute;
import com.MES.domain.System_Details;
import com.MES.domain.System_SubAttributes;
import com.MES.domain.Systems;
import com.MES.domain.Technical_Info_Questions;

public class DataExtractor {   

	public HomeDetails extractData(ResultSet resultSet) throws SQLException,   
	DataAccessException {   

		HomeDetails user = new HomeDetails();   

		user.setModuleid(resultSet.getInt(1));   
		user.setModuleName(resultSet.getString(2));   
		user.setLink(resultSet.getString(3));   
		user.setDescription(resultSet.getString(4));   
		return user;   
	}  
	public RequirementFormDetails extractReqList1Extractor(ResultSet resultSet) throws SQLException {
		RequirementFormDetails list = new RequirementFormDetails();
		list.setReq_id(resultSet.getString(1));
		return list;
	}  
	public System_SubAttributes extractTechQues(ResultSet resultSet) throws SQLException {
		System_SubAttributes ques = new System_SubAttributes();
		ques.setSubAttribute_id(resultSet.getInt(1));
		ques.setSubAttribute_name(resultSet.getString(2));
		ques.setAttribute_subtype(resultSet.getInt(3));
		ques.setMainAttribute_id(resultSet.getInt(4));
		ques.setIs_active(resultSet.getInt(5));
		ques.setIs_active1(resultSet.getInt(6));
		return ques;
	}
	public Technical_Info_Questions extractTechInfoSaved(ResultSet resultSet) throws SQLException {
		Technical_Info_Questions saved_info = new Technical_Info_Questions();
		saved_info.setCat_id(resultSet.getInt(1));
		saved_info.setSub_cat_id(resultSet.getInt(2));
		saved_info.setQues_id(resultSet.getInt(3));
		saved_info.setSub_ques_id(resultSet.getInt(4));
		saved_info.setRatings(""+resultSet.getString(5));
		saved_info.setComments(resultSet.getString(6));
		saved_info.setCompany(resultSet.getString(6));
		saved_info.setSite(resultSet.getString(7));
		return saved_info;
	}
	public NewUser extractCustomers(ResultSet resultSet) throws SQLException {
		NewUser customers = new NewUser();
		customers.setCompany(resultSet.getString(2));
		customers.setCmpswd(resultSet.getString(3));
		return customers;
	}  
	public SubBusinessProcess extractSubBusinessData(ResultSet resultSet) throws SQLException,   
	DataAccessException {   

		SubBusinessProcess user = new SubBusinessProcess();   

		user.setSBP_ID(resultSet.getInt(1));   
		user.setPROCESS_ID(resultSet.getInt(2));   
		user.setSBP_NAME(resultSet.getString(3));  

		return user;   
	}
	public StdBusinessProcess extractStdBPData(ResultSet resultSet) throws SQLException,   
	DataAccessException {   

		StdBusinessProcess stdValues=new StdBusinessProcess();

		stdValues.setProcessId(resultSet.getInt(1));   
		stdValues.setProcessName(resultSet.getString(2));   


		return stdValues;   
	}  public Process_Details extractProDetailsData(ResultSet resultSet) throws SQLException,   
	DataAccessException {   

		Process_Details stdValues=new Process_Details();

		stdValues.setDetails_Id(resultSet.getInt(1));
		stdValues.setSP_Id(resultSet.getInt(2)); 
		stdValues.setDETAILS(resultSet.getString(3));
		stdValues.setIs_active(resultSet.getInt(4));
		stdValues.setCustomer_active(resultSet.getInt(5));
		stdValues.setCustomer_name(resultSet.getString(6));
		stdValues.setSite(resultSet.getString(7));		
		if(stdValues.getDETAILS().contains("|"))
		{	stdValues.setCheck(1);
			
		}
		else 
			stdValues.setCheck(0);;
		return stdValues;   
	}  
	public Role extractRoleData(ResultSet resultSet) throws SQLException,DataAccessException
	{
		Role role = new Role();
		role.setRoleid(resultSet.getInt(1));
		role.setRoleName(resultSet.getString(2));

		return role;
	} 
	public SubProcess extractSubProData(ResultSet resultSet) throws SQLException,   
	DataAccessException {   

		SubProcess stdValues=new SubProcess();

		stdValues.setSP_id(resultSet.getInt(1)); 
		stdValues.setSBP_id(resultSet.getInt(2));
		stdValues.setSP_Name(resultSet.getString(3));   


		return stdValues;   
	} 

	public NewUser extractUserData(ResultSet resultset) throws SQLException,DataAccessException
	{
		NewUser user = new NewUser();

		user.setUserid(resultset.getString(1));
		user.setUsername(resultset.getString(2));
		user.setCompany(resultset.getString(5));
		user.setRoleid(resultset.getInt(4));

		return user;
	}

	public HomeDetails extractSavedData(ResultSet resultSet) throws SQLException {
		HomeDetails data=new HomeDetails();
		data.setModuleName(resultSet.getString(1));
		data.setDescription(resultSet.getString(2));
		return data;
	}

	public AssementmentForm extractReqExtractor(ResultSet resultSet) throws SQLException ,DataAccessException{

		AssementmentForm reqDetails = new AssementmentForm();
		reqDetails.setReqID(resultSet.getString(1));
		reqDetails.setStdProcess(resultSet.getString(2));
		reqDetails.setSubProcess(resultSet.getString(3));
		reqDetails.setExistingSystemEntered(resultSet.getString(4));
		reqDetails.setSp_id(resultSet.getInt(5));
		return reqDetails;
	}

	public AssementmentForm extractReqListExtractor(ResultSet resultSet)  throws SQLException ,DataAccessException{
		AssementmentForm reqDetails = new AssementmentForm();
		reqDetails.setReqID(resultSet.getString(1));
		return reqDetails;
	}

	public AssementmentForm extractSubProcessListExtractor(ResultSet resultSet) throws SQLException {
		AssementmentForm reqDetails = new AssementmentForm();
		reqDetails.setSubProcess(resultSet.getString(3));
		reqDetails.setSp_id(resultSet.getInt(5));
		return reqDetails;
	}

	public Systems extractSystemName(ResultSet resultSet) throws SQLException {
		Systems system = new Systems();
		system.setSys_ID(resultSet.getInt(1));
		system.setSys_Name(resultSet.getString(2));
		system.setSys_Description(resultSet.getString(3));
		return system;
	}

	public System_Attribute extractSystemAttribute(ResultSet resultSet) throws SQLException {
		System_Attribute attributes=new System_Attribute();
		attributes.setAttribute_id(resultSet.getInt(1));
		attributes.setAttribute_name(resultSet.getString(2));
		attributes.setAttribute_subtype(resultSet.getInt(3));
		attributes.setIs_active(resultSet.getInt(4));
		return attributes;
	}

	public System_SubAttributes extractSystemSubAttributes(ResultSet resultSet) throws SQLException {
		System_SubAttributes attributes=new System_SubAttributes();
		attributes.setSubAttribute_id(resultSet.getInt(1));
		attributes.setSubAttribute_name(resultSet.getString(2));
		attributes.setAttribute_subtype(resultSet.getInt(3));
		attributes.setIs_active(resultSet.getInt(4));
		return attributes;
	}

	public System_Details extractSystemDetails(ResultSet resultSet) throws SQLException {
		System_Details attributes=new System_Details();
		attributes.setSys_ID(resultSet.getInt(1));
		attributes.setAttribute_id(resultSet.getInt(2));
		attributes.setDetails(resultSet.getString(3));
		attributes.setSubAttribute_id(resultSet.getInt(4));
		attributes.setDetails_id(resultSet.getInt(5));
		return attributes;
	}

	public Ratings extractRatingDetailsData(ResultSet resultSet) throws SQLException {
		Ratings attributes=new Ratings();
		attributes.setRating(resultSet.getInt(1));
		attributes.setDescription(resultSet.getString(2));
		return attributes;
	}

	public RequirementFormDetails extractRequirementFormDetails(
			ResultSet resultSet) throws SQLException {
		RequirementFormDetails reqDetails=new RequirementFormDetails();
		reqDetails.setReq_id(resultSet.getString(1));
		reqDetails.setSBP_name(resultSet.getString(2));
		reqDetails.setSP_name(resultSet.getString(3));
		reqDetails.setProcess_details(resultSet.getString(4));
		reqDetails.setRating(""+resultSet.getInt(5));
		reqDetails.setCommentsGiven(resultSet.getString(6));
		reqDetails.setDetails_id(resultSet.getInt(7));
		reqDetails.setStd_name(resultSet.getString(8));
		reqDetails.setSBP_id(resultSet.getInt(9));
		reqDetails.setSP_id(resultSet.getInt(10));
		return reqDetails;
	}

	public Login extractLoginData(ResultSet resultSet) throws SQLException {
		Login login=new Login();
		login.setRoleId(resultSet.getInt(4));
		login.setEncryptedPwd(resultSet.getString(3));
		login.setUsername(resultSet.getString(2));
		login.setCompany(resultSet.getString(5)); 
		login.setSite(resultSet.getString(6));
		login.setPwdQues(resultSet.getInt(7));
		login.setPwdAns(resultSet.getString(8));
		return login;
	}
	public Integer extractCount(ResultSet resultSet) throws SQLException {
		int count=resultSet.getInt(1);
		return count;
	}
	public CompanyDetails extractComapnyData(ResultSet resultSet) throws SQLException {
		CompanyDetails data=new CompanyDetails();
		data.setCompanyId(resultSet.getInt(1));
		data.setCompanyName(resultSet.getString(2));
		data.setType(resultSet.getString(3));
		return data;
	}
	public SiteDetails extractSiteData(ResultSet resultSet) throws SQLException {
		SiteDetails data=new SiteDetails();
		data.setSiteId(resultSet.getInt(1));
		data.setSiteName(resultSet.getString(2));
		data.setCompanyId(resultSet.getInt(3));
		return data;
	}  
	public Criteria_titles extractCriteria_titles(ResultSet resultSet) throws SQLException {
		Criteria_titles titles = new Criteria_titles();
		titles.setCriteria_id(resultSet.getInt(1));
		titles.setCriteria_Title(resultSet.getString(2));
		return titles;
	}
	public Criteria_Details extractCriteria_Details(ResultSet resultSet) throws SQLException {
		Criteria_Details details = new Criteria_Details();
		details.setCriteria_details_id(resultSet.getInt(1));
		details.setCriteria_id(resultSet.getInt(2));
		details.setRatings(resultSet.getInt(3));
		details.setRatings_name(resultSet.getString(4));
		return details;
	}
	public Supplier_Info_Questions extractSupplier_Ques(ResultSet resultSet) throws SQLException {
		Supplier_Info_Questions ques = new Supplier_Info_Questions();
		ques.setsInfo_id(resultSet.getInt(1));
		ques.setCat_id(resultSet.getInt(2));
		ques.setSd_id(resultSet.getInt(3));
		ques.setInfo_ques(resultSet.getString(4));
		ques.setIs_active(resultSet.getInt(5));
		return ques;
	}
	public Category extractCategory(ResultSet resultSet) throws SQLException {
		Category category = new Category();
		category.setCat_id(resultSet.getInt(1));
		category.setCat_name(resultSet.getString(2));
		category.setCriteria_id(resultSet.getInt(3));
		
		return category;
	}
	public Ratings extractRatings(ResultSet resultSet) throws SQLException {
		Ratings rating =new Ratings();
		rating.setRating(resultSet.getInt(1));
		rating.setDescription(resultSet.getString(2));
		return rating;
	}
	public Supplier_Info_Questions extractResponse(ResultSet resultSet) throws SQLException {
		Supplier_Info_Questions response = new Supplier_Info_Questions();
		response.setSd_id(resultSet.getInt(1));
		response.setCat_id(resultSet.getInt(2));
		response.setsInfo_id(resultSet.getInt(3));
		response.setRatings(""+resultSet.getString(4));
		response.setComments(resultSet.getString(5));
		response.setCompany(resultSet.getString(6));
		return response;
	}
	public SupplierRatingDetails extractSuplierRating(ResultSet resultSet) throws SQLException {
		SupplierRatingDetails rating=new SupplierRatingDetails();
		
		rating.setDetails_id(resultSet.getInt(1));
		rating.setReq_id(resultSet.getString(2));
		rating.setRating(resultSet.getInt(3));
		rating.setComments(resultSet.getString(4));
		rating.setSp_id(resultSet.getInt(5));
		return rating;
	}
	public Supplier_Customer extractSupplierCustomer(ResultSet resultSet) throws SQLException {
		Supplier_Customer customer=new Supplier_Customer();
		
		customer.setCustomer_company(resultSet.getString(1));
		return customer;
	}
	public Supplier_Customer extractSupplierSite(ResultSet resultSet) throws SQLException {
		Supplier_Customer customer=new Supplier_Customer();
		customer.setCustomer_company(resultSet.getString(1));
		customer.setSupplier_id(resultSet.getString(2));
		return customer;
	}
	public Category extractTechCategory(ResultSet resultSet) throws SQLException {
		Category category = new Category();
		category.setCat_id(resultSet.getInt(1));
		category.setCat_name(resultSet.getString(2));
		category.setCriteria_id(resultSet.getInt(3));
		category.setIs_active(resultSet.getInt(4));
		return category;
	}
	public Category extractSubCat(ResultSet resultSet) throws SQLException {
		Category subcat = new Category();
		subcat.setCriteria_id(resultSet.getInt(1));
		return subcat;
	}
	public RequirementsList extractRequirementsList(ResultSet resultSet) throws SQLException {
		RequirementsList list=new RequirementsList();
		list.setReq_id(resultSet.getString(1));
		list.setUserid(resultSet.getString(2));
		list.setCompany(resultSet.getString(3));
		list.setSite(resultSet.getString(4));
		return list;
	}  
	public String extractString(ResultSet resultSet) throws SQLException {
		String newString = new String();
		newString = resultSet.getString(1);
		return newString;
	} 
}  
