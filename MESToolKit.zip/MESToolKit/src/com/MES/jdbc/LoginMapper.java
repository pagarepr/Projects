package com.MES.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;


import org.springframework.jdbc.core.RowMapper;
import com.MES.domain.Login;

public class LoginMapper implements RowMapper<Login> {   
	  
	 @Override  
	 public Login mapRow(ResultSet resultSet, int line) throws SQLException {   
	  DataExtractor userExtractor = new DataExtractor();   
	  return userExtractor.extractLoginData(resultSet);   
	 }   
	  
	}  
