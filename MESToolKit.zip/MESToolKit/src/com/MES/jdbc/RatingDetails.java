package com.MES.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;


import org.springframework.jdbc.core.RowMapper;

import com.MES.domain.Ratings;

public class RatingDetails implements RowMapper<Ratings>{
	 @Override  
	 public Ratings mapRow(ResultSet resultSet, int line) throws SQLException {   
	  DataExtractor userExtractor = new DataExtractor();   
	  return userExtractor.extractRatingDetailsData(resultSet);   
	 }   


}

