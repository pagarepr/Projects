package com.MES.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;


import org.springframework.jdbc.core.RowMapper;
import com.MES.domain.System_Details;


public class SystemDetailsMapper implements RowMapper<System_Details> {   

	 @Override  
	 public System_Details mapRow(ResultSet resultSet, int line) throws SQLException {   
	  DataExtractor userExtractor = new DataExtractor();   
	  return userExtractor.extractSystemDetails(resultSet);   
	 }
}