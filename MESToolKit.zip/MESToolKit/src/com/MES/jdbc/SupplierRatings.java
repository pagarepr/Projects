package com.MES.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import com.MES.domain.SupplierRatingDetails;

public class SupplierRatings  implements RowMapper<SupplierRatingDetails> {   
	  
	 @Override  
	 public SupplierRatingDetails mapRow(ResultSet resultSet, int line) throws SQLException {   
	  DataExtractor userExtractor = new DataExtractor();   
	  return userExtractor.extractSuplierRating(resultSet);   
	 }   

}
