package com.MES.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import com.MES.domain.SubBusinessProcess;

public class SubBusinessDetails implements RowMapper<SubBusinessProcess>{
	 @Override  
	 public SubBusinessProcess mapRow(ResultSet resultSet, int line) throws SQLException {   
	  DataExtractor userExtractor = new DataExtractor();   
	  return userExtractor.extractSubBusinessData(resultSet);   
	 }   


}