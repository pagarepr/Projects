package com.MES.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import com.MES.domain.System_Attribute;

public class SystemAttributeMapper implements RowMapper<System_Attribute> {   

	 @Override  
	 public System_Attribute mapRow(ResultSet resultSet, int line) throws SQLException {   
	  DataExtractor userExtractor = new DataExtractor();   
	  return userExtractor.extractSystemAttribute(resultSet);   
	 }
}


