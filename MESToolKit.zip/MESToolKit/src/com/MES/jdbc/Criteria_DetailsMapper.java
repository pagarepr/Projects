package com.MES.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;


import org.springframework.jdbc.core.RowMapper;

import com.MES.domain.Criteria_Details;


public class Criteria_DetailsMapper implements RowMapper<Criteria_Details> {   
	  
	 @Override  
	 public Criteria_Details mapRow(ResultSet resultSet, int line) throws SQLException {   
	  DataExtractor userExtractor = new DataExtractor();   
	  return userExtractor.extractCriteria_Details(resultSet);   
	 }   

}
