package com.MES.dao;   

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.sql.DataSource;   

import org.springframework.beans.factory.annotation.Autowired;   
import org.springframework.jdbc.core.JdbcTemplate;   
import org.springframework.stereotype.Repository;

import com.MES.domain.AssementmentForm;
import com.MES.domain.Category;
import com.MES.domain.CompanyDetails;
import com.MES.domain.Criteria_Details;
import com.MES.domain.Criteria_titles;
import com.MES.domain.Login;
import com.MES.domain.NewUser;
import com.MES.domain.Process_Details;
import com.MES.domain.Ratings;
import com.MES.domain.RequirementFormDetails;
import com.MES.domain.RequirementsList;
import com.MES.domain.Role;
import com.MES.domain.SiteDetails;
import com.MES.domain.StdBusinessProcess;
import com.MES.domain.SubBusinessProcess;
import com.MES.domain.SubProcess;
import com.MES.domain.HomeDetails;
import com.MES.domain.SupplierRatingDetails;
import com.MES.domain.Supplier_Customer;
import com.MES.domain.Supplier_Info_Questions;
import com.MES.domain.System_Attribute;
import com.MES.domain.System_Details;
import com.MES.domain.System_SubAttributes;
import com.MES.domain.Systems;
import com.MES.domain.Technical_Info_Questions;
import com.MES.jdbc.CategoryMapper;
import com.MES.jdbc.CategoryRatings;
import com.MES.jdbc.CheckRequirementsMapper;
import com.MES.jdbc.CheckSubProcessMapper;
import com.MES.jdbc.CriteriaMapper;
import com.MES.jdbc.Criteria_DetailsMapper;
import com.MES.jdbc.CustomerMapper;
import com.MES.jdbc.LoginMapper;
import com.MES.jdbc.NewUserRowMapper;
import com.MES.jdbc.ProDetails;
import com.MES.jdbc.RequirementListMapper;
import com.MES.jdbc.RequirementsList1Mapper;
import com.MES.jdbc.RequirementsListMapper;
import com.MES.jdbc.RequirementsMapper;
import com.MES.jdbc.RoleMapper;
import com.MES.jdbc.SBPRowMapper;
import com.MES.jdbc.SavedTableExtractor;
import com.MES.jdbc.StringMapper;
import com.MES.jdbc.SubBusinessDetails;
import com.MES.jdbc.SubCatMapper;
import com.MES.jdbc.SubProRowMapper;
import com.MES.jdbc.HomeRowMapper;
import com.MES.jdbc.SupplierQuesMapper;
import com.MES.jdbc.SupplierRatings;
import com.MES.jdbc.SupplierResponseMapper;
import com.MES.jdbc.Supplier_CustomerMapper;
import com.MES.jdbc.SystemAttributeMapper;
import com.MES.jdbc.SystemDetailsMapper;
import com.MES.jdbc.SystemNameMapper;
import com.MES.jdbc.SystemSubAttributeMapper;
import com.MES.jdbc.TechCategoryMapper;
import com.MES.jdbc.TechQuestionsMapper;
import com.MES.jdbc.TechnicalResponseMapper;
import com.MES.jdbc.companyData;
import com.MES.jdbc.count;
import com.MES.jdbc.siteData;
  

@Repository("userDao")
public class TablesDaoImpl implements TablesDao {   
	private int noOfRecords;
	private int noOfRecordsMia;
 @Autowired  
 DataSource dataSource;   
  public String checkForQuotes(String processName)
  {
	  String modifedName="";
	  ArrayList<Integer> indexes=new ArrayList<Integer>();
	  for (int index = processName.indexOf('\'');index >= 0;index = processName.indexOf('\'', index + 1))
				{
				    indexes.add(index);
				}
	  for(int i=0;i<indexes.size();i++)
	 {
		  if(indexes.size()==1)
		  		modifedName=processName.substring(0,indexes.get(i))+"'||chr(39)||'"+processName.substring(indexes.get(i)+1);
		  else{ 
			  if(i==0)
			  {
				  modifedName=processName.substring(0,indexes.get(i))+"'||chr(39)||'";
			  }
			  else if(i==indexes.size()-1)
			  {
				  modifedName+=processName.substring(indexes.get(i-1)+1,indexes.get(i))+"'||chr(39)||'"+processName.substring(indexes.get(i)+1);
			  }
			  else
			  {
				  modifedName+=processName.substring(indexes.get(i-1)+1,indexes.get(i))+"'||chr(39)||'";
			  }
		  } 		
	 }	 
	  if(indexes.size()==0)
		  return processName;
	return modifedName; 
	  
  }
 public void insertData(HomeDetails user,int role,String company,String site) {   
	
   if(user.getModuleName()!="")
  {
	  String sql="select max(DETAILS_ID) as DETAILS_ID from PROCESS_DETAILS_MD";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);  
		int attID = jdbcTemplate.queryForInt(sql);
		attID+=1;
		if(role==1)
		sql = "INSERT INTO PROCESS_DETAILS_MD VALUES ("+attID+","+user.getModuleid()+",'"+checkForQuotes(user.getModuleName())+"',1,0,'"+company+"','"+site+"')";   
		else if (role==5)
		{
		sql = "INSERT INTO PROCESS_DETAILS_MD VALUES ("+attID+","+user.getModuleid()+",'"+checkForQuotes(user.getModuleName())+"',0,1,'"+company+"','"+site+"')";   
		}
		jdbcTemplate = new JdbcTemplate(dataSource);   
  
  jdbcTemplate.update(sql);   
  }
 } 
 @Override
	public void changeSystemDetails(System_Details changeDetails) {
	 if(changeDetails.getDetails().equals(""))
	 {
		 String SQL = "delete System_Details  where details_ID="+changeDetails.getDetails_id();
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource); 
			jdbcTemplate.execute(SQL); 
	 }
	 else{
	 String SQL = "Update System_Details set details='"+checkForQuotes(changeDetails.getDetails())+"' where details_ID="+changeDetails.getDetails_id();
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource); 
		jdbcTemplate.execute(SQL);}
	}
	@Override
	public void deleteSystemDetails1(int parseInt) {

		String SQL = "delete from SYSTEM_DETAILS where details_ID="+parseInt;
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource); 
		jdbcTemplate.execute(SQL);
	}   
 public List<SubBusinessProcess>  getSubBusinessProcess(int array[]){   
	  List<SubBusinessProcess> userList = new ArrayList<SubBusinessProcess>(); 
	  String row="";
	  for(int i=0;i<array.length;i++){
		  if(i==array.length-1)
			  row+=array[i];
		  else
			  row+=array[i]+" OR PROCESS_ID=";
	  }
	  String sql = "select * from SUB_BUSINESS_PROCESS_MD where PROCESS_ID="+row;   
	  JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);   
	  userList = jdbcTemplate.query(sql, new SubBusinessDetails()); 
	  return userList;   
	 }

 public List<Process_Details> getProcessDetails(){   
	  List<Process_Details> userList = new ArrayList<Process_Details>();   
	  String sql = "select * from PROCESS_DETAILS_MD ";   
	  
	  JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);   
	  userList = jdbcTemplate.query(sql, new ProDetails()); 
	  return userList;   
	 }
 public List<SubProcess> getSubProcessList(int a) {   
	  List<SubProcess> userList = new ArrayList<SubProcess>();   
	  String sql = "select * from SUB_PROCESS_MD where SBP_ID="+a;   
	  
	  JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);   
	  userList = jdbcTemplate.query(sql, new SubProRowMapper()); 
	  return userList;   
	 }
 public List<StdBusinessProcess> getSBPList() {   
	  List<StdBusinessProcess> userList = new ArrayList<StdBusinessProcess>();   
	  
	  String sql = "select * from STD_BUSINESS_PROCESS_MD";   
	  
	  JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);   
	  userList = jdbcTemplate.query(sql, new SBPRowMapper());   
	  return userList;   
	 }
 public List<HomeDetails> getUserList() {   
  List<HomeDetails> userList = new ArrayList<HomeDetails>();   
  String sql = "select * from home_md";   
  JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);  
  userList = jdbcTemplate.query(sql, new HomeRowMapper());   
  return userList;   
 }   
  
 @Override  
 public void deleteData(String id,String active,int role,String company,String site) { 
	 int idValue=Integer.parseInt(id);
	 String sql=null;
	 if(role==1)
	 {
	 	if(Integer.parseInt(active)==1)
	 	{
	 		sql = "update PROCESS_DETAILS_MD set IS_ACTIVE=0,CUSTOMER_ACTIVATE=0,customer_name='"+company+"',site='"+site+"' where DETAILS_ID=" + idValue;   
		}
	 	else
	 	{
			sql = "update PROCESS_DETAILS_MD set IS_ACTIVE=1,CUSTOMER_ACTIVATE=0,customer_name='"+company+"',site='"+site+"' where DETAILS_ID=" + idValue;   
	 	}
	 }
	 else if(role==5)
	 {
		 if(Integer.parseInt(active)==1)
	 	{
	 		sql = "update PROCESS_DETAILS_MD set CUSTOMER_ACTIVATE=2 where DETAILS_ID=" + idValue;   
		}
	 	else
	 	{
			sql = "update PROCESS_DETAILS_MD set CUSTOMER_ACTIVATE=1 where DETAILS_ID=" + idValue;   
	 	}
	 }
	 JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);   
	  jdbcTemplate.update(sql); 
 }   
  
 @Override  
 public void updateData(HomeDetails processDetails) {   
  if(processDetails.getModuleName()!="")
  {
	
  String sql = "UPDATE PROCESS_DETAILS_MD set PROCESS_DETAILS = '"+ checkForQuotes(processDetails.getModuleName())+"' where DETAILS_ID ="+processDetails.getModuleid();   
  JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);   
  jdbcTemplate.update(sql);
  }
 }   
  
 @Override  
 public HomeDetails getUser(String id) {   
  List<HomeDetails> userList = new ArrayList<HomeDetails>();   
  String sql = "select * from home_md where user_id= " + id;   
  JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);   
  userList = jdbcTemplate.query(sql, new HomeRowMapper());   
  return userList.get(0);   
 }
 
@Override
public List<NewUser> getUserIDList() {
	List<NewUser> userList = new ArrayList<NewUser>();   
	  
	  String sql = "select * from Role_Transaction where role_id!=1";   
	  JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);  
	  userList = jdbcTemplate.query(sql, new NewUserRowMapper());   
	  return userList;   
	
}
@Override
public NewUser getUserOfID(String userid) {
	NewUser newuser;
	String sql = "select * from Role_Transaction where User_ID = '"+userid+"'";   
	 JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);  
	  newuser = jdbcTemplate.queryForObject(sql, new NewUserRowMapper());   
	  return newuser;
}
@Override
public boolean setRole(String rolename,String userid) {

	String sql = "UPDATE Role_Transaction set Role_ID=(select Role_Id from Role_md where role_name='"+rolename+"') where USER_ID='"+userid+"'";
	 JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);   
	 try
	 {
	  jdbcTemplate.update(sql);
	  return true;
	 }
	 catch(Exception e)
	 {
		 return false;
	 }
	}
	 @Override
	 public List<Role> getRoleList() {

	 	List<Role> roleList = new ArrayList<Role>();   

	 	  String sql = "select * from Role_MD";   
	 	  JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);  
	 	 roleList = jdbcTemplate.query(sql, new RoleMapper());   
	 	  return roleList;   

	 }
	@Override
	public List<StdBusinessProcess> getStandardProcessList(int[] array) {
		 List<StdBusinessProcess> userList = new ArrayList<StdBusinessProcess>(); 
		  String row="";
		  for(int i=0;i<array.length;i++){
			  if(i==array.length-1)
				  row+=array[i];
			  else
				  row+=array[i]+" OR PROCESS_ID=";
		  }
		  String sql = "select * from STD_BUSINESS_PROCESS_MD where PROCESS_ID="+row;   
		  JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);   
		  userList = jdbcTemplate.query(sql, new SBPRowMapper()); 
		  return userList;  
		
	}
	@Override
	public void insertRequirements(List<AssementmentForm> formValues) {
		List<AssementmentForm> checkList=new ArrayList<AssementmentForm>();
		if(formValues.isEmpty())
		{
			return;
		}
		String SQ = "Select REQ_ID,STD_PROCESS,SUB_PROCESS,EXISTING_SYSTEMS,SBP_ID from MIA_FORM where REQ_ID='"+formValues.get(0).getReqID()+"'";
		 JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);   
		 checkList = jdbcTemplate.query(SQ, new CheckSubProcessMapper()); 
		 int processPresent=0;
		for (AssementmentForm requirement:formValues)
		{
			for(AssementmentForm checkSubProcess:checkList)
			{
				if(checkSubProcess.getSubProcess().equals(requirement.getSubProcess()))
				{
					if(checkSubProcess.getSp_id()==requirement.getSp_id())
					{processPresent=1;
					break;
				}}
			}
			if(processPresent==1)
			{
				String SQL="UPDATE MIA_FORM SET EXISTING_SYSTEMS='"+requirement.getExistingSystemEntered()+"' where Req_id='"+requirement.getReqID()+"' and SUB_PROCESS='"+requirement.getSubProcess()+"' and SBP_ID="+requirement.getSp_id(); 
				jdbcTemplate = new JdbcTemplate(dataSource); 
				jdbcTemplate.update(SQL);
			}
			else{
				if(!(requirement.getSubProcess().equals(""))){
			String SQL="INSERT INTO MIA_FORM (REQ_ID,STD_PROCESS,SUB_PROCESS,EXISTING_SYSTEMS,SBP_ID) VALUES ('"+requirement.getReqID()+"','"+requirement.getStdProcess()+"','"+requirement.getSubProcess()+"','"+requirement.getExistingSystemEntered()+"',"+requirement.getSp_id()+")";
			jdbcTemplate = new JdbcTemplate(dataSource); 
			jdbcTemplate.update(SQL);}
			}
			processPresent=0;
		}    
	}
	@Override
	public void saveInTemporary(String string, int[] array, String userid) {
		String arrayCreation="";
		for(int x=0;x<array.length;x++)
		{
			if(x==array.length-1)
				arrayCreation+=array[x];
			else
				arrayCreation+=array[x]+",";
		}
		String SQL="INSERT INTO TEMP_MIA_TABLE VALUES ('"+string+"','"+arrayCreation+"','"+userid+"')";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource); 
		jdbcTemplate.update(SQL);
	}
	@Override
	public void deleteFromTemporary(String userid) {
		String SQL="delete from TEMP_MIA_TABLE where USER_ID='"+userid+"'";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource); 
		jdbcTemplate.update(SQL);
		
	}
	@Override
	public List<HomeDetails> getSavedProcess(String userid) {
		List<HomeDetails> processes=new ArrayList<HomeDetails>();
		String sql = "select TEMP_REQ_ID,STANDARD_PROCESS from TEMP_MIA_TABLE where USER_ID='"+userid+"'";   
		  JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);   
		 processes = jdbcTemplate.query(sql, new SavedTableExtractor()); 
		  return processes; 
	}
	@Override
	public String validateID(String customerReqId) {
		String SQL = "Select REQ_ID,STD_PROCESS,SUB_PROCESS,EXISTING_SYSTEMS,SBP_ID from MIA_FORM where Req_id='"+customerReqId+"'";
		String newCustId=null;
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		List<AssementmentForm> emptyForm = new ArrayList<>();
		emptyForm = jdbcTemplate.query(SQL, new RequirementsMapper());
		if(!emptyForm.isEmpty())
		{
			long seq= Long.parseLong(customerReqId.substring(3))+1;
			newCustId = customerReqId.substring(0,3)+ Long.toString(seq);
			newCustId=validateID(newCustId);
		}
		else
		{
			newCustId= customerReqId;
		}
		
		return newCustId;
	}
	@Override
	public String validateIDReq(String customerReqId) {
		String SQL = "Select * from REQUIREMENT_FORM where Req_id='"+customerReqId+"'";
		String newCustId=null;
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		List<RequirementFormDetails> emptyForm = new ArrayList<>();
		emptyForm = jdbcTemplate.query(SQL, new CheckRequirementsMapper());
		if(!emptyForm.isEmpty())
		{
			long seq= Long.parseLong(customerReqId.substring(3))+1;
			newCustId = customerReqId.substring(0,3)+ Long.toString(seq);
			newCustId=validateID(newCustId);
		}
		else
		{
			newCustId= customerReqId;
		}

		return newCustId;
	}

	@Override
	public int checkForSubmittedAndSaved(String userId) {
		int count=0;
		int flag=0;
		String SQL= "Select req_id from LIST_OF_ASSESSMENT where user_id='"+userId+"'";
		String SQL1 = "select temp_req_id from Temp_MIA_Table where user_id='"+userId+"'";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		List<Supplier_Customer> getID = new ArrayList<>();
		List<Supplier_Customer> getID1 = new ArrayList<>();
		getID = jdbcTemplate.query(SQL1, new Supplier_CustomerMapper());
		if(!getID.isEmpty())
		{
			count=1;
			++flag;
		}
		getID1 = jdbcTemplate.query(SQL, new Supplier_CustomerMapper());
		if(!getID1.isEmpty())
		{
			++flag;
			count=2;
		}
		if(flag==2)
			count=3;
		
		return count;
		}
	@Override
	public int checkForSubmittedAndSavedRequirement(String userId) {
		int count=0;
		int flag=0;
		List<Supplier_Customer> report =new ArrayList<Supplier_Customer>();
		List<Supplier_Customer> report1 =new ArrayList<Supplier_Customer>();
		String SQL= "Select req_id from LIST_OF_REQUIREMENT where user_id='"+userId+"'";
		String SQL1 = "select temp_req_id from Temp_REQUIREMENT_Table where user_id='"+userId+"'";
		
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);  
		
		report = jdbcTemplate.query(SQL1, new Supplier_CustomerMapper());
			if(!report.isEmpty())
			{	
				count=1;
				++flag;
				return count;
			}
			jdbcTemplate = new JdbcTemplate(dataSource);  
			report1 = jdbcTemplate.query(SQL, new Supplier_CustomerMapper());

			if(!report1.isEmpty())
			{	++flag;
				count=2;	
				return count;
			}
			if(flag==2)
			{
				count=3;
				return count;
			}
		return 0;
		}
	@Override
	public List<AssementmentForm> generateReport(String reqID) {
		List<AssementmentForm> report = new ArrayList<AssementmentForm>();
		String SQL = "Select REQ_ID,STD_PROCESS,SUB_PROCESS,EXISTING_SYSTEMS,SBP_ID from MIA_FORM where req_id='"+reqID+"'";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);  
		report = jdbcTemplate.query(SQL, new RequirementsMapper());   
		return report ;
	}
	@Override
	public List<AssementmentForm> getReqId(String userId)
	{

		List<AssementmentForm> reqIDList = new ArrayList<AssementmentForm>();    
		String SQL = "Select Req_id from LIST_OF_ASSESSMENT where user_id='"+userId+"'"; 
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);  
		reqIDList = jdbcTemplate.query(SQL, new RequirementsListMapper());   
		return reqIDList;  		
	}
	@Override
	public void generateReqID(String attribute, String userid,String company,String site) {
		String SQL = "Insert into LIST_OF_ASSESSMENT values('"+attribute+"','"+userid+"','"+company+"','"+site+"')";
		String sql = "Update MIA_FORM set Submitted_systems=EXISTING_SYSTEMS where req_id='"+attribute+"'";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource); 
		jdbcTemplate.execute(SQL);
		jdbcTemplate.execute(sql);

	}
	@Override
	public void editReport(AssementmentForm form) {
		String SQL = "Update MIA_FORM set EXISTING_SYSTEMS='"+form.getExistingSystemEntered()+"' where REQ_ID='"+form.getReqID()+"' AND SUB_PROCESS='"+form.getSubProcess()+"'";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource); 
		jdbcTemplate.execute(SQL);
		
	}
	@Override
	public void deleteReportDetails(String id, String subP) {
		String SQL = "delete from MIA_FORM where REQ_ID='"+id+"' AND SUB_PROCESS='"+subP+"'";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource); 
		jdbcTemplate.execute(SQL);
		
	}
	@Override
	public List<Systems> getSystems(String company,String site) {

		List<Systems> systems = new ArrayList<Systems>();
		String SQL = "Select * from System_name where company='"+company+"' and site='"+site+"'";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);  
		systems = jdbcTemplate.query(SQL, new SystemNameMapper());   
		return systems;
	}

	public int checkSystemID(int id)
	{
		String SQL = "select * from System_Name where System_id="+id;
		List<Systems> systems = new ArrayList<Systems>();
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);  
		int newID=0;
		systems = jdbcTemplate.query(SQL, new SystemNameMapper());  
		if(!systems.isEmpty())
		{
			int ID = id+1;
			newID=checkSystemID(ID);
		}
		else
		{
			newID= id;
		}
		return newID;
	}

	@Override
	public void addNewSystem(Systems newSystem) {
		int id=1;
		String date = new java.util.Date().toString();
		if(newSystem.getSys_Name()!=""){
		String SQL = "Insert into System_name values("+checkSystemID(id)+",'"+checkForQuotes(newSystem.getSys_Name())+"','"+checkForQuotes(newSystem.getSys_Description())+"','"+newSystem.getCompany()+"','"+newSystem.getInserted_By()+"','"+date+"','"+newSystem.getSite()+"')";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource); 
		jdbcTemplate.execute(SQL);}
	}
	@Override
	public List<System_Attribute> getSystemAttributes() {
		List<System_Attribute> systems = new ArrayList<System_Attribute>();
		String SQL = "select * from SYSTEM_ATTRIBUTES";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);  
		systems = jdbcTemplate.query(SQL, new SystemAttributeMapper());   
		return systems;
	}
	@Override
	public List<System_SubAttributes> getSystemSubAttributes() {
		List<System_SubAttributes> systems = new ArrayList<System_SubAttributes>();
		String SQL = "select * from SYSTEM_SUBATTRIBUTES";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);  
		systems = jdbcTemplate.query(SQL, new SystemSubAttributeMapper());   
		return systems;
	}
	@Override
	public List<System_Details> getSystemEnteredDetails(int id) {
		List<System_Details> systems = new ArrayList<System_Details>();
		String SQL = "select * from SYSTEM_DETAILS where SYSTEM_ID="+id;
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);  
		systems = jdbcTemplate.query(SQL, new SystemDetailsMapper());   
		return systems;
	}
	@Override
	public void insertSystemDetails(System_Details inserted_details) {
		List<System_Details> systems = new ArrayList<System_Details>();
		String SQL = "select * from SYSTEM_DETAILS ";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);  
		systems = jdbcTemplate.query(SQL, new SystemDetailsMapper());   
		Collections.sort(systems, new Comparator<System_Details>() {
	        @Override public int compare(System_Details p1, System_Details p2) {
	            return p1.getDetails_id() - p2.getDetails_id(); // Ascending
	        }});
		String sql=null;
		if(systems.size()==0){
	   		  sql = "INSERT INTO SYSTEM_DETAILS VALUES("+inserted_details.getSys_ID()+","+inserted_details.getAttribute_id()+",'"+checkForQuotes(inserted_details.getDetails())+"',"+inserted_details.getSubAttribute_id()+",1)";   

	        }
		else{
		 sql = "INSERT INTO SYSTEM_DETAILS VALUES("+inserted_details.getSys_ID()+","+inserted_details.getAttribute_id()+",'"+checkForQuotes(inserted_details.getDetails())+"',"+inserted_details.getSubAttribute_id()+","+((systems.get(systems.size() - 1).getDetails_id())+1)+")";   
		}jdbcTemplate = new JdbcTemplate(dataSource);   
		 jdbcTemplate.update(sql);  
		
	}
	@Override
	public void deleteSystem(int parseInt) {
		String SQL = "delete from System_name where SYSTEM_ID="+parseInt;
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource); 
		jdbcTemplate.execute(SQL);
		
		
	}
	@Override
	public void deleteSystemDetails(int parseInt) {
		String SQL = "delete from SYSTEM_DETAILS where SYSTEM_ID="+parseInt;
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource); 
		jdbcTemplate.execute(SQL);
		
		
	}
	@Override
	public void updateSystemDetails(Systems updated_details) {
		String SQL = "Update System_name set SYSTEM_NAME='"+checkForQuotes(updated_details.getSys_Name())+"',SYSTEM_DESCRIPTION='"+checkForQuotes(updated_details.getSys_Description())+"' where SYSTEM_ID="+updated_details.getSys_ID();
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource); 
		jdbcTemplate.execute(SQL);
		
	}
	@Override
	public void deleteFromTemporaryReq(String userid) {
		String SQL="delete from TEMP_REQUIREMENT_TABLE where USER_ID='"+userid+"'";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource); 
		jdbcTemplate.update(SQL);
		
	}
	@Override
	public void saveInTemporaryReq(String attribute,
			int[] selectedModulesRequirement, String userid) {
		String arrayCreation="";
		for(int x=0;x<selectedModulesRequirement.length;x++)
		{
			if(x==selectedModulesRequirement.length-1)
				arrayCreation+=selectedModulesRequirement[x];
			else
				arrayCreation+=selectedModulesRequirement[x]+",";
		}
		String SQL="INSERT INTO TEMP_REQUIREMENT_TABLE VALUES ('"+attribute+"','"+arrayCreation+"','"+userid+"')";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource); 
		jdbcTemplate.update(SQL);
		
	}
	@Override
	public List<Process_Details> getProcessDetailsById(int sp_id) {
		 List<Process_Details> userList = new ArrayList<Process_Details>();   
		  String sql = "select * from PROCESS_DETAILS_MD where SP_ID="+sp_id+" and IS_ACTIVE=1" ;   
		  
		  JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);   
		  userList = jdbcTemplate.query(sql, new ProDetails()); 
		  return userList; 
	}
	@Override
	public void insertRequirementsGathering(
			List<RequirementFormDetails> formValues) {
		if(formValues.get(0).getRating().equals("0"))
		{
			String SQL = "delete from REQUIREMENT_FORM where REQ_ID='"+formValues.get(0).getReq_id()+"' and SP_ID="+formValues.get(0).getSP_id();
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource); 
			jdbcTemplate.execute(SQL);
		}
		else
		{
			String SQL = "delete from REQUIREMENT_FORM where REQ_ID='"+formValues.get(0).getReq_id()+"' and SP_ID="+formValues.get(0).getSP_id();
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource); 
			jdbcTemplate.execute(SQL);
			for (RequirementFormDetails required:formValues)
			{
				
				SQL="INSERT INTO REQUIREMENT_FORM (REQ_ID,STD_PROCESS,SUB_PROCESS,PROCESS_NAME,RATINGS,REMARKS,DETAILS_ID,STD_BUSINESS_PROCESS,SBP_ID,SP_ID) VALUES ('"+required.getReq_id()+"','"+required.getSBP_name()+"','"+required.getSP_name()+"','"+checkForQuotes(required.getProcess_details())+"',"+required.getRating().charAt(0)+",'"+checkForQuotes(required.getCommentsGiven())+"',"+required.getDetails_id()+",'"+required.getStd_name()+"',"+required.getSBP_id()+","+required.getSP_id()+")";
				jdbcTemplate = new JdbcTemplate(dataSource); 
				jdbcTemplate.update(SQL);
			}
		}
		
		
	}
	@Override
	public List<RequirementFormDetails> getSavedDetails(String subProcessName,
			String attribute) {
		List<RequirementFormDetails> checkList=new ArrayList<RequirementFormDetails>();
		String SQ = "Select REQ_ID,STD_PROCESS,SUB_PROCESS,PROCESS_NAME,RATINGS,REMARKS,DETAILS_ID,STD_BUSINESS_PROCESS,SBP_ID,SP_ID from REQUIREMENT_FORM where REQ_ID='"+attribute+"' and SUB_PROCESS='"+subProcessName+"'";
		 JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);   
		 checkList = jdbcTemplate.query(SQ, new CheckRequirementsMapper()); 
		return checkList;
	}
	@Override
	public List<HomeDetails> getSavedProcessReq(String userid) {
		List<HomeDetails> processes=new ArrayList<HomeDetails>();
		String sql = "select TEMP_REQ_ID,STANDARD_PROCESS from TEMP_REQUIREMENT_TABLE where USER_ID='"+userid+"'";   
		  JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);   
		 processes = jdbcTemplate.query(sql, new SavedTableExtractor()); 
		  return processes; 
		
	}
	@Override
	public List<RequirementFormDetails> getNumberOfEntries(
			String sbp_NAME, String attribute) {
		List<RequirementFormDetails> checkList=new ArrayList<RequirementFormDetails>();
		String SQ = "Select REQ_ID,STD_PROCESS,SUB_PROCESS,PROCESS_NAME,RATINGS,REMARKS,DETAILS_ID,STD_BUSINESS_PROCESS,SBP_ID,SP_ID from REQUIREMENT_FORM where REQ_ID='"+attribute+"' and STD_PROCESS='"+sbp_NAME+"'";
		 JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);   
		 checkList = jdbcTemplate.query(SQ, new CheckRequirementsMapper()); 
		return checkList;
	}
	@Override
	public List<RequirementFormDetails> createReport(String reqID) {
		List<RequirementFormDetails> report = new ArrayList<RequirementFormDetails>();
		String SQL = "Select REQ_ID,STD_PROCESS,SUB_PROCESS,PROCESS_NAME,SUBMITTED_RATING,SUBMITTED_COMMENTS,DETAILS_ID,STD_BUSINESS_PROCESS,SBP_ID,SP_ID from Requirement_FORM where req_id='"+reqID+"'";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);  
		report = jdbcTemplate.query(SQL, new CheckRequirementsMapper());   
		return report ;

	}
	@Override
	public void createReqID(String attribute, Login userid) {
		String SQL = "Insert into LIST_OF_Requirement values('"+attribute+"','"+userid.getUserid()+"','"+userid.getCompany()+"','"+userid.getSite()+"')";
		String sql = "Update REQUIREMENT_FORM set Submitted_rating=ratings,submitted_comments=remarks where req_id='"+attribute+"'";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource); 
		jdbcTemplate.execute(SQL);
		jdbcTemplate.execute(sql);

	}
	@Override
	public List<RequirementFormDetails> getNumberOfEntriesList(String name,
			String sp_Name, String id) {
		List<RequirementFormDetails> checkList=new ArrayList<RequirementFormDetails>();
		String SQ = "Select REQ_ID,STD_PROCESS,SUB_PROCESS,PROCESS_NAME,RATINGS,REMARKS,DETAILS_ID,STD_BUSINESS_PROCESS,SBP_ID,SP_ID from REQUIREMENT_FORM where REQ_ID='"+id+"' and STD_PROCESS='"+name+"' and SUB_PROCESS='"+sp_Name+"'";
		 JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);   
		 checkList = jdbcTemplate.query(SQ, new CheckRequirementsMapper()); 
		return checkList;
	}
	@Override
	public List<RequirementFormDetails> getReqIds(String userId) {
		List<RequirementFormDetails> reqIDList = new ArrayList<RequirementFormDetails>();    
		String SQL = "Select Req_id from LIST_OF_REQUIREMENT where user_id='"+userId+"'"; 
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);  
		reqIDList = jdbcTemplate.query(SQL, new RequirementsList1Mapper());   
		return reqIDList;  	

	}
	@Override
	public List<Process_Details> getProcessDetailsTotal(int sbp_ID) {
		 List<Process_Details> userList = new ArrayList<Process_Details>();   
		  String sql = "select * from PROCESS_DETAILS_MD where SP_ID in (select sp_id from SUB_PROCESS_MD where SUB_PROCESS_MD.SBP_ID="+sbp_ID+") and IS_ACTIVE=1";  
		  JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);   
		  userList = jdbcTemplate.query(sql, new ProDetails()); 
		  return userList; 
	}
	@Override
	public void clearConnections() {
		
		String SQL = "alter system set processes=300 scope=spfile";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource); 
		jdbcTemplate.execute(SQL);
		 SQL = "alter system set sessions=300 scope=spfile";
		jdbcTemplate.execute(SQL);
		
	} 
	@Override
	public void addNewAtt(System_Attribute newAtt) {
		String sql="select max(ATTRIBUTE_ID) as ATTRIBUTE_ID from SYSTEM_ATTRIBUTES";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);  
		int attID = jdbcTemplate.queryForInt(sql);
		attID+=1;
		String SQL = "Insert into SYSTEM_ATTRIBUTES values("+attID+",'"+checkForQuotes(newAtt.getAttribute_name())+"',"+0+",1)";
		jdbcTemplate.execute(SQL);
	}
	@Override
	public void addNewSubAtt(System_SubAttributes newSubAtt) 
	{
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		String sql1= "Select ATTRIBUTE_SUBTYPE from SYSTEM_ATTRIBUTES where ATTRIBUTE_ID="+newSubAtt.getMainAttribute_id();
		int subtype = jdbcTemplate.queryForInt(sql1);
		String sql="select max(SUBATTRIBUTE_ID) as SUBATTRIBUTE_ID from SYSTEM_SUBATTRIBUTES";  
		int subAttID = jdbcTemplate.queryForInt(sql);
		subAttID+=1;
		if(subtype==0)
		{
			String sql2="select max(ATTRIBUTE_SUBTYPE) as ATTRIBUTE_SUBTYPE from SYSTEM_ATTRIBUTES";	
			int maxSubtype = jdbcTemplate.queryForInt(sql2);
			subtype=maxSubtype+1;
			String sql3="update SYSTEM_ATTRIBUTES set ATTRIBUTE_SUBTYPE="+subtype+"where ATTRIBUTE_ID="+newSubAtt.getMainAttribute_id();
			jdbcTemplate.execute(sql3);
			String SQL = "Insert into SYSTEM_SUBATTRIBUTES values("+subAttID+",'"+checkForQuotes(newSubAtt.getSubAttribute_name())+"',"+subtype+",1)";
			jdbcTemplate.execute(SQL);
		}
		else
		{
			String SQL1 = "Insert into SYSTEM_SUBATTRIBUTES values("+subAttID+",'"+checkForQuotes(newSubAtt.getSubAttribute_name())+"',"+newSubAtt.getAttribute_subtype()+",1)";
			jdbcTemplate.execute(SQL1);
		}

	}
	@Override
	public void updateAtt(System_Attribute updateAtt) {
		String SQL = "Update SYSTEM_ATTRIBUTES set ATTRIBUTE_NAME='"+checkForQuotes(updateAtt.getAttribute_name())+"' where ATTRIBUTE_ID="+updateAtt.getAttribute_id();
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource); 
		jdbcTemplate.execute(SQL);
	}
	@Override
	public void updateSubAtt(System_SubAttributes updateSubAtt) {
		String SQL = "Update SYSTEM_SUBATTRIBUTES set SUBATTRIBUTE_NAME='"+checkForQuotes(updateSubAtt.getSubAttribute_name())+"' where SUBATTRIBUTE_ID="+updateSubAtt.getSubAttribute_id();
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource); 
		jdbcTemplate.execute(SQL);
	}
	@Override
	public void delSubAtt(int subAttId, int active) {
		String SQL = "Update SYSTEM_SUBATTRIBUTES set is_active="+active+"where SUBATTRIBUTE_ID="+subAttId;
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource); 
		jdbcTemplate.execute(SQL);
	}

	@Override
	public void delAtt(int AttId, int active) {
		String SQL = "Update SYSTEM_ATTRIBUTES set is_active="+active+"where ATTRIBUTE_ID="+AttId;
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource); 
		jdbcTemplate.execute(SQL);
	}
	@Override
	public int getActiveProcessDetails() {
		List<Integer> count=new ArrayList<Integer>();
		 String sql = "SELECT count(*) FROM PROCESS_DETAILS_MD WHERE IS_ACTIVE=1";
		  JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);   
		  count = jdbcTemplate.query(sql, new count()); 
		return count.get(0);
	}
	@Override
	public int getRequirementDetailsFilled(String attribute) {
		List<Integer> count=new ArrayList<Integer>();
		 String sql = "SELECT count(*) FROM Requirement_Form WHERE req_id='"+attribute+"'";
		  JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);   
		  count = jdbcTemplate.query(sql, new count()); 
		return count.get(0);
	}
	@Override
	public void deletePreviousDetailsMIA(String moduleName) {
		String SQL = "delete from MIA_FORM where REQ_ID='"+moduleName+"'";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource); 
		jdbcTemplate.execute(SQL);
		
	}
	@Override
	public void deletePreviousDetailsReq(String moduleName) {
		String SQL = "delete from Requirement_FORM where REQ_ID='"+moduleName+"'";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource); 
		jdbcTemplate.execute(SQL);
		
	}
	@Override
	public void addSystemsToSubProcess(HomeDetails systemForm) {
		String SQL = "delete from MIA_FORM where REQ_ID='"+systemForm.getLink()+"' and SBP_ID="+systemForm.getModuleid();
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource); 
		jdbcTemplate.execute(SQL);
		 List<SubProcess> userList = new ArrayList<SubProcess>();   
		  SQL = "select * from SUB_PROCESS_MD where SBP_ID="+systemForm.getModuleid();   
		  userList = jdbcTemplate.query(SQL, new SubProRowMapper()); 
		  for(SubProcess subProcesses:userList)
		  {
			   SQL = "Insert into MIA_FORM (REQ_ID,STD_PROCESS,SUB_PROCESS,EXISTING_SYSTEMS,SBP_ID) values('"+systemForm.getLink()+"','"+systemForm.getModuleName()+"','"+subProcesses.getSP_Name()+"','"+systemForm.getDescription()+"',"+systemForm.getModuleid()+")";
				jdbcTemplate.execute(SQL);
		  }
	}
	@Override
	public void addSystemsToSBP(HomeDetails systemForm) {
		String SQL = "delete from MIA_FORM where REQ_ID='"+systemForm.getLink()+"' and STD_PROCESS='"+systemForm.getModuleName()+"'";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource); 
		jdbcTemplate.execute(SQL);
		List<StdBusinessProcess> userList = new ArrayList<StdBusinessProcess>();   
		  
		 SQL = "select * from STD_BUSINESS_PROCESS_MD where PROCESS_NAME='"+systemForm.getModuleName()+"'";   
		 userList = jdbcTemplate.query(SQL, new SBPRowMapper());   
		 List<SubProcess> userList1 = new ArrayList<SubProcess>();   
		  SQL = "select * from SUB_PROCESS_MD where SBP_ID in (select SBP_ID from SUB_BUSINESS_PROCESS_MD where process_id="+userList.get(0).getProcessId()+")";   
		  userList1 = jdbcTemplate.query(SQL, new SubProRowMapper()); 
		  for(SubProcess subProcesses:userList1)
		  {
			   SQL = "Insert into MIA_FORM (REQ_ID,STD_PROCESS,SUB_PROCESS,EXISTING_SYSTEMS,SBP_ID) values('"+systemForm.getLink()+"','"+systemForm.getModuleName()+"','"+subProcesses.getSP_Name()+"','"+systemForm.getDescription()+"',"+subProcesses.getSBP_id()+")";
			   jdbcTemplate.execute(SQL);
		  }
	}
	@Override
	public List<CompanyDetails> getListOfCompanies() {
		List<CompanyDetails> details=new ArrayList<CompanyDetails>();
		 String sql = "SELECT * FROM COMPANY_MD";
		  JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);   
		  details = jdbcTemplate.query(sql, new companyData()); 
		return details;
	
	}
	@Override
	public List<SiteDetails> getListOfSites(int id) {
		List<SiteDetails> details=new ArrayList<SiteDetails>();
		 String sql = "SELECT * FROM SITE_MD where company_id="+id;
		  JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);   
		  details = jdbcTemplate.query(sql, new siteData()); 
		return details;
	} 
	@Override
	public List<Criteria_titles> getCriteriaTitles() {
		List<Criteria_titles> titles = new ArrayList<Criteria_titles>();
		String SQL="Select * from CRITERIA_TABLE_MD";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		titles = jdbcTemplate.query(SQL,new CriteriaMapper() );
		return titles;
	}
	@Override
	public List<Criteria_Details> getCriteria_details() {
		List<Criteria_Details> details = new ArrayList<Criteria_Details>();
		String SQL = "Select * from CRITERIA_RATINGS_TABLE_MD";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		details = jdbcTemplate.query(SQL,new Criteria_DetailsMapper());
		return details;
	}
	@Override
	public List<Category> getDetailsCategory() {
		List<Category> category = new ArrayList<Category>();
		String SQL ="Select * from CATEGORY_TABLE_MD";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		category = jdbcTemplate.query(SQL,new CategoryMapper());
		return category;
	}
	@Override
	public List<Supplier_Info_Questions> getInfoQues(int cat_id) {
		List<Supplier_Info_Questions> ques = new ArrayList<Supplier_Info_Questions>();
		String SQL = "Select * from SUPPLIER_INFORMATION_TABLE_MD where CAT_ID="+cat_id;
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		ques = jdbcTemplate.query(SQL,new SupplierQuesMapper());
		return ques;
	}
	@Override
	public List<Ratings> getCategoryRatings(int cat_id) {
		List<Ratings> rating = new ArrayList<Ratings>();
		String SQL = "Select CRITERIA_ID from CATEGORY_TABLE_MD where CAT_ID="+cat_id;
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		int c_id = jdbcTemplate.queryForInt(SQL);
		String SQL1 = "select rating, rating_details from CRITERIA_RATINGS_TABLE_MD where CRITERIA_ID="+c_id;
		rating = jdbcTemplate.query(SQL1, new CategoryRatings());
		return rating;
	}
	@Override
	public List<Role> getSupDetails() {
		List<Role> supDet = new ArrayList<Role>();
		String SQL = "Select * from SUPPLIER_DETAILS_MD";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		supDet = jdbcTemplate.query(SQL,new RoleMapper());
		return supDet;
	}

	@Override
	public void insertInfo(List<Supplier_Info_Questions> response,String Company) {
		if(response.get(0).getRatings().equals("0"))
		{
			String SQL = "delete from SUPPLIER_RESPONSE where CAT_ID="+response.get(0).getCat_id()+" and COMPANY='"+response.get(0).getCompany()+"'";
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource); 
			jdbcTemplate.execute(SQL);
		}
		else
		{
			String SQL = "delete from SUPPLIER_RESPONSE where CAT_ID="+response.get(0).getCat_id()+" and COMPANY='"+response.get(0).getCompany()+"'";
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource); 
			jdbcTemplate.execute(SQL);
			for (Supplier_Info_Questions required:response)
			{
				SQL="INSERT INTO SUPPLIER_RESPONSE VALUES ("+required.getSd_id()+","+required.getCat_id()+","+required.getsInfo_id()+","+required.getRatings().charAt(0)+",'"+checkForQuotes(required.getComments())+"','"+required.getCompany()+"')";
				jdbcTemplate = new JdbcTemplate(dataSource); 
				jdbcTemplate.update(SQL);
			}
		}
	}
	@Override
	public List<Supplier_Info_Questions> getSavedInfo(int cat_id1, String string) {
		List<Supplier_Info_Questions> savedInfo = new ArrayList<Supplier_Info_Questions>();
		String SQL = "Select * from SUPPLIER_RESPONSE where CAT_ID="+cat_id1+" and Company='"+string+"'";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);    
		savedInfo= jdbcTemplate.query(SQL, new SupplierResponseMapper()); 
		return savedInfo;
	}
	@Override
	public List<RequirementFormDetails> getRequirementSavedProcess(String id) {
		List<RequirementFormDetails> details=new ArrayList<RequirementFormDetails>();
		String SQ = "Select REQ_ID,STD_PROCESS,SUB_PROCESS,PROCESS_NAME,RATINGS,REMARKS,DETAILS_ID,STD_BUSINESS_PROCESS,SBP_ID,SP_ID from REQUIREMENT_FORM where REQ_ID='"+id+"'";
		 JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);   
		 details = jdbcTemplate.query(SQ, new CheckRequirementsMapper()); 
		return details;
	}
	@Override
	public List<RequirementFormDetails> getSavedReqDetailFromStdP(
			String attribute, String std) {
		List<RequirementFormDetails> checkList=new ArrayList<RequirementFormDetails>();
		String SQ = "Select REQ_ID,STD_PROCESS,SUB_PROCESS,PROCESS_NAME,RATINGS,REMARKS,DETAILS_ID,STD_BUSINESS_PROCESS,SBP_ID,SP_ID from REQUIREMENT_FORM where REQ_ID='"+attribute+"' and STD_BUSINESS_PROCESS='"+std+"'";
		 JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);   
		 checkList = jdbcTemplate.query(SQ, new CheckRequirementsMapper()); 
		return checkList;
	}
	@Override
	public List<RequirementFormDetails> getNumberOfEntriesFromIDSBP(int sub,
			String attribute) {
		List<RequirementFormDetails> checkList=new ArrayList<RequirementFormDetails>();
		String SQ = "Select REQ_ID,STD_PROCESS,SUB_PROCESS,PROCESS_NAME,RATINGS,REMARKS,DETAILS_ID,STD_BUSINESS_PROCESS,SBP_ID,SP_ID from REQUIREMENT_FORM where REQ_ID='"+attribute+"' and SBP_ID="+sub;
		 JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);   
		 checkList = jdbcTemplate.query(SQ, new CheckRequirementsMapper()); 
		return checkList;
	}
	@Override
	public List<RequirementFormDetails> getNumberOfEntriesFromIdSP(int sp_id,
			String attribute) {
		List<RequirementFormDetails> checkList=new ArrayList<RequirementFormDetails>();
		String SQ = "Select REQ_ID,STD_PROCESS,SUB_PROCESS,PROCESS_NAME,RATINGS,REMARKS,DETAILS_ID,STD_BUSINESS_PROCESS,SBP_ID,SP_ID from REQUIREMENT_FORM where REQ_ID='"+attribute+"' and SP_ID="+sp_id;
		 JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);   
		 checkList = jdbcTemplate.query(SQ, new CheckRequirementsMapper()); 
		return checkList;
	}
	@Override
	public List<Ratings> getTechRatings(int i) {
		List<Ratings> ratings = new ArrayList<>();
		String SQL1 = "select rating, rating_details from CRITERIA_RATINGS_TABLE_MD where CRITERIA_ID="+i;
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		ratings = jdbcTemplate.query(SQL1, new CategoryRatings());
		return ratings;
	}
	
	@Override
	public List<SupplierRatingDetails> getSavedSupplierRatings(int sp_id, String attribute) {
		List<SupplierRatingDetails> ratings = new ArrayList<SupplierRatingDetails>();
		String SQL1 = "select * from SUPPLIER_RATING where sp_id="+sp_id+" and supplier_id='"+attribute+"'";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		ratings = jdbcTemplate.query(SQL1, new SupplierRatings());
		return ratings;
	}
	@Override
	public void addSupplierRatingsCustomers(List<SupplierRatingDetails> save) {
		if(save.get(0).getRating()==0)
		{
			String SQL = "delete from SUPPLIER_RATING where SUPPLIER_ID='"+save.get(0).getReq_id()+"' and SP_ID="+save.get(0).getSp_id();
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource); 
			jdbcTemplate.execute(SQL);
		}
		else
		{
		String SQL = "delete from SUPPLIER_RATING where SUPPLIER_ID='"+save.get(0).getReq_id()+"' and SP_ID="+save.get(0).getSp_id();
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource); 
		jdbcTemplate.execute(SQL);
		for(SupplierRatingDetails details:save)
		{
			
		SQL="INSERT INTO SUPPLIER_RATING VALUES ("+details.getDetails_id()+",'"+details.getReq_id()+"',"+details.getRating()+",'"+checkForQuotes(details.getComments())+"',"+details.getSp_id()+")";
		jdbcTemplate = new JdbcTemplate(dataSource); 
		jdbcTemplate.update(SQL);
		}}
	}
	@Override
	public List<System_SubAttributes> getTech_Ques(int cat_id1) {
		List<System_SubAttributes> ques = new ArrayList<>();
		String SQL = "select * from TECHNICAL_QUESTIONS_MD where cat_id="+cat_id1;
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		ques = jdbcTemplate.query(SQL,new TechQuestionsMapper());
		return ques;
	}
	@Override
	public List<Category> getTechSubQues( ) {
		List<Category> sub_ques = new ArrayList<>();
		String SQL ="Select * from TECHNICAL_SUB_QUESTIONS_MD";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		sub_ques = jdbcTemplate.query(SQL,new TechCategoryMapper());
		return sub_ques;
	}
	
	@Override
	public void insertTechInfo(List<Technical_Info_Questions> response,String company) {
		if(response.get(0).getRatings().equals("0"))
		{
			String SQL = "delete from TECHNICAL_INFO_RESPONSE where CAT_ID="+response.get(0).getCat_id()+" and COMPANY='"+response.get(0).getCompany()+"' and SITE='"+response.get(0).getSite()+"'";
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource); 
			jdbcTemplate.execute(SQL);
		}
		else
		{
			String SQL = "delete from TECHNICAL_INFO_RESPONSE where CAT_ID="+response.get(0).getCat_id()+" and COMPANY='"+response.get(0).getCompany()+"' and SITE='"+response.get(0).getSite()+"'";
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource); 
			jdbcTemplate.execute(SQL);
			for (Technical_Info_Questions required:response)
			{
				SQL="INSERT INTO TECHNICAL_INFO_RESPONSE VALUES ("+required.getCat_id()+","+required.getSub_cat_id()+","+required.getQues_id()+","+required.getSub_ques_id()+","+required.getRatings().charAt(0)+",'"+checkForQuotes(required.getComments())+"','"+required.getCompany()+"','"+required.getSite()+"')";
				jdbcTemplate = new JdbcTemplate(dataSource); 
				jdbcTemplate.update(SQL);
			}
		}
		
	}
	
	
	@Override
	public List<NewUser> getCustomerList() {
		List<NewUser> customers = new ArrayList<>();
		String SQL = "Select * from Company_md where type='Customer'";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		customers= jdbcTemplate.query(SQL, new CustomerMapper());
		return customers;
	}
	@Override
	public List<Category> getTech_Category() {
		List<Category> category = new ArrayList<>();
		String SQL ="Select * from TECHNICAL_CATEGORY_MD";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		category = jdbcTemplate.query(SQL,new TechCategoryMapper());
		return category;
	}
	@Override
	public List<Category> getTech_sub_category(int cat_id1) {
		List<Category> sub_category = new ArrayList<Category>();
		String SQL ="Select * from TECHNICAL_SUB_CATEGORY_MD where cat_id="+cat_id1;
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		sub_category = jdbcTemplate.query(SQL,new TechCategoryMapper());
		return sub_category;
	}
	@Override
	public List<Technical_Info_Questions> getSavedTecInfo(int cat_id1,String company,String site) {
		List<Technical_Info_Questions> savedInfo = new ArrayList<Technical_Info_Questions>();
		String SQL = "Select * from TECHNICAL_INFO_RESPONSE where CAT_ID="+cat_id1+" and Company='"+company+"' and site='"+site+"'";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);    
		savedInfo= jdbcTemplate.query(SQL, new TechnicalResponseMapper()); 
		return savedInfo;

	}
	@Override
	public List<Process_Details> getProcessDetailsByIdAll(int sp_id) {
		List<Process_Details> userList = new ArrayList<Process_Details>();   
		  String sql = "select * from PROCESS_DETAILS_MD where SP_ID="+sp_id;   
		  
		  JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);   
		  userList = jdbcTemplate.query(sql, new ProDetails()); 
		  return userList; 
	}
	@Override
	public List<Process_Details> insertedByCustomers(int id,String company,String site) {
		List<Process_Details> userList = new ArrayList<Process_Details>();   
		  String sql = "select * from PROCESS_DETAILS_MD where CUSTOMER_ACTIVATE!=0 and sp_id="+id+" and CUSTOMER_name='"+company+"' and site='"+site+"'" ;   
		  
		  JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);   
		  userList = jdbcTemplate.query(sql, new ProDetails()); 
		  return userList; 
	} 
	@Override
	public void addSubCat(Role newSubCat) {

		String sql="select max(SD_ID) as SD_ID from SUPPLIER_DETAILS_MD";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		int sd_count = jdbcTemplate.queryForInt(sql);
		String SQL = "Insert into SUPPLIER_DETAILS_MD values("+(sd_count+1)+",'"+checkForQuotes(newSubCat.getRoleName())+"')";
		jdbcTemplate.execute(SQL);

	}
	@Override
	public void updateSubCat(Role newSubCat) {

			String sql = "update SUPPLIER_DETAILS_MD set sd_name='"+checkForQuotes(newSubCat.getRoleName())+"' where sd_id="+newSubCat.getRoleid();
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			jdbcTemplate.execute(sql);


	}
	@Override
	public void updateQues(Supplier_Info_Questions newQues) {
		String sql = "update SUPPLIER_INFORMATION_TABLE_MD set SD_INFO_QUESTIONS='"+checkForQuotes(newQues.getInfo_ques())+"' where INFO_ID="+newQues.getsInfo_id();
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		jdbcTemplate.execute(sql);

	}
	@Override
	public void addNewQues(Supplier_Info_Questions newQues) {
		List<Supplier_Customer> info=new ArrayList<>();
		int present =2;
		String sql1="select SD_INFO_QUESTIONS from SUPPLIER_INFORMATION_TABLE_MD where sd_id="+newQues.getSd_id()+" and cat_id="+newQues.getCat_id1().charAt(0); 
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		info = jdbcTemplate.query(sql1, new Supplier_CustomerMapper());
		if(!info.isEmpty())
		{
		for(Supplier_Customer search : info)
		{
			if(search.getCustomer_company().equals("null"))
			{
				present= 1;
				
			}
			else  present= 0;
		}
		}
		else 
		{
			String sql="select max(INFO_ID) as INFO_ID from SUPPLIER_INFORMATION_TABLE_MD";
			int id_count = jdbcTemplate.queryForInt(sql);
			String SQL = "Insert into SUPPLIER_INFORMATION_TABLE_MD values("+(id_count+1)+","+newQues.getCat_id1().charAt(0)+","+newQues.getSd_id()+",'"+newQues.getInfo_ques()+"',0)";
			jdbcTemplate.execute(SQL);
		}
		if(present ==0)
		{
			String sql="select max(INFO_ID) as INFO_ID from SUPPLIER_INFORMATION_TABLE_MD";
			int id_count = jdbcTemplate.queryForInt(sql);
			String SQL = "Insert into SUPPLIER_INFORMATION_TABLE_MD values("+(id_count+1)+","+newQues.getCat_id1().charAt(0)+","+newQues.getSd_id()+",'"+newQues.getInfo_ques()+"',1)";
			jdbcTemplate.execute(SQL);
		}
		else if (present ==1)
		{
			String sql2 = "update SUPPLIER_INFORMATION_TABLE_MD set SD_INFO_QUESTIONS='"+checkForQuotes(newQues.getInfo_ques())+"',is_active=1 where sd_id="+newQues.getSd_id()+" and cat_id="+newQues.getCat_id1().charAt(0);
			jdbcTemplate.execute(sql2);
		}

	}
	@Override
	public void doActivation(String active, String quesid) {
		String sql = "update SUPPLIER_INFORMATION_TABLE_MD set is_active='"+active+"' where INFO_ID="+quesid;
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		jdbcTemplate.execute(sql);
	}
	@Override
	public void doSubactivation(String active, String cat_id, String subcat_id) {
		String sql = "update SUPPLIER_INFORMATION_TABLE_MD set is_active='"+active+"' where sd_id="+subcat_id+" and cat_id="+cat_id; 
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		jdbcTemplate.execute(sql);
	}
	@Override
	public void addNewTechCat(Category newCat) {
		String sql="select max(CAT_ID) as CAT_ID from TECHNICAL_CATEGORY_MD";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		int id_count = jdbcTemplate.queryForInt(sql);
		String SQL = "Insert into TECHNICAL_CATEGORY_MD values("+(id_count+1)+",'"+checkForQuotes(newCat.getCat_name())+"',3,1)";
		jdbcTemplate.execute(SQL);
	}
	@Override
	public int getLastCount() {
		String sql="select max(CAT_ID) as CAT_ID from TECHNICAL_CATEGORY_MD";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		int lastCount = jdbcTemplate.queryForInt(sql);
		return lastCount;
	}
	@Override
	public void catActivation(String active, String cat_id) {
		String sql = "update TECHNICAL_CATEGORY_MD set is_active="+active+" where CAT_ID="+cat_id.charAt(0);
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		jdbcTemplate.execute(sql);
	}
	@Override
	public void updateTechSubCat(Category newSubCat) {
		String sql = "update TECHNICAL_SUB_CATEGORY_MD set SUB_CAT_NAME='"+checkForQuotes(newSubCat.getCat_name())+"' where SUB_CAT_ID="+newSubCat.getCat_id1().charAt(0);
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		jdbcTemplate.execute(sql);
	}
	@Override
	public void doSubCatActivation(String active, String subcat_id) {
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);

		String sql5 = "SELECT count(*) FROM TECHNICAL_QUESTIONS_MD WHERE  sub_cat_id="+subcat_id;
		int count = jdbcTemplate.queryForInt(sql5);
		String sql=null;
		if(count ==0)
		{
			sql = "update TECHNICAL_SUB_CATEGORY_MD set is_active=0 where SUB_CAT_ID="+subcat_id;

		}
		else{
		 sql = "update TECHNICAL_SUB_CATEGORY_MD set is_active="+active+" where SUB_CAT_ID="+subcat_id; }
		String sql1 = "update TECHNICAL_QUESTIONS_MD set is_active="+active+" where SUB_CAT_ID="+subcat_id; 
		String sql2 = "update TECHNICAL_SUB_QUESTIONS_MD set is_active="+active+" where SUB_CAT_ID='"+subcat_id+"'";

		jdbcTemplate.execute(sql);
		jdbcTemplate.execute(sql1);
		jdbcTemplate.execute(sql2);
	} 
	@Override
	public void doQuesActivation(String active, String ques_id,String subcat_id) {
		String sql1 = "update TECHNICAL_QUESTIONS_MD set is_active="+active+" where ques_id="+ques_id; 
		String sql2 = "update TECHNICAL_SUB_QUESTIONS_MD set is_active="+active+" where ques_id='"+ques_id+"'";
		String sql3 = "SELECT count(*) FROM TECHNICAL_QUESTIONS_MD WHERE IS_ACTIVE=0 and SUB_CAT_ID="+subcat_id;
		String sql4 = "SELECT count(*) FROM TECHNICAL_QUESTIONS_MD WHERE SUB_CAT_ID="+subcat_id;
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		jdbcTemplate.execute(sql1);
		jdbcTemplate.execute(sql2);
		int countAtive= jdbcTemplate.queryForInt(sql3);
		int countTotal = jdbcTemplate.queryForInt(sql4);
		if(countAtive==countTotal)
		{
			String sql5 = "update TECHNICAL_SUB_CATEGORY_MD set is_active=0 where SUB_CAT_ID="+subcat_id; 
			jdbcTemplate.execute(sql5);
		}
		else {
			String sql6 = "update TECHNICAL_SUB_CATEGORY_MD set is_active=1 where SUB_CAT_ID="+subcat_id; 
			jdbcTemplate.execute(sql6);
		}
	}
	@Override
	public void updateTechQues(System_SubAttributes newQues) {
		String sql1 = "update TECHNICAL_QUESTIONS_MD set QUESTION='"+checkForQuotes(newQues.getSubAttribute_name())+"' where ques_id="+newQues.getSubAttribute_id(); 
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		jdbcTemplate.execute(sql1);
	}
	@Override
	public void updateTechSubQues(Category newSubQues) {
		String sql2 = "update TECHNICAL_SUB_QUESTIONS_MD set SUB_QUESTIONS='"+checkForQuotes(newSubQues.getCat_name())+"' where sub_ques_id='"+newSubQues.getCat_id()+"'";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		jdbcTemplate.execute(sql2);
	}
	@Override
	public void doSubQuesActivation(String active, String ques_id,String subcat_id) {
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);

		 String sql2 = "update TECHNICAL_SUB_QUESTIONS_MD set is_active="+active+" where sub_ques_id='"+ques_id+"'";
		String sql = "SELECT count(*) FROM TECHNICAL_SUB_QUESTIONS_MD WHERE IS_ACTIVE=0 and ques_id="+subcat_id;
		String sql1 = "SELECT count(*) FROM TECHNICAL_SUB_QUESTIONS_MD WHERE ques_id="+subcat_id;

		jdbcTemplate.execute(sql2);
		int countAtive= jdbcTemplate.queryForInt(sql);
		int countTotal = jdbcTemplate.queryForInt(sql1);
		if(countAtive==countTotal)
		{
			String sql3 = "update TECHNICAL_QUESTIONS_MD set is_active=0 where ques_id="+subcat_id; 
			jdbcTemplate.execute(sql3);
		}
		else {
			String sql4 = "update TECHNICAL_QUESTIONS_MD set is_active=1 where ques_id="+subcat_id; 
			jdbcTemplate.execute(sql4);
		}
	} 
	@Override
	public void addNewTechQues(System_SubAttributes newQues) {
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		if(newQues.getAttribute_subtype()==0)
		{
			String sql="select max(SUB_CAT_ID) as SUB_CAT_ID from TECHNICAL_SUB_CATEGORY_MD";

			int lastCount = jdbcTemplate.queryForInt(sql);
			String SQL1 = "Insert into TECHNICAL_SUB_CATEGORY_MD (SUB_CAT_ID, CAT_ID, IS_ACTIVE) values("+(lastCount+1)+","+newQues.getMainAttribute_id()+",1)";
			jdbcTemplate.execute(SQL1);
			String sql1= "select sub_cat_id from TECHNICAL_SUB_CATEGORY_MD where CAT_ID="+newQues.getMainAttribute_id();
			Category newSubCat = jdbcTemplate.queryForObject(sql1, new SubCatMapper());
			String sql3="select max(QUES_ID) as QUES_ID from TECHNICAL_QUESTIONS_MD";
			int lastCount1 = jdbcTemplate.queryForInt(sql3);
			String SQL = "Insert into TECHNICAL_QUESTIONS_MD values("+(lastCount1+1)+",'"+checkForQuotes(newQues.getSubAttribute_name())+"',"+newSubCat.getCriteria_id()+","+newQues.getMainAttribute_id()+",0,1)";
			jdbcTemplate.execute(SQL);
		}
		else
		{
			String sql4 = "SELECT count(*) FROM TECHNICAL_QUESTIONS_MD WHERE  sub_cat_id="+newQues.getAttribute_subtype();
			int count = jdbcTemplate.queryForInt(sql4);
			if(count ==0)
			{
				String sql = "update TECHNICAL_SUB_CATEGORY_MD set is_active=1 where SUB_CAT_ID="+newQues.getAttribute_subtype();
				jdbcTemplate.execute(sql);
			}

		String sql2="select max(QUES_ID) as QUES_ID from TECHNICAL_QUESTIONS_MD";

		int lastCount = jdbcTemplate.queryForInt(sql2);
		String SQL = "Insert into TECHNICAL_QUESTIONS_MD values("+(lastCount+1)+",'"+checkForQuotes(newQues.getSubAttribute_name())+"',"+newQues.getAttribute_subtype()+","+newQues.getMainAttribute_id()+",0,1)";
		jdbcTemplate.execute(SQL);
		}
	} 
	@Override
	public void addNewTechSubCat(Category newSubCat) {
		String sql="select max(SUB_CAT_ID) as SUB_CAT_ID from TECHNICAL_SUB_CATEGORY_MD";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		int lastCount = jdbcTemplate.queryForInt(sql);
		String SQL = "Insert into TECHNICAL_SUB_CATEGORY_MD values("+(lastCount+1)+",'"+checkForQuotes(newSubCat.getCat_name())+"',"+newSubCat.getCriteria_id()+",0)";
		jdbcTemplate.execute(SQL);

	}
	
	@Override    
	public String create(NewUser register)    
	{       
		String username= register.getFirstName()+" " +register.getLastName();
		String SQL = "Insert into Role_Transaction values('"+register.getUserid()+"','"+username+"','"+register.getEncryptedPwd()+"',3,'"+register.getCompany()+"','"+register.getSiteName()+"',"+register.getPwdQues()+",'"+checkForQuotes(register.getPwdQuesAns())+"')";       
		String SQL1 = "SELECT * FROM Role_Transaction WHERE user_id = '"+register.getUserid()+"'" ;  
		String nameOfCustomer=register.getFirstName()+register.getLastName();

		if(register.getPswd().equals(register.getCmpswd()))
		{
			if(register.getPswd().matches("^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z]).{6,20}"))
			{

			if(!nameOfCustomer.matches(".*[^A-Za-z].*"))
			{
				if(!(register.getCompany().equals("Select")))
						{
						if(!(register.getSiteName().equals("Select")))
							{	try       
										{   
											String useridExist = null;
											List<Login> userList=new ArrayList<Login>();
											JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);   
											userList = jdbcTemplate.query(SQL1, new LoginMapper()); 
											if(!userList.isEmpty())
												{
													useridExist  = "exists";

												}
												else useridExist = "notavailable";

											if(useridExist.equals("notavailable"))
											{
												return createUser(SQL);

											}
											else return "UserID Already Exist";
										} 


										catch (Exception e)    
										{            
											return "Connection Problem. Please try again";      
										}
							}
						else return "Please Select the site";
						}
				else return "Please Select your Company";
			}
			else return "Name must contain only alphabets";
			}
			else return "Invalid Password";
		}else return "Password does not match";
	} 
	public String createUser(String SQL)
	{
		
		try {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);   
			  
			  jdbcTemplate.update(SQL); 
			              
				return "done";           
		} catch (Exception e) {
			return "Registration failed";  
		}
	}
	
	@Override    
	public boolean validate(Login login)    
	{     
		String SQL = "SELECT * FROM Role_Transaction WHERE user_id = '"+login.getUserid()+"' and password = '"+login.setEncryptedPwd(login.getPassword())+"'";       
		List<Login> userList=new ArrayList<Login>();
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);   
		userList = jdbcTemplate.query(SQL, new LoginMapper()); 
		if (!userList.isEmpty())           
		{     
			login.setRoleId(userList.get(0).getRoleId());
			login.setUsername(userList.get(0).getUsername());
			login.setCompany(userList.get(0).getCompany()); 
			login.setSite(userList.get(0).getSite());
			return true;          
		}           
		else          
		{  
			return false;    
		}       
	}
	@Override
	public List<RequirementsList> getSubmittedReqList() {
		List<RequirementsList> list=new ArrayList<>();
		String SQL = "select distinct * from LIST_OF_REQUIREMENT";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);  
		list = jdbcTemplate.query(SQL, new RequirementListMapper());  
		return list;
	}
	@Override
	public int getStdIdName(String userid) {
		String SQL = "select PROCESS_ID from STD_BUSINESS_PROCESS_MD where PROCESS_NAME='"+userid+"'";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);  
		int id= jdbcTemplate.queryForInt(SQL);  
		return id;
	}
	@Override
	public int getBusiProcessIdFromName(String company) {
		String SQL = "select SBP_ID from SUB_BUSINESS_PROCESS_MD where SBP_NAME='"+company+"'";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);  
		int id= jdbcTemplate.queryForInt(SQL);  
		return id;
	}
	public int getNoOfRecords() {
		return noOfRecords;
	}
	public void setNoOfRecords(int noOfRecords) {
		this.noOfRecords = noOfRecords;
	}
	@Override
	public List<RequirementFormDetails> viewAllReqDetails(int i,
			int recordsPerPage, String searchTable) {
		int end=i+recordsPerPage;
		String query = "select * from ( select a.*, ROWNUM rnum from  ("+searchTable+") a  where ROWNUM <= "+end+" )where rnum  >= "+(i+1);
		List<RequirementFormDetails> list = new ArrayList<RequirementFormDetails>();
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);  
		list = jdbcTemplate.query(query, new CheckRequirementsMapper()); 
		String str="REQ_ID,STD_PROCESS,SUB_PROCESS,PROCESS_NAME,submitted_RATING,submitted_comments,DETAILS_ID,STD_BUSINESS_PROCESS,SBP_ID,SP_ID";
		int len = str.length();
		int index=searchTable.indexOf("REQ_ID,STD_PROCESS,SUB_PROCESS,PROCESS_NAME,submitted_RATING,submitted_comments,DETAILS_ID,STD_BUSINESS_PROCESS,SBP_ID,SP_ID");
		String count=searchTable.substring(0,index-1)+" count(*) "+searchTable.substring(index+len);
		this.noOfRecords =	jdbcTemplate.queryForInt(count);
		return list;
	}
	@Override
	public int getNoOfRecordsValue() {
		return noOfRecords;
	}
	@Override
	public List<RequirementFormDetails> getRequirementsToExcel(
			String searchTable) {
		List<RequirementFormDetails> list = new ArrayList<RequirementFormDetails>();
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);  
		list = jdbcTemplate.query(searchTable, new CheckRequirementsMapper());  
		return list;
	}	
	@Override
	public List<String> getSupplierList() {
		String sql = "Select SUPPLIER_ID from SUPPLIER_RATING  GROUP BY  SUPPLIER_ID HAVING COUNT(*) >1 ORDER BY SUPPLIER_ID ASC";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);   
		List<String> suppliers= jdbcTemplate.query(sql, new StringMapper()); 
		return suppliers;
	}
	@Override
	public List<SubBusinessProcess> getSubBP() {
		List<SubBusinessProcess> sub_business_process = new ArrayList<>();
		String sql = "select * from SUB_BUSINESS_PROCESS_MD ";   
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);   
		sub_business_process = jdbcTemplate.query(sql, new SubBusinessDetails()); 
		return sub_business_process; 

	}

	@Override
	public SupplierRatingDetails getSupplierRatingsScore(String string,int process_ID) {
		SupplierRatingDetails scoreDetails = new SupplierRatingDetails();
		String sql="Select AVG(rating) from SUPPLIER_RATING  where SP_ID in (select sp_id from SUB_PROCESS_MD where SUB_PROCESS_MD.SBP_ID="+process_ID+") and SUPPLIER_ID='"+string+"'";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);   
		List<Supplier_Customer> score = jdbcTemplate.query(sql, new Supplier_CustomerMapper());
		String score1=score.get(0).getCustomer_company();
		if(score1 != null)
		{
			if(score1.length()>4)
			{
				scoreDetails.setComments(score1.substring(0,1));
			}
			else scoreDetails.setComments(score1.substring(0,1));
		}
		else scoreDetails.setComments("0");
		scoreDetails.setReq_id(string);
		scoreDetails.setSp_id(process_ID);
		return scoreDetails;
	}
	@Override
	public Role checkModuleData(int processId) 
	{
		Role modulePresent = new Role();
		String sql = "SELECT count(*) FROM SUB_BUSINESS_PROCESS_MD WHERE PROCESS_ID="+processId;  
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);   
		int count= jdbcTemplate.queryForInt(sql);
		if(count!=0)
		{
			modulePresent.setRoleid(processId);
			modulePresent.setRoleName("present");
			return modulePresent;
		}
		else
		{
			modulePresent.setRoleid(processId);
			modulePresent.setRoleName("Not present");
			return modulePresent;
		}

	}
	@Override
	public String formExists(String id) {
		String sql="select TEMP_REQ_ID from TEMP_REQUIREMENT_TABLE where user_id='"+id+"'";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		List<String> check=null;
		check = jdbcTemplate.query(sql,new StringMapper());
		if(check.isEmpty())
		{
			return "no";
		}
		else return check.get(0);
	}
	@Override
	public String formPresent(String userid) {
		String sql="select TEMP_REQ_ID from TEMP_MIA_TABLE where user_id='"+userid+"'";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		List<String> check=null;
		check = jdbcTemplate.query(sql,new StringMapper());
		if(check.isEmpty())
		{
			return "no";
		}
		else return check.get(0);
	}
	@Override
	public List<RequirementsList> getSubmittedMiaList() {
		List<RequirementsList> list=new ArrayList<>();
			String SQL = "select distinct * from LIST_OF_ASSESSMENT";
			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);  
			list = jdbcTemplate.query(SQL, new RequirementListMapper());  
			return list;
		
	}
	@Override
	public List<String> viewAllMiaDetails(int i, int recordsPerPage,
			String searchMiaTable) {
		int end=i+recordsPerPage;
		String query = "select * from ( select a.*, ROWNUM rnum from  ("+searchMiaTable+") a  where ROWNUM <= "+end+" )where rnum  >= "+(i+1);
		List<String> list = new ArrayList<String>();
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);  
		list = jdbcTemplate.query(query,new StringMapper());  
		String count="select count(*) from ("+searchMiaTable+")";
		this.noOfRecordsMia =	jdbcTemplate.queryForInt(count);
		return list;
	}
	public int getNoOfRecordsMia() {
		return noOfRecordsMia;
	}
	public void setNoOfRecordsMia(int noOfRecordsMia) {
		this.noOfRecordsMia = noOfRecordsMia;
	}
	@Override
	public int getNoOfRecordsValueMia() {
		return noOfRecordsMia;
	}
	@Override
	public List<String> getMiaToExcel(String searchMiaTable) {
		List<String> list = new ArrayList<String>();
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);  
		list = jdbcTemplate.query(searchMiaTable,new StringMapper());  
		return list;
	} 
	@Override
	public List<HomeDetails> getCustomerSystemList() {
		List<HomeDetails> customers = new ArrayList<>();
		String sql="Select distinct Company,site from System_Name";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		customers  = jdbcTemplate.query(sql, new SavedTableExtractor());
		return customers;
	}
	@Override
	public List<Role> getUsers(int[] systemsID,List<Systems> systems) {
		List<Role> values=new ArrayList<>();
		
		String sql=null;
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		for(int i=0;i<systemsID.length;i++)
		{
			Role value= new Role();
			sql= "select max(details) from SYSTEM_DETAILS where ATTRIBUTE_ID=5 and SUBATTRIBUTE_ID=6 and SYSTEM_ID="+systemsID[i];
			int users = jdbcTemplate.queryForInt(sql);
			for(Systems seeSystems : systems)
			{
				if(seeSystems.getSys_ID()==systemsID[i])
				{
					value.setRoleid(users);
					value.setRoleName(seeSystems.getSys_Name());
				}
			}
			values.add(value);
		}
		return values;
	}
	@Override
	public List<Role> getAges(int[] systemsID,List<Systems> systems) {
		List<Role> values=new ArrayList<>();
		
		String sql=null;
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		for(int i=0;i<systemsID.length;i++)
		{
			sql= "select max(details) from SYSTEM_DETAILS where ATTRIBUTE_ID=7 and SYSTEM_ID="+systemsID[i];
			Role value= new Role();
			int age = jdbcTemplate.queryForInt(sql);
			for(Systems seeSystems : systems)
			{
				
				if(seeSystems.getSys_ID()==systemsID[i])
				{
					
					value.setRoleid(age);
					value.setRoleName(seeSystems.getSys_Name());
				}
			}
			values.add(value);
		}
		return values;
	}
	@Override
	public List<Role> getPswdRecoveryQues() {
		List<Role> pwdQues = new ArrayList<>();
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		String SQL = "Select * from FORGOT_PSWD_QUES_MD";
		pwdQues= jdbcTemplate.query(SQL, new RoleMapper());
		return pwdQues;
	}
	@Override
	public List<CompanyDetails> checkIdPresent(String userid) {
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);  
		String SQL = "SELECT pwdques,pwdans,password FROM Role_Transaction WHERE user_id = '"+userid+"'";
		List<CompanyDetails> data=new ArrayList<CompanyDetails>();
		data = jdbcTemplate.query(SQL, new companyData()); 
		return data;
	}
	@Override
	public String getSecretQuestion(int number) {
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		List<String> list = new ArrayList<String>();
		String SQL = "Select SECRET_QUES from FORGOT_PSWD_QUES_MD where QUES_ID="+number;
		 list= jdbcTemplate.query(SQL, new StringMapper());
		return list.get(0);
	} 
}  
