CREATE 
    ALGORITHM = UNDEFINED 
    DEFINER = `root`@`localhost` 
    SQL SECURITY DEFINER
VIEW `final_project`.`view_userapplicance` AS
    SELECT 
        `cm`.`Community_UserID` AS `UserID`,
        `ap`.`ApplianceName` AS `ApplianceName`,
        `ap`.`PowerWattage` AS `PowerWattage`,
        (CASE
            WHEN (`ap`.`Appliance_IfGreen` = 1) THEN 'Green Appliance'
            ELSE 'Non Green Applicance'
        END) AS `Green/Non Green`
    FROM
        (`final_project`.`appliance` `ap`
        JOIN `final_project`.`community_main` `cm` ON ((`cm`.`Community_Main_AssociatedCommunityID` = `ap`.`Appliance_AssociatedCommunityID`)));
        

CREATE 
    ALGORITHM = UNDEFINED 
    DEFINER = `root`@`localhost` 
    SQL SECURITY DEFINER
VIEW `final_project`.`view_userbill` AS
    SELECT 
        `ub`.`UserBill_UserID` AS `UserID`,
        `ub`.`MonthlyPowerConsumption` AS `Your Montly Consumption`,
        `ub`.`MonthlyPowerGeneration` AS `Your Monthly Generation`,
        `ub`.`BillAmount` AS `Your Bill`
    FROM
        `final_project`.`userbill` `ub`;
        
        
CREATE 
    ALGORITHM = UNDEFINED 
    DEFINER = `root`@`localhost` 
    SQL SECURITY DEFINER
VIEW `final_project`.`view_userpowerresources` AS
    SELECT 
        `final_project`.`powerresources`.`PowerResources_UserID` AS `UserID`,
        `final_project`.`powerresourcetype`.`PowerResourceTypeName` AS `Power Resources`
    FROM
        (`final_project`.`powerresources`
        JOIN `final_project`.`powerresourcetype` ON ((`final_project`.`powerresources`.`PowerResources_PowerResourceTypeID` = `final_project`.`powerresourcetype`.`PowerResourceTypeID`)));
        