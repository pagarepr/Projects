CREATE USER 'newuser'@'localhost' IDENTIFIED BY 'password';

GRANT SELECT ON * . * TO 'newuser'@'localhost';



CREATE USER 'alterUser'@'localhost' IDENTIFIED BY 'password';

GRANT ALTER ON * . * TO 'newuser'@'localhost';



CREATE USER 'deleteUser'@'localhost' IDENTIFIED BY 'password';

GRANT DELETE ON * . * TO 'newuser'@'localhost';