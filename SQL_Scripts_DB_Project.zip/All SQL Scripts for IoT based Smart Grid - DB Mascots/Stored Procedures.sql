CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_CalculateuserBillAmount`()
BEGIN

create temporary table temp_power_consumption as 
(select UserID, sum(PeakHourMeterReading) as PeakHourMeterReading, sum(NonPeakHourMeterReading) as NonPeakHourMeterReading
from powerconsumption 
Inner Join smartsocket on SmartSocketIP = PowerConsumption_SmartSocketIP
group by PowerConsumption_SmartSocketIP, month(TrackedOnDate));

create temporary table temp_power_Generation as 
(select PowerResources_UserID, sum(EnergyGenerated) as UserEnergyGeneration
from userenergygeneration 
Inner Join powerresources on PowerResourcesIP = UserEnergyGeneration_PowerResourcesIP
group by UserEnergyGeneration_PowerResourcesIP, month(TrackedOnDate));


Create temporary table temp_finalUserBil as(
select SUM(TiredBillAmount) as UserBillAmount,  Community_UserID from (
select *, (actualpowerused*TiredRate) as TiredBillAmount from(
select *, CASE WHEN powerConsumption > 0 Then (NonPeakHourMeterReading - powerConsumption - UsageFrom) 
			   ELSE (NonPeakHourMeterReading- UsageFrom +2) END as actualpowerused from (
select Community_UserID, Community_CommunityID, NonPeakHourMeterReading,(NonPeakHourMeterReading - UsageTo) as powerConsumption,
	   UsageFrom,UsageTo, TiredRate from community_main cm
inner join rates r on cm.Community_CommunityID = r.Rates_CommunityID 
inner join temp_power_consumption tpc on tpc.UserID = cm.Community_UserID) as Table1
where NonPeakHourMeterReading > UsageFrom) as nonPeakHourBill) as TiredUserBill
GROUP BY Community_UserID);

update userbill  
inner join temp_finalUserBil on UserBill_UserID = Community_UserID 
inner join temp_power_consumption on UserID =  UserBill_UserID 
left join temp_power_Generation on UserBill_UserID =  PowerResources_UserID
set BillAmount = (CASE WHEN UserEnergyGeneration is NULL THEN (UserBillAmount + (PeakHourMeterReading*0.1))
ELSE (UserBillAmount + (PeakHourMeterReading*0.1)) -(UserEnergyGeneration*0.05) END);


drop table temp_power_consumption;
drop table temp_finalUserBil;
drop table temp_power_Generation;



END


















CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_getBackUPPowerStation`( )
BEGIN
	update ComminityPowerStation
    set ComminityPowerStation_Status = 
				CASE When comminitypowerstation.ComminityPowerStation_IfRunning = 0 
				then 'Main power station failed, back up running'
				else 'Main Station Running' end;
	
END























CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_getPowerConsumptionMonthly`()
BEGIN
update UserBill
set MonthlyPowerConsumption =
(select sum(PeakHourMeterReading + NonPeakHourMeterReading)
from PowerConsumption
where (UserBill_UserID = (select UserId from SmartSocket
where SmartSocket.SmartSocketIP = PowerConsumption.PowerConsumption_SmartSocketIP))
and Month (TrackedOnDate) = Month (CURRENT_DATE - INTERVAL 1 MONTH)
group by PowerConsumption_SmartSocketIP);
END





















CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_getPowerGenerationMonthly`()
BEGIN
update UserBill
set MonthlyPowerGeneration= (select sum(EnergyGenerated) from userEnergyGeneration 
where ((UserBill_UserID = (select PowerResources_UserID from PowerResources
where powerResources.PowerResourcesIP=userEnergyGeneration.UserEnergyGeneration_PowerResourcesIP)))
and Month (TrackedOnDate) = Month (CURRENT_DATE - INTERVAL 1 MONTH)
group by UserEnergyGeneration_PowerResourcesIP);
END






















CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_insertIntoUserBill`()
begin

declare maxCount int unsigned default 100;
declare counter int unsigned default 0;

  start transaction;
  while counter < maxCount do
    insert into userbill  (userbill.UserBill_UserID, userbill.BillAmount , userbill.DateGenerated, userBill.DueDate, userbill.MonthlyPowerConsumption,userbill.MonthlyPowerGeneration)
    values((select Distinct UserID from users order by UserID asc LIMIT counter,1), 0 , CURRENT_DATE, (CURRENT_DATE + INTERVAL 1 MONTH),0,0 );
    set counter=counter+1;
  end while;
  commit;
end



