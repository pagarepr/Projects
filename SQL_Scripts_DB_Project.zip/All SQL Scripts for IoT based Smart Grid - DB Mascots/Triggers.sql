CREATE DEFINER = CURRENT_USER TRIGGER `final_project`.`PowerConsumption_AFTER_INSERT` AFTER INSERT ON `PowerConsumption` FOR EACH ROW
BEGIN
insert into usercommunication (UserCommunication_UserID,MessageSent) 
values 
((select UserID from smartsocket where SmartSocketIP IN 
(select PowerConsumption_SmartSocketIP from powerconsumption where 
(select threshold from threshold where Threshold_UserID = (select UserID from smartsocket where SmartSocketIP = 
(select PowerConsumption_SmartSocketIP from powerconsumption order by TrackedOnDate desc limit 1)))
<(select sum(PeakHourMeterReading + NonPeakHourMeterReading) from powerconsumption where 
PowerConsumption_SmartSocketIP = (select SmartSocketIP from smartsocket where SmartSocketIP = 
(select PowerConsumption_SmartSocketIP from powerconsumption order by TrackedOnDate desc limit 1))
group by year((select TrackedOnDate from powerconsumption order by TrackedOnDate desc limit 1)),
month((select TrackedOnDate from powerconsumption order by TrackedOnDate desc limit 1)))
and PowerConsumption_SmartSocketIP = (select PowerConsumption_SmartSocketIP from powerconsumption order by TrackedOnDate desc limit 1
))),'Your power usage has exceeded the set threshold');
END


USE `final_project`;

DELIMITER $$
USE `final_project`$$
CREATE DEFINER = CURRENT_USER TRIGGER `final_project`.`PeakHoursTriggers_AFTER_INSERT` AFTER INSERT ON `PeakHoursTriggers` FOR EACH ROW
BEGIN

insert into final_project.usercommunication (UserCommunication_UserID,MessageSent)
values 
((select community_main.Community_UserID from community_main where community_main.Community_Main_AssociatedCommunityID = 
(select appliance.Appliance_AssociatedCommunityID from appliance where appliance.ApplianceIP = 
(select PeakHoursTriggers_ApplianceIP from peakhourstriggers order by peakhourstriggers.SwitchedOnDate, peakhourstriggers.SwitchedOnTime desc limit 1))),
'You have turned your device during peak hours. Do you want to continue?');
END
$$

